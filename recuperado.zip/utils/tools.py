import datetime
import os
import re

from utils import broadcast, excelUtils
from internal.com import logControl

class Utils:

    logTools = logControl.LogControl()
    broadcast = broadcast.Broadcast()
    exceltools = excelUtils.XlsxUtils()
    serviceMap = False
    def clearDir(self, path):

        files = os.listdir(path)

        index = 0
        max = len(files)

        if max == 0:
            max = 1

        counter = 0

        for file in files:
            percentual = float("{:.2f}".format((index / max) * 100))
            self.broadcast.broadcastText("REMOVENDO ARQUIVOS | " + str(index) + " de " + str(max) + " | " + str(percentual) + "%")

            fullPath = path + "/" + file
            response = self.deleteFile(fullPath)

            if response:
                counter = counter + 1

        percentual = float("{:.2f}".format((counter / max) * 100))
        self.broadcast.broadcastText("PROCESSO FINALIZADO | " + str(counter) + " arquivos removidos | Taxa de efetividade: " + str(percentual) + "%" )

    def deleteFile(self, path):

        try:
            os.remove(path)
            return True
        except:
            self.logTools.addLog("FILE ERROR", "Não foi possível deletar: " + str(path))
            print("Não foi possível deletar: " + str(path))
            return False

    def getDate(self):



        try:
            userDate = self.broadcast.custonData()
            rDate = datetime.datetime.strptime(userDate, '%d.%m.%Y')
            mDate = rDate.strftime('%d.%m.%Y')
            return mDate
        except:
            None


        mDate = str(datetime.datetime.now())

        mDate = mDate.split(" ")[0].split("-")

        mDate = mDate[2] + "." + mDate[1] + "." + mDate[0]

        return mDate




    def fixDecimal(self, value, reduce=False):

        data = str(value)
        data = data.replace(".", ",")

        mTemp = data.split(",")

        if len(mTemp) == 2 and reduce:

            if len(mTemp[1]) > 2:
                mTemp[1] = mTemp[1][:2]
                return  mTemp[0] + ',' + mTemp[1]
            else:
                return mTemp[0] + ',' + mTemp[1]
        else:
            return data



    def convert2float(self, value):

        data = str(value)
        data = data.replace("\n", "")
        data = data.replace(" ", "")
        data = data.replace("-", "")

        if len(data) > 3 and (data[-3] == "." or data[-3] == ","):
            mdata = list(data)
            mdata[-3] = "#"
            data = "".join(mdata)

        if len(data) > 2 and (data[-2] == "." or data[-2] == ","):
            mdata = list(data)
            mdata[-2] = "#"
            data = "".join(mdata)


        data = data.replace(".", "")
        data = data.replace(",", "")
        data = data.replace("#", ".")

        if data == "":
            return 0
        else:
            try:
                data = float(data)
                return data
            except:
                print("Value: ", value, "Data:", data)
                return value



    def fixFloat2Str(self, data):

        try:
            temp = str(data)

            if temp[-2] == "." and temp[-1] == "0":
                temp = temp[:-2]

            return temp
        except:
            return data

    def extract_numeric_string(self, input_string):
        numeric_string = ''.join(re.findall(r'\d', input_string))
        return numeric_string


    def dateSAP(self):

        day = str(datetime.datetime.now().day)
        if len(day) != 2:
            day = "0" + day

        month = str(datetime.datetime.now().month)

        if len(month) != 2:
            month = "0" + month

        return day + "." + month + "." + str(datetime.datetime.now().year)



    def checkService(self, texto, compareDict=False):

        texto = str(texto).upper().strip()

        if self.serviceMap == False:
            self.servicesCOD()

        if compareDict != False:
            for item in str(texto).split(" "):
                if item in self.serviceMap:
                    if any(str(key) in compareDict for key in self.serviceMap[item]):
                        return True
            return False
        else:
            for item in str(texto).split(" "):
                if item in self.serviceMap:
                    return self.serviceMap[item]

            return False


    def servicesCOD(self):

        rData = self.exceltools.loadSheet_v2(self.broadcast.templates(), "COD")

        sMap = {}

        for index in range(1, len(rData)):

            try:

                keyCos = self.fixFloat2Str(str(rData[index][0])).upper().strip()
                ketService = str(rData[index][1]).split("Servicio de")[1].upper().strip()
                keyService2 = str(rData[index][1]).split(" ")[-1].upper().strip()
                keyservice3 = [str(item).strip() for item in str(rData[index][2]).split(";")]

                sMap[keyCos] = [keyCos]
                sMap[ketService] = [keyCos]
                sMap[keyService2] = [keyCos]

                for msItem in keyservice3:
                    vlist = [keyCos] + [str(x) for x in keyservice3]
                    sMap[msItem] = vlist

            except:
                pass

        self.serviceMap = sMap
        return sMap

    def date2str(self, mdate):

        rDate = self.fixDate(mdate)

        if isinstance(rDate, datetime.datetime):

            formatted_date = rDate.strftime('%d.%m.%Y')
        else:
            formatted_date = mdate

        return formatted_date


    def fixDate(self, date):

        stringDates = False
        date_object = date

        if not isinstance(date_object, datetime.datetime):
            sDate = str(date_object).replace("_", "").split(" ")[0]

            possible_formats = [
                "%d-%m-%Y",
                "%d/%m/%Y",
                "%d.%m.%Y",
                "%Y-%m-%d",
                "%Y.%m.%d",
                "%Y/%m/%d",
            ]

            for date_format in possible_formats:
                try:
                    date_object = datetime.datetime.strptime(sDate, date_format)
                    break
                except ValueError:
                    pass

        if isinstance(date_object, datetime.datetime):

           return date_object


        return date