# -*- coding: utf-8 -*-

import ctypes
import multiprocessing
import os
import subprocess
import sys
import traceback

from PyQt6 import QtWidgets, QtCore
from PyQt6.QtCore import QTimer

from functions import filter, sapComp, restituicao_uatp
from internal.com import communication
from internal.configure import CustomWidget
from internal.internal_pages import main_page

from internal import configure
from pages import config, processos
from utils import excelTools
from pymsgbox import alert

PROCESS_ID="438"
PROCESS_VERSION="5.8"
TOKEN="4d2d108b-7693-4c52-8eab-16e5a17405aa"

APP_NAME = "Propostas de Compensação"
APP_TITLE = "Propostas de Compensação"
DEV = "tarcisio.b.prates"
PASSWORD = "12345"
URL_DIR = "./images/source_code.7z" # URL OU CAMINHO PARA ZIP ou UM ARQUIVO QUE POSSA SER ABERTO COMO UM TXT, DOC ETC

URL_MANUAL = "https://myoffice.accenture.com/:f:/r/personal/tarcisio_b_prates_accenture_com/Documents/REPOSITORIO/MANUAIS?csf=1&web=1&e=NbS471"
URL_SDD = "https://myoffice.accenture.com/:f:/r/personal/tarcisio_b_prates_accenture_com/Documents/REPOSITORIO/MANUAIS?csf=1&web=1&e=NbS471"

WINDOW_ICON = "./images/logo.ico"
ICON_PATH = './images/logo.png'
ICON_DARK = './images/logo.png'

CLIENT_LOGO = './images/latam_logo.png'
CLIENT_NAME = "LATAM AIRLINES"
CLIENT_COLOR = "#2a0088"
CLIENT_TEXT_COLOR = "#ffffff"




class Accenture_Operations:

    def main(self):


        try:

            # CRIA UMA JANELA
            self.app = QtWidgets.QApplication(sys.argv)
            self.notification_window = None
            self.mPage = main_page.Ui_Form()
            self.mPage.rotation_angle = 0
            self._translate = QtCore.QCoreApplication.translate

            self.Form = CustomWidget(notification_window=self.notification_window, page=self.mPage)
            self.mPage.setupUi(self.Form) # CARREGA OS EMELENTOS DA JANELA PRINCIPAL

            self.fx = configure.Functions(self.mPage, self.Form, self.app) # CONFIGURA AS FUNÇÕES E EVENTOS DA JANELA PRINCIPAL
            self.fx.info(PROCESS_ID, PROCESS_VERSION, TOKEN, APP_NAME, ICON_PATH, ICON_DARK, APP_TITLE, DEV, PASSWORD, URL_DIR, URL_MANUAL, URL_SDD,  CLIENT_LOGO, CLIENT_NAME, CLIENT_COLOR, CLIENT_TEXT_COLOR)
            self.fx.config()
            self.comm = communication.Commnunication()
            if not self.fx.echoCheck():
                return



            #CRIA AS JANELA NO MENU PRINCIPAL
            self.criaJanela()

            #call your code here
            self.__initUI()


            try:#CRIA UM ID DE JANELA PARA SUA APLICAÇÃO
                myappid = PROCESS_ID + PROCESS_VERSION
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
            except ImportError:
                pass
            QTimer.singleShot(0, self.Form.update_background)
            QTimer.singleShot(1, self.fx.switch_theme)
            self.Form.show() # EXIBE A JANELA
            try:
                sys.exit(self.app.exec())
            except:
                pass
        except:
            print(traceback.format_exc())
            open("./log.txt", "a", encoding="UTF-8").write(traceback.format_exc())
            alert(title='Opps!' , text=self._translate("Form","Ocorreu um erro. Verifique o LOG"))





    def criaJanela(self):

        self.configWidget = QtWidgets.QWidget()  # Primeiro, cria-se um widget em branco, que será usado como contêiner.
        self.configPage = config.Ui_Form()  # Em seguida, instancia-se a classe principal gerada pelo Qt Designer (arquivo .py).
        self.configPage.setupUi(self.configWidget)  # Por fim, o método setupUi configura o widget criado com os elementos gráficos definidos no Designer.
        # Após isso, os elementos da interface podem ser acessados e manipulados por meio de self.fopPage, permitindo adicionar lógica,
        # como animações, eventos e comportamentos personalizados.

        self.procWidget = QtWidgets.QWidget()
        self.procPage = processos.Ui_Form()
        self.procPage.setupUi(self.procWidget)

        self.janelas = {

            "HOME":{
                "TAB_NAME": "HOME",
                "TAB_ICON": "./images/home.png",
                "WINDOW":  self.fx.homeWidget
            },
            "CONF": {
                "TAB_NAME": "CONFIGURAÇÕES",
                "TAB_ICON": "./images/config.png",
                "WINDOW": self.configWidget
            },
            "PROC": {
                "TAB_NAME": "PROCESSOS",
                "TAB_ICON": "./images/proc.png",
                "WINDOW": self.procWidget
            },
            "CHARTS": {
                "TAB_NAME": "CHARTS",
                "TAB_ICON": "./images/stats.png",
                "WINDOW": self.fx.iniWidget
            }

        }
        self.fx.buildJanelas(self.janelas)

    def __connections(self):

        self.configPage.saveScript.clicked.connect(lambda state: self.__saveConfig())
        self.procPage.run_uatp.clicked.connect(lambda state: self.__runChileUATP("UAPT", "1387"))
        self.procPage.run_chile.clicked.connect(lambda state: self.__runChileUATP("CHILE", "1089"))

        self.procPage.run_f51.clicked.connect(lambda state: self.__runSAP())
        self.configPage.template_path.mousePressEvent = lambda event: self.fx.selectFile(event, self.configPage.template_path, filter="Microsoft Excel (*.xlsx)")
        self.procPage.stop_f51.clicked.connect(lambda state: self.comm.stop("TRUE"))

        self.procPage.chile_carteira.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.chile_carteira, filter="Microsoft Excel (*.xlsx)")
        self.procPage.chile_extrato.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.chile_extrato, filter="Microsoft Excel (*.xlsx)")

        self.procPage.uatp_detale.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.uatp_detale, filter="Microsoft Excel (*.xlsx)")
        self.procPage.uatp_patidas.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.uatp_patidas, filter="Microsoft Excel (*.xlsx)")

        self.procPage.f51_arquivo.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.f51_arquivo, self.procPage.f51_tabela,"Microsoft Excel (*.xlsx)")
        self.procPage.data_sap.mousePressEvent = lambda event: self.fx.openCalendar(self.procPage.data_sap, "dd.MM.yyyy")

        self.procPage.res_arquivo.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.res_arquivo, self.procPage.res_tabela, "Microsoft Excel (*.xlsx)")

        self.procPage.account_input.mousePressEvent = lambda event: self.fx.selectFile(event, self.procPage.account_input, self.procPage.acc_tabela, "Microsoft Excel (*.xlsx)")

        self.procPage.uatp_report.mousePressEvent = lambda event: self.fx.selectFile(event,
                                                                                       self.procPage.uatp_report,
                                                                                       self.procPage.uatp_table,
                                                                                       "Microsoft Excel (*.xlsx)")

        self.procPage.run_res_uatp.clicked.connect(lambda state: self.__restUATP())
        self.procPage.stop_uatp.clicked.connect(lambda state: self.comm.stop("TRUE"))

        self.procPage.stop_uatp.setVisible(False)
        self.procPage.stop_f51.setVisible(False)

        self.comm.stop("")



        self.procPage.export_uatp.clicked.connect(lambda state: self.__export(restituicao_uatp.Restituicao_UATP().export))
        self.procPage.export_f51.clicked.connect(lambda state: self.__export(sapComp.SAP_COMP().export))


    def __initUI(self):

        self.params = {
            "max_carteira": 30,
            "max_comb": 8,
            "tam_ref": 7,
            "max_prop": 10,
            "max_time": 15,
            "max_th": 2,
            "buscar_nome": "NÃO",
            "template_path": "",
            "user_sap": "",
            "pass_sap": "",
            "conn_sap": "",
            "user_uatp": "",
            "pass_uatp": "",
        }

        self.__connections()
        self.configPage.pass_sap.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)

        self.configPage.pass_uatp.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)

        self.configPage.busca_nome.addItems(["NÃO", "SIM"])

        self.excelTools = excelTools.ExcelTools()

        self.proc_params = self.comm.userConf()
        self.comm.textUpdate("ACCENTURE AUTOMATION FACTORY")

        if self.proc_params == None:
            self.proc_params = self.params
            self.comm.userConf(self.proc_params)


        self.__updateCONF()


        for item in self.proc_params:
            try:
                self.configWidget.findChild(QtWidgets.QWidget,item).setText(str(self.proc_params[item]))
            except:
                try:
                    self.configWidget.findChild(QtWidgets.QWidget, item).setCurrentText(str(self.proc_params[item]))
                except:
                    pass


    def __updateCONF(self):

        for item in self.params:

            if not item in self.proc_params:
                self.proc_params[item] = self.params[item]


    def __saveConfig(self):


        for item in self.proc_params:
            try:
                self.proc_params[item] = self.configWidget.findChild(QtWidgets.QWidget,item).text()
            except:
                try:
                    self.proc_params[item] = self.configWidget.findChild(QtWidgets.QWidget, item).currentText()
                except:
                    pass

        self.comm.userConf(self.proc_params)
        self.fx.msgBox("Configurações salvas com sucesso!")

    def __restUATP(self):

        self.resUATP = restituicao_uatp.Restituicao_UATP()

        payload = {
            "FX": self.resUATP.run,

            "ECHO": {
                "SPID":"1423",
                "NOME": "RESTITUIÇÃO",
                "TM": "3",
            },

            "DATA": {

                "USER": self.proc_params["user_uatp"],
                "PASSWORD": self.proc_params["pass_uatp"],
                "FILE": self.procPage.res_arquivo.text(),
                "TABLE": self.procPage.res_tabela.currentText(),
                "ACC_FILE": self.procPage.account_input.text(),
                "ACC_TABLE": self.procPage.acc_tabela.currentText(),
                "REST_FILE": self.procPage.uatp_report.text(),
                "REST_TABLE": self.procPage.uatp_table.currentText(),
                "SAP_USER": self.proc_params["user_sap"],
                "SAP_PASSWORD": self.proc_params["pass_sap"],
                "SAP_CONNECTION": self.proc_params["conn_sap"],
            }
        }
        self.items = [self.procPage.stop_uatp]

        self.fx.run(payload, begin=self.__customBegin, end=self.__customEnd)

    def __customBegin(self):

        for item in self.items:

            item.setVisible(True)

        self.fx.begin()

    def __customEnd(self):

        for item in self.items:
            item.setVisible(False)

        self.fx.end()

    def __export(self, function):

        payload = {

            "FX": function,

            "ECHO": {
                "SPID": False,
                "NOME": "Exporta",
                "TM": "10",
            },

            "DATA": {
            }
        }

        self.fx.run(payload)

    def __runSAP(self):

        self.f51 = sapComp.SAP_COMP()

        payload = {

            "FX": self.f51.run,

            "ECHO": {
                "SPID": "1347",
                "NOME": "F-51",
                "TM": "5",
            },

            "DATA": {


            "USER": self.proc_params["user_sap"],
            "PASSWORD": self.proc_params["pass_sap"],
            "CONNECTION": self.proc_params["conn_sap"],

            "FILE": self.procPage.f51_arquivo.text(),
            "TABLE":  self.procPage.f51_tabela.currentText(),

            "DATA COMP.": self.procPage.data_sap.text()
            }
        }
        self.items = [self.procPage.stop_f51]
        self.fx.run(payload, begin=self.__customBegin, end=self.__customEnd)

    def __runChileUATP(self, option, spid):

        self.filter = filter.Filter()

        payload = {

            "FX": self.filter.run,

            "ECHO": {
                "SPID": str(spid),
                "NOME": "GERADOR DE PROPOSTAS | " + str(option),
                "TM": "10",
            },

            "DATA": {

                "CARTERA": self.procPage.chile_carteira.text(),
                "EXTRACTO": self.procPage.chile_extrato.text(),

                "DETALLE": self.procPage.uatp_detale.text(),
                "PARTIDAS": self.procPage.uatp_patidas.text(),

                "MAX_CARTERA": self.proc_params["max_carteira"],
                "MAX_CARTERA_OP": self.proc_params["max_comb"],
                "MAX_REF": self.proc_params["tam_ref"],
                "MAX_TIME": self.proc_params["max_time"],
                "MAX_TH": self.proc_params["max_th"],
                "CHECK_NAME": self.proc_params["buscar_nome"],
                "MAX_PROP": self.proc_params["max_prop"],
                "PREVIEW": "FALSE",
                "OPTION": option,
                "SPID": spid
            }

        }

        self.fx.run(payload)



if __name__ == "__main__":

    if sys.platform.startswith('win'):
        # On Windows calling this function is necessary.
        multiprocessing.freeze_support()

    try:
        is_admin = os.getuid() == 0
    except AttributeError:
        is_admin = ctypes.windll.shell32.IsUserAnAdmin() != 0

    if os.getlogin() in ["tarcisio.b.prates"]: # Coloque seu EID para entrar como dev
       is_admin = True

    try:
        resultado = subprocess.run(['dotnet', '--list-sdks'], stdout=subprocess.PIPE, stderr=subprocess.PIPE,text=True)
        resultado = resultado.stdout
    except:
        resultado = False


    if not is_admin:
        alert(title='Opps!' , text='RUN AUTOMATION AS ADMINISTRATOR')

    elif not resultado:
        alert(title='Opps!' , text='Microsoft .NET cannot be located. Please check if it is installed on your machine :)')

    elif not os.path.exists("C:\\Program Files (x86)\\Excel API\\Excel API.exe"):
        alert(title='Opps!', text='The EXCEL API cannot be located. Please check if it is installed on your machine :)')

    else:

        AO = Accenture_Operations()
        AO.main()