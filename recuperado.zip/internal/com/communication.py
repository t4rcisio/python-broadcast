import datetime
import os.path
import pickle
import traceback

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
import os
import base64
from contextlib import contextmanager
from filelock import FileLock


@contextmanager
def dummy_lock():
     yield
class Commnunication:

    gpass = "ef42264841db504a2e9c4c63ad9f6ec0786d8f74"

    def __init__(self):


        try:

            with open(".\images\\com.pickle", "rb") as file:
                content = pickle.load(file)
            file.close()


            self.appName = content['APP_NAME']
            mainFolder = "C:\Automation\\"

            self.appFolder = mainFolder + self.appName
            self.tempPath = self.appFolder + "\\temp"
            self.downloadPath = self.appFolder + "\\download"
            self.dataPath = self.appFolder + "\\data"
            self.logPath = self.appFolder + "\\log"

            self.notificationsPath = self.dataPath + "\\notification.pickle"
            self.notifications()

            v = [self.__create_folder(i) for i in [mainFolder, self.appFolder, self.tempPath, self.downloadPath, self.dataPath, self.logPath]]

        except:

            self.appName = None
            self.appFolder = None
            self.tempPath = None
            self.downloadPath = None
            self.dataPath = None
            self.logPath = None

    def isRunnig(self, data=False):

        return self.__dataControl(self.dataPath + "\\isRunnig.pickle", data)

    def automationError(self, data=False):

        return self.__dataControl(self.dataPath + "\\automationError.pickle", data)

    def pagoHis(self, data=False):

        return self.__dataControl(self.dataPath + "\\pagoHis.pickle", data)

    def theme(self, data=False):

        return self.__dataControl(self.dataPath + "\\theme.pickle", data)

    def language(self, data=False):

        return self.__dataControl(self.dataPath + "\\language.pickle", data)


    def stopLoading(self, data=False):

        return self.__dataControl(self.dataPath + "\\stopLoading.pickle", data)

    def thdatactrl(self, data=False):

        return self.__dataControl(self.dataPath + "\\thdatactrl.pickle", data)

    def queueEcho(self, data=False):

        return self.__dataControl(self.dataPath + "\\queueEcho.pickle", data)

    def stop(self, data=False):

        return self.__dataControl(self.dataPath + "\\stop.pickle", data)

    def saveTempProccess(self, operation, data=False):

        return self.__dataControl(self.dataPath + "\\operation_"+str(operation)+".pickle", data)

    def textUpdate(self, data=False, operations=1):

        if data != False:
            content = {"DATA": data, "OP": operations}
        else:
            content = False

        return self.__dataControl(self.dataPath + "\\textUpdate.pickle", content)

    def execution_report(self, data=False):

        return self.__dataControl(self.dataPath + "\\execution_report.pickle", data)


    def config(self, data=False):

        return self.__dataControl(self.dataPath + "\\config.pickle", data)

    def operationsCounter(self, data=False):

        res = self.__dataControl(self.dataPath + "\\operationsCounter.pickle", data, locker=True)
        return res if (res != False and res != None) else {"ECHO": 0, "TOTAL": 0}

    def incrementOperation(self, qtd=1):

        lock = FileLock("icc" + ".lock")

        with lock:
            ops = self.operationsCounter()
            ops["ECHO"] = ops["ECHO"] + qtd
            ops["TOTAL"] = ops["TOTAL"] + qtd
            self.operationsCounter(ops)

    def userConf(self, data=False):

        return self.__dataControl(self.dataPath + "\\userConf.pickle", data)

    def notifications(self, data=False, mode="APPEND",index=0):


        queue = self.__dataControl(self.notificationsPath)
        if queue == None:
            queue = []

        if mode == "APPEND":
            if data != "" and data != False:
                queue.append([str(data), datetime.datetime.now().strftime("%d/%m %H:%M")])
                self.__dataControl(self.notificationsPath, queue)
        elif mode == "REMOVE":
            del queue.pop[index]
            self.__dataControl(self.notificationsPath, queue)
        elif mode == "CLEAR":
            queue = []
            self.__dataControl(self.notificationsPath, queue)
        else:
            return queue


        return queue



    def __create_folder(self, path):

        try:
            if not os.path.exists(path):
                os.mkdir(path)
        except:
            print(traceback.format_exc())

    def __dataControl(self, path, data=False, secure=False, replace=False, locker=False):

        lockFile = path + ".lock"

        if locker:
            lock = FileLock(lockFile)
        else:
            lock = dummy_lock()

        res = None

        try:

            with lock:
                if data != False:

                    with open(path, "wb") as file:

                        if replace:

                            res = pickle.load(file)
                            if secure:
                                res = self.__decrypt_string(res, self.gpass)

                        if secure:
                            data = self.__encrypt_string(str(data), self.gpass)

                        pickle.dump(data, file)
                        return res

                else:

                    with open(path, "rb") as file:

                        res = pickle.load(file)

                        if secure:
                            res = self.__decrypt_string(res, self.gpass)

                        return res
        except:
            return None

    def __derive_key(self, password, salt):
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        return kdf.derive(password.encode())

    def __encrypt_string(self, plaintext, password):

        salt = os.urandom(16)
        key = self.__derive_key(password, salt)
        iv = os.urandom(16)

        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()

        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(plaintext.encode()) + padder.finalize()

        ciphertext = encryptor.update(padded_data) + encryptor.finalize()

        return base64.b64encode(salt + iv + ciphertext).decode()

    def __decrypt_string(self, ciphertext, password):

        decoded_data = base64.b64decode(ciphertext)
        salt = decoded_data[:16]
        iv = decoded_data[16:32]
        ciphertext = decoded_data[32:]

        key = self.__derive_key(password, salt)
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()

        padded_data = decryptor.update(ciphertext) + decryptor.finalize()

        unpadder = padding.PKCS7(128).unpadder()
        plaintext = unpadder.update(padded_data) + unpadder.finalize()

        return plaintext.decode()


