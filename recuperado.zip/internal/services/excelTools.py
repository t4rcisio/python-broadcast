# -*- coding: utf-8 -*-
import os
import re
import subprocess
import time
import traceback

import openpyxl
import pandas as pd
import xlwings as xw
import python_calamine
from utils import broadcast
from internal.com import logControl
from python_calamine import CalamineWorkbook

class ExcelTools:


    lastPath = False
    logTools = logControl.LogControl()
    broadcast = broadcast.Broadcast()

    def loadTable_v2(self, path: str, tname: str):
        try:
            file = open(path, 'rb')
            workbook = python_calamine.CalamineWorkbook.from_filelike(file)
            rows = list(workbook.get_sheet_by_name(tname).to_python())
            headers = list(map(str, rows[0]))
            vTp = 10 ** 15

            def fix_scientific_notation(cell):

                if isinstance(cell, (int, float)):
                    if cell >= vTp:
                        return int(cell)
                    if "inf" in str(cell).upper():
                        return "INVALID VALUE - ADD ' '  ON LEFT"
                return cell


            valid_rows = [
                [fix_scientific_notation(cell) for cell in row]
                for row in rows
                if any(cell is not None and cell != '' for cell in row)
            ]

            #valid_rows = [row for row in rows if any(cell is not None and cell != '' for cell in row)]

            row_count = len(valid_rows) - 1

            def rows_generator():
                for row in rows[1:]:
                    yield row

            return headers, valid_rows, row_count
        except:

            return self.load_excel_pd(path, tname)

    def load_excel_cl(self, file_path, sheet_name):

        response = []

        try:

            with open(file_path, "rb") as f:
                wb = CalamineWorkbook.from_filelike(f)

                if isinstance(sheet_name, int):
                    sheet = wb.get_sheet_by_index(sheet_name)
                else:
                    sheet = wb.get_sheet_by_name(sheet_name)

                row_iter = sheet.iter_rows()

                while True:
                    try:
                        row = next(row_iter)
                        safe_row = []
                        for cell in row:
                            try:
                                safe_row.append(str(cell) if cell is not None else "")
                            except:
                                safe_row.append("<ERROR>")
                        response.append(safe_row)

                    except StopIteration:
                        break  # fim das linhas
                    except Exception:
                        continue

                return None, response, None
        except:
            self.logTools.addLog("ERRO", traceback.format_exc())
            return None, response, None



    def load_excel_pd(self, file_path, sheet_name, dType=None):

        try:

            if isinstance(sheet_name, int):
                    data = CalamineWorkbook.from_path(file_path)
                    data = data.get_sheet_by_index(sheet_name)
                    data = data.to_python()
                    data_frame = pd.DataFrame(data[1:], columns=data[0])

                    if dType != None:
                        data_frame = data_frame.astype(dType)
            else:
                data = CalamineWorkbook.from_path(file_path)
                data = data.get_sheet_by_name(sheet_name)
                data = data.to_python()
                data_frame = pd.DataFrame(data[1:], columns=data[0])

                if dType != None:
                    data_frame = data_frame.astype(dType)

            rows = data_frame.values.tolist()
            # Include the header as the first row
            header = data_frame.columns.tolist()
            rows.insert(0, header)

            return header, rows, len(rows)

        except:

            return self.load_excel_cl(file_path, sheet_name)

    def read_calamine(self, data):

        rows = []
        start = 0

        for index in range(start, data.total_height):
            try:
                for row in data.iter_rows():
                    rows.append(row)
            except:
                start = len(rows)
                data.start = (start, 0)
                data.to_python(nrows=500)

        return rows


    def getHeader(self, path: str, tname: str):

        headers, valid_rows, row_count = self.loadTable_v2(path, tname)

        sheetMap = {}
        for index in range(0, len(headers)):
            sheetMap[headers[index]] = index


        return sheetMap, valid_rows, row_count

    def getTableNames(self, path: str):

        file = open(path, 'rb')
        workbook = python_calamine.CalamineWorkbook.from_filelike(file)
        sheet_names = workbook.sheet_names
        return sheet_names



    def get_rowsMax(self,  path: str, tname: str) -> int:

        file = open(path, 'rb')
        workbook = python_calamine.CalamineWorkbook.from_filelike(file)  # type: ignore[arg-type]
        rows = iter(workbook.get_sheet_by_name(tname).to_python())
        next(rows)  # Pula o cabeçalho
        row_count = sum(1 for _ in rows)  # Conta as linhas restantes
        return row_count

    def loadWb(self, path, sheetName):

        try:

            if self.lastPath == False or path != self.lastPath:
                self.workbook = xw.Book(path)
                self.lastPath = path

            sheet = self.workbook.sheets[sheetName]

            return sheet
        except:
            try:
                self.workbook = xw.Book(path)
                self.lastPath = path

                sheet = self.workbook.sheets[sheetName]
                return sheet
            except:
                print(traceback.format_exc())
                return False


    def get_header(self, sheet):

        headerMap = {}
        header_range = sheet.range('1:1')
        headers = header_range.value

        index = 1
        for header in headers:

            if header != None and str(header) != '':
                headerMap[header] = index

            index +=1

        return headerMap

    def getSheetNames(self, sheet=False, path=False):

        if sheet == False:
            sheet = xw.Book(path, read_only=True)

        workbook_names = [workbook.name for workbook in sheet.sheets]
        return workbook_names


    def convert2CSV(self, excel_path, table, destPath):


        command = "C:\Program Files (x86)\Excel API\Excel API.exe"
        excel_file = os.path.normpath(excel_path)
        sheet_name = table
        output_file = os.path.normpath(destPath)
        separator = '|'

        command = command + ' "' + str(excel_file) + '"' + ' "' + str(sheet_name) + '"' + ' "' + output_file + '" "|"'

        self.logTools.addLog("COMMAND", command)
        try:
            resultado = subprocess.check_output(
                command,
                shell=False,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        except:
            self.logTools.addLog("LOG", traceback.format_exc())

    def create_or_append(self, nome_arquivo, nome_aba):
        try:
            if os.path.exists(nome_arquivo):
                workbook = openpyxl.load_workbook(nome_arquivo)
            else:
                workbook = openpyxl.Workbook()
                if "Sheet" in workbook.sheetnames:
                    workbook.remove(workbook["Sheet"])

            if nome_aba in workbook.sheetnames:
                worksheet = workbook[nome_aba]
            else:
                worksheet = workbook.create_sheet(title=nome_aba)

            worksheet["A1"] = "ACCENTURE"

            workbook.save(nome_arquivo)
            workbook.close()
            print(f"Arquivo '{nome_arquivo}' atualizado com sucesso!")

        except Exception as e:
            print(f"Ocorreu um erro: {e}")

    def saveData(self, path, table, tempFile, data, append=False):

        content = self.__buildFileEditor(data)
        self.create_or_append(path, table)

        self.saveChanges(path, table, content, tempFile)

    def saveChanges(self, excel_path, table, data, sourcePath):

        command = "C:\Program Files (x86)\Excel API\Excel API.exe"
        excel_file = os.path.normpath(excel_path)
        sheet_name = table
        output_file = os.path.normpath(sourcePath)
        separator = '|'

        open(output_file, "w", encoding="UTF-8").write(data)
        time.sleep(2)

        command = command + ' "' + str(excel_file) + '"' + ' "' + str(sheet_name) + '"' + ' "' + output_file + '" "|"'

        self.logTools.addLog("COMMAND", command)
        try:
            suresultado = subprocess.check_output(
                command,
                shell=False,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        except:
            self.logTools.addLog("LOG", traceback.format_exc())

    def __buildFileEditor(self, table):

        content = []
        pMax = len(table) - 1

        for line in range(0, len(table)):

            self.broadcast.broadcastText("GERANDO DADOS DE GRAVAÇÃO | " + str(line) + "/" + str(pMax))
            for col in range(0, len(table[line])):

                cellData = table[line][col]
                type = "text"

                if cellData != "":

                    if isinstance(cellData, float) and not bool(re.search(r'[a-zA-Z\W]', str(cellData))):
                        type = "float"
                        cellData = str(cellData).replace(".", ",")

                    elif isinstance(cellData, int) and not bool(re.search(r'[a-zA-Z\W]', str(cellData))):
                        type = "int"
                        cellData = str(cellData)
                    else:
                        type = "text"
                        cellData = str(cellData)

                    text = str(line + 1) + "|" + str(col + 1) + "|" + cellData + "|" + type + "\n"

                    content.append(text)

        return ''.join(content)


    def fixNaN(self, row):

        try:
            for index in range(0, len(row)):
                if not isinstance(row[index], list):
                    if pd.isna(row[index]):
                        row[index] = ""
        except:
            pass

        return row