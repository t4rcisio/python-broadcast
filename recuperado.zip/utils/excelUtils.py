import os
import traceback

import openpyxl
import pandas as pd
from openpyxl.reader.excel import load_workbook

from internal.com import logControl


class XlsxUtils:

    def __init__(self):

        self.logmanager = logControl.LogControl()

    def loadAlltables(self, path):

        dataMap = {}
        wb = load_workbook(path)
        for name in wb.sheetnames:
            dataMap[name] = self.loadSheet_v2(path, name)

        return dataMap

    def loadSheet_reg(self,file_path, sheet_name, template):

        res = self.loadSheet_v2(file_path, sheet_name)
        return self.regularizeData(template,res)



    def appendInfo(self, path, tableName, row, ctrl=0, wr=False):

        if wr == False:

            wb = openpyxl.load_workbook(path)
            ws = wb[tableName]

        else:
            ws = wr

        last_row = None

        for vrow in range(1, ws.max_row + 1):
            cell_value = ws[f'{"C"}{vrow}'].value
            if cell_value is not None:
                last_row = vrow + 1

        if last_row > 2 and ctrl == 1:
            rowIndex = last_row + 1
        else:
            rowIndex = last_row


        # RESPONSAVEL
        ws.cell(row=rowIndex, column=1).value = row[0]

        # ANO
        ws.cell(row=rowIndex, column=2).value = row[1]

        # RUT
        ws.cell(row=rowIndex, column=3).value = row[2]

        # FACTURA
        ws.cell(row=rowIndex, column=4).value = row[3]

        # DOC SAP
        ws.cell(row=rowIndex, column=5).value = row[4]

        # MONTO FAT
        ws.cell(row=rowIndex, column=6).value = row[5]

        # MONTO DEP
        ws.cell(row=rowIndex, column=7).value = row[6]

        # FECHA DEP
        ws.cell(row=rowIndex, column=8).value = row[7]

        # MONEDA
        ws.cell(row=rowIndex, column=9).value = row[8]

        # FORMA DE PAGO
        ws.cell(row=rowIndex, column=10).value = row[9]

        # CUENTA
        ws.cell(row=rowIndex, column=11).value = row[10]

        # MONEDA
        ws.cell(row=rowIndex, column=12).value = row[11]

        # FORMA DE PAGO
        ws.cell(row=rowIndex, column=13).value = row[12]

        # CUENTA DE BANCO
        ws.cell(row=rowIndex, column=14).value = row[13]

        # NOMBRE BANCO
        ws.cell(row=rowIndex, column=15).value = row[14]

        # ATRIBUICION
        ws.cell(row=rowIndex, column=16).value = row[15]

        # OBSERVACION
        ws.cell(row=rowIndex, column=18).value = row[17]

        # TIPO
        ws.cell(row=rowIndex, column=21).value = row[-1]


        if wr == False:
            wb.save(path)




    def loadSheet_v2(self, file_path, sheet_name):

        try:

            file_size_bytes = os.path.getsize(file_path)
            file_size_mb = file_size_bytes / (1024 * 1024)

            if str(file_path).upper().endswith(".XLSX"):

                if isinstance(sheet_name, str):
                    data_frame = pd.read_excel(file_path, sheet_name=sheet_name)
                    if isinstance(sheet_name, int):
                        data_frame = pd.read_excel(file_path, sheet_name)
                elif str(file_path).endswith(".csv"):

                    data_frame = pd.read_csv(file_path)

                    # Convert DataFrame to list of rows
                rows = data_frame.values.tolist()

                # Include the header as the first row
                header = data_frame.columns.tolist()
                rows.insert(0, header)

            return rows
        except:
            title = "Não foi possível localizar ou ler o arquivo!" + "\nFile: " + file_path + "\nFrom table: " + str(sheet_name)
            message = "Error: " + traceback.format_exc()
            self.logmanager.addLog(title, message)
            return []

    def createFile(self, path, table, name, type="XLSX"):

        df = pd.DataFrame(table)

        if type == "CSV":
            path = path.replace(".xlsx", ".csv")
            df.to_csv(path, sep='\t', encoding='utf-8')
        else:
            df.to_excel(path, index=False, header=False, sheet_name=name)


    def regularizeData(self, template, sourceData):

        self.tempData = []
        self.tempData.append(template)

        # Preenche a tabela temporária com listas vazias
        for index in range(1, len(sourceData)):
            self.tempData.append(["" for _ in range(len(template))])

        # Percorre as colunas da fonte de dados para testar correspondencia com o template
        for index in range(0, len(sourceData[0])):
            row_source = sourceData[0][index]
            self.__mergeData(template, row_source, index, sourceData)

        return self.tempData

    def __mergeData(self, template, row_source, source_index, sourceData):

        target = -1

        for index in range(0, len(template)):
            if str(template[index]).upper().strip() == str(row_source).upper().strip():
                target = index
                break

        if target == -1:
            return

        for index in range(1, len(sourceData)):
            self.tempData[index][target] = sourceData[index][source_index]

    def appendDataframe(self, path, table, name):

        if not os.path.exists(path):
            self.createFile(path, table, name)
            return

        self.__deleteSheet(path, name)

        new_df = pd.DataFrame(table)

        with pd.ExcelWriter(path, engine='openpyxl', mode='a') as writer:
            new_df.to_excel(writer, sheet_name=name, index=False, header=False)


    def __deleteSheet(self, path, name):

        wb = load_workbook(path)
        if name in wb.sheetnames:
            wb.remove(wb[name])
        wb.save(path)


    def copy_worksheetContent(self, input_filename, output_filename, source_sheet_name, new_sheet_name):
        # Load the Excel workbook
        workbook = openpyxl.load_workbook(input_filename)

        # Get the source worksheet by name
        source_sheet = workbook[source_sheet_name]

        # Create a new worksheet with a different name
        new_sheet = workbook.create_sheet(title=new_sheet_name)

        # Copy the contents of the source worksheet to the new worksheet
        for row in source_sheet.iter_rows(values_only=True):
            new_sheet.append(row)

        # Save the changes to the output file
        workbook.save(output_filename)

    def createCopy(self, source, dest):
        wb = openpyxl.load_workbook(source)
        wb.save(dest)

    def fixNaN(self, row):

        try:
            for index in range(0, len(row)):
                if not isinstance(row[index], list):
                    if pd.isna(row[index]):
                        row[index] = ""
        except:
            pass

        return row

    def loadLargeData(self, path, tableRef=0):

        if str(path).endswith(".xlsx"):

            workbook = openpyxl.load_workbook(path, read_only=True)

            if isinstance(tableRef, str):
                sheet = workbook[tableRef]
            elif isinstance(tableRef, int):
                sheet = workbook.worksheets[tableRef]
            else:
                return []

            tempTable = []

            masx = sheet.rows.gi_frame.f_locals['max_row']
            couter = 0
            for row in sheet.iter_rows(values_only=True):
                tempTable.append(list(row))
                self.logmanager.broadcast.broadcastText("LENDO ARCHIVO " + str(couter) + " de " + str(masx))
                couter +=1


            return tempTable

        elif str(path).endswith(".csv"):

            return []

            csv.field_size_limit(int(2147483647))
            tempTable = []

            with open(path, 'r', newline='', encoding='utf-8') as csvfile:
                csv_reader = csv.reader(csvfile)

                for row in csv_reader:
                    vRow = fixRow(row)
                    vRow = vRow.split(";")
                    tempTable.append(vRow)

            return tempTable
