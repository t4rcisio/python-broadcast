# -*- coding: utf-8 -*-
import time
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtWidgets import QMainWindow
from threading import Thread


class Worker(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(int)

    def setParams(self,params):

        self.params = params

    def run(self):


        try: # O PARÂMETRO FX RECEBE SUA FUNÇÃO QUE SERÁ EXECUTADA, JA DATA RECEBE OS PARÂMETROS DA FUNÇÃO

            if not "DATA" in self.params or self.params["DATA"] == {} or self.params["DATA"] == None:
                self.app = Thread(target=self.params["FX"])
                self.app.start()
            else:
                self.app = Thread(target=self.params["FX"], args=(self.params["DATA"],))
                self.app.start()
        except:
            self.progress.emit(1)
            self.finished.emit()
            return


        while (self.app.is_alive()):

            time.sleep(1)
            self.progress.emit(1)

        self.finished.emit()


class ThreadService(QMainWindow):

    def end(self):

        self.endApp()

    def runUpdate(self):

        self.running()


    def startThread(self, params, beginApp, endApp, running):

        self.thread = QThread()

        self.beginApp = beginApp
        self.endApp = endApp
        self.running = running

        self.tempCount = 0


        self.worker = Worker()
        self.worker.setParams(params)
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.progress.connect(self.runUpdate)

        self.beginApp()
        self.thread.start()
        self.thread.finished.connect(self.end)
