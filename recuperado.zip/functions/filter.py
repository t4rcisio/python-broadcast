import copy
import datetime
import multiprocessing
import os.path
import shutil
import time
import traceback
from multiprocessing import Process

import openpyxl
import pandas as pd
import psutil

from internal.services import echo
from utils import excelUtils, broadcast, tools, excelTools

from internal.com import communication, logControl

ECHO_PATH = "C:\Program Files (x86)\Echo API\echo-api.exe"


def set_cpu_affinity(process, cpu_index):

    try:
        p = psutil.Process(process.pid)
        p.cpu_affinity([cpu_index])
    except Exception as e:
        print(f"Erro ao configurar afinidade da CPU: {e}")

def vsr(args, outputFile, th, lock, progresso, isRunning):

    process = psutil.Process(os.getpid())
    process.nice(psutil.REALTIME_PRIORITY_CLASS)
    ab = Filter()
    ab.rsProc(args, outputFile, th, lock, progresso, isRunning)


def uatp(args, index, path, lock, progresso, isRunning):

    try:
        process = psutil.Process(os.getpid())
        process.nice(psutil.REALTIME_PRIORITY_CLASS)
        ab = Filter()
        ab.runUATP(args, index, path, lock, progresso, isRunning)
    except:
        print(traceback.format_exc())


def monitor_progresso(progressos, used_range, isRunning):

    comm = communication.Commnunication()
    counter = 0
    lastCount = []
    while not all(x.value == 0 for x in isRunning):
        time.sleep(0.5)
        counter = 0

        for i, progresso in enumerate(progressos):
            counter +=progresso.value

        if counter >= used_range:
            time.sleep(1)
            break

        comm.textUpdate("PROCESSANDO DADOS | ANALIZANDO COMBINAÇÕES " + str(counter) + "/" + str(used_range) + " | " + str(round(((counter / used_range) * 100), 2)) + "%", counter)
        comm.thdatactrl([counter, used_range])
        lastCount = [counter, used_range]

    try:
        comm.notifications(str(lastCount[0]) + " COMBINAÇÕES TESTADAS | " + str(round(((counter / used_range) * 100), 2)) + "%")
    except:
        pass


class Filter:

    def __init__(self, brds=False):

        self.exceltools = excelUtils.XlsxUtils()
        self.broadcast = brds if brds != False else broadcast.Broadcast()
        self.tools = tools.Utils()
        self.logTools = logControl.LogControl()
        self.echo = echo.Echo()
        self.excel = excelTools.ExcelTools()

    def run(self, args):

        self.comm = communication.Commnunication()
        self.logTools.addLog("REG", f"Operation started by "+ str(os.getlogin()))
        self.masterCount = 0
        self.broadcast.threadEN("")

        try:
            self.masterCount = 0
            self.logTools.addLog("REG", "START")
            self.__run(args)
        except:
            vText = str(traceback.format_exc()).split("\n")[-2]
            message = "SE PRODUJO UN ERROR DURANTE LA EJECUCIÓN<br>" + vText + "..."
            self.comm.textUpdate(message)
            self.comm.notifications(message)
            self.logTools.addLog("ERRO", traceback.format_exc(), True)
            self.comm.notifications("FINALIZADO | OCORREU UM ERRO")
            #subprocess.call(ECHO_PATH + " ERRO  1089 " + str(traceback.format_exc()), shell=False)

        if self.echo.delta != None:

            total_seconds = self.echo.delta.total_seconds()

            hours = int(total_seconds // 3600)
            minutes = int((total_seconds % 3600) // 60)
            seconds = int(total_seconds % 60)

            # Resultado formatado
            if hours > 0:
                msg = f"Tempo de execução: {hours}h, {minutes}m e {seconds}s."
            elif minutes > 0:
                msg = f"Tempo execução: {minutes}m e {seconds}s."
            else:
                msg = f"Tempo execução: {seconds}s."

            self.logTools.addLog("REGISTRO", msg)
            self.comm.notifications(msg)

    def __run(self, args):

        self.comm.textUpdate("INICIALIZANDO RECURSOS")
        self.timeCtrl = datetime.datetime.now()

        carteraPath = args["CARTERA"]
        extractoPath = args["EXTRACTO"]
        detallePath = args["DETALLE"]
        partidasPath = args["PARTIDAS"]

        try:
            if isinstance(args['MAX_TH'], int):
                self.maxTH = args['MAX_TH']
            else:
                self.maxTH = int(args['MAX_TH'])
        except:
            self.maxTH = 1




        self.maxCartera = args["MAX_CARTERA"]
        self.maxCombinaciones = args["MAX_CARTERA_OP"]
        self.maxProp = args["MAX_PROP"]

        self.maxRef = args["MAX_REF"]
        self.checkName = args["CHECK_NAME"]

        self.preview = args["PREVIEW"]
        self.bancoMap = False
        self.negocioMap = False

        self.outputFile = self.broadcast.homePath()["TEMP"] + "/" + self.tools.getDate() + ".xlsx"
        self.tools.deleteFile(self.outputFile)

        if args["OPTION"] == "CHILE":
            self.chile_script(args, carteraPath, extractoPath)
        else:
            self.uatp_script(args, detallePath, partidasPath)


    def uatp_script(self, args, detallePath, partidasPath):

        if not os.path.exists(detallePath):
            message = "EL ARCHIVO '" + str(os.path.basename(detallePath)) + "' NO FUE ENCONTRADO"
            self.comm.notifications(message)
            self.broadcast.broadcastText(message)
            self.logTools.addLog("ERRO", message)
            return

        if not os.path.exists(partidasPath):
            message = "EL ARCHIVO '" + str(os.path.basename(partidasPath)) + "' NO FUE ENCONTRADO"
            self.comm.notifications(message)
            self.broadcast.broadcastText(message)
            self.logTools.addLog("ERRO", message)
            return

        if not os.path.exists(self.broadcast.template()):
            message = "EL ARCHIVO '" + str(os.path.basename(self.broadcast.template())) + "' NO FUE ENCONTRADO"
            self.comm.notifications(message)
            self.broadcast.broadcastText(message)
            self.logTools.addLog("ERRO", message)
            return

        self.__ajustParams()


        dataClientes = self.exceltools.loadSheet_v2(self.broadcast.template(), "CLIENTES")

        if len(dataClientes) == 0:
            message = "NO SE PUEDE LOCALIZAR LA TABLA DE CLIENTES"
            self.comm.notifications(message)
            self.broadcast.broadcastText(message)
            self.logTools.addLog("ERRO", message)
            return


        self.clientKey = {}
        self.__mapClientes(dataClientes)


        if len(self.clientKey) == 0:
            message = "NO SE PUEDE ASIGNAR LA TABLA DE CLIENTES"
            self.comm.notifications(message)
            self.broadcast.broadcastText(message)
            self.logTools.addLog("ERRO", message)
            return


        _, dataDetalle, __ = self.excel.loadTable_v2(detallePath, 0)


        templateDetalle = self.exceltools.loadSheet_v2(self.broadcast.template(), "CARTERA UATP")[0]
        dataDetalle = self.exceltools.regularizeData(templateDetalle, dataDetalle)

        self.detalleMap = {}
        self.__mapDetalle(dataDetalle)

        if len(self.detalleMap) == 0:
            message = "FALHA AO MONTAR A CARTEIRA. VERIFIQUE O TEMPLATE."
            self.comm.notifications(message)
            self.broadcast.broadcastText(message)
            self.logTools.addLog("ERRO", message)
            return


        _, dataPart, __ = self.excel.loadTable_v2(partidasPath, 0)
        paTemplate  = self.exceltools.loadSheet_v2(self.broadcast.template(), "PARTIDAS")[0]
        dataPartidas = self.exceltools.regularizeData(paTemplate, dataPart)

        pastidasMap = self.__mapPartidas(dataPartidas)

        #depMapSplited = self.split_dict(self.detalleMap, 4)

        target = {
            "TEXTO": pastidasMap["0"][0].index('Texto'),
            "SOC": pastidasMap["0"][0].index('Empresa'),
            "CUR": pastidasMap["0"][0].index('Código da moeda do documento'),
            "DATE": pastidasMap["0"][0].index('Data do documento'),
            "MONTO": pastidasMap["0"][0].index('Valor em moeda do documento')

        }

        for key in self.detalleMap:

            rut, soc, cur = str(key).split("#")

            lkey = soc + "#" + cur

            if lkey in pastidasMap:

                partidas = pastidasMap[lkey]

                for index in range(0, len(partidas)):

                    partidas[index] = self.exceltools.fixNaN(partidas[index])

                    kDate = self.tools.fixDate(self.detalleMap[key]["DATE"])
                    vText = str(partidas[index][target["TEXTO"]]).upper().strip()
                    vDate = self.tools.fixDate(str(partidas[index][self.detalleMap["DATE"]]).upper().strip())

                    if vDate >= kDate:

                        if rut in vText.upper():
                            self.detalleMap[key]["PARTIDAS"].append(copy.copy(partidas[index]))

        procs = []
        paths = []
        progressos = []
        lock = multiprocessing.Value('i', 0)
        isRunning = []

        for index in range(0, 4):

            progresso = multiprocessing.Value('i', 0)
            progressos.append(progresso)

            isRunning.append(multiprocessing.Value('i', 1))

            paths.append(self.outputFile.replace(".xlsx", '_' + str(index) + ".xlsx"))
            self.tools.deleteFile(paths[index])

            self.broadcast.dataTh(index, {"map": "", "partidas": pastidasMap})

            procs.append(Process(target=uatp, args=(args, index, paths[index], lock, progresso, isRunning[-1], )))
            self.logTools.addLog("REGISTER", "THREAD " + str(index) + " STARTED")

        monitor_proc = multiprocessing.Process(target=monitor_progresso, args=(progressos, len(self.detalleMap), isRunning,))
        monitor_proc.start()

        index = 0
        for proc in procs:
            proc.start()
            set_cpu_affinity(proc, index)
            index += 1

        timeout = int(args["MAX_TIME"]) * 60
        for proc in procs:

            proc.join(timeout)
            timeout = 0

            if proc.is_alive():
                proc.kill()
                proc.join()

            self.logTools.addLog("REGISTRO","Tempo limite atingido. Processo " + str(procs.index(proc)) + " finalizado")
            time.sleep(1)

        try:
            monitor_proc.kill()
        except:
            pass

        progressos[-1].value = len(self.detalleMap)

        self.broadcast.broadcastTextCtrl_clear()
        time.sleep(1)
        self.broadcast.broadcastText("MESCLANDO RESULTADOS")
        self.mergeFiles(paths, "UATP")
        self.broadcast.payload({})

    def runUATP(self, args, th, path, lock, progresso, isRunning):
        self.comm = communication.Commnunication()
        self.broadcast.threadEN("RUNNING")

        thData = self.broadcast.dataTh(th)

        detMap = thData["map"]
        pastidasMap = thData["partidas"]


        self.outputFile = path
        self.masterCount = 0
        self.maxCartera = int(args["MAX_CARTERA"])
        self.maxCombinaciones = int(args["MAX_CARTERA_OP"])
        self.maxRef = int(args["MAX_REF"])
        self.checkName = args["CHECK_NAME"]
        self.preview = args["PREVIEW"]
        self.maxProp = int(args["MAX_PROP"])
        self.bancoMap = False
        self.negocioMap = False
        self.timeCtrl = datetime.datetime.now()

        self.__checkNegocionName(False)


        target = {
            "TEXTO": pastidasMap["0"][0].index('Texto'),
            "SOC": pastidasMap["0"][0].index('Empresa'),
            "CUR": pastidasMap["0"][0].index('Código da moeda do documento'),
            "DATE": pastidasMap["0"][0].index('Data do documento'),
            "MONTO": pastidasMap["0"][0].index('Valor em moeda do documento')

        }
        templateDetalle = self.exceltools.loadSheet_v2(self.broadcast.template(), "CARTERA UATP")[0]
        monto_cart = templateDetalle.index('Valor em moeda do documento')

        #self.broadcast.tempData(detMap)

        try:
            self.runAlgotihmUATP(path, monto_cart, target, lock, progresso, th)
        except:
            self.logTools.addLog("UATP ERRO TH:" + str(th), traceback.format_exc())

        isRunning.value = 0


    def runAlgotihmUATP(self, path, monto_cart, target, lock, progresso, th):

        counter = 0
        cont = True
        detMap = {}

        while cont:


            msdata = self.broadcast.payloadQueue()

            if msdata == "FIM":
                #print(th, "FIM - FILA VAZIA")
                lock.value = 0
                break
            else:
                key = msdata[0]
                detMap[key] = msdata[1]
                lock.value = 0

            if  key != None:

                progresso.value += 1
                self.maxTime = datetime.datetime.now()

                if len(detMap[key]["PARTIDAS"]) > 0:

                    zCounter = 1
                    for row in detMap[key]["PARTIDAS"]:

                        vtarget = self.tools.convert2float(row[target["MONTO"]])
                        cartera = detMap[key]["DETALLE"]

                        if self.__checkNegative(cartera, monto_cart):

                            response = self.sums_less_than(vtarget, cartera[:self.maxCartera], monto_cart)

                            if len(response) > 0:
                                self.__filldata(row, response, detMap[key]["MODE"], path, vtarget, monto_cart, mode="UATP")
                                self.comm.incrementOperation(1)

                        zCounter += 1
                    counter += 1

    def chile_script(self, args, carteraPath, extractoPath):

        self.comm.textUpdate("CARREGANDO DADOS")
        self.broadcast.template(self.comm.userConf()["template_path"])

        if not os.path.exists(carteraPath):
            message = "EL ARCHIVO '"+str(os.path.basename(carteraPath))+"' NO FUE ENCONTRADO"
            self.comm.notifications(message)
            self.comm.textUpdate(message)
            self.logTools.addLog("ERRO", message)
            return

        if not os.path.exists(extractoPath):
            message = "EL ARCHIVO '"+str(os.path.basename(extractoPath))+"' NO FUE ENCONTRADO"
            self.comm.notifications(message)
            self.comm.textUpdate(message)
            self.logTools.addLog("ERRO", message)
            return

        if not os.path.exists(str(self.broadcast.template())):
            message = "EL ARCHIVO '"+str(os.path.basename(self.broadcast.template()))+"' NO FUE ENCONTRADO"
            self.comm.notifications(message)
            self.comm.textUpdate(message)
            self.logTools.addLog("ERRO", message)
            return


        self.__ajustParams()


        templates = self.exceltools.loadAlltables(self.broadcast.template())

        if len(templates) == 0:
            message = "NO SE PUEDE ABRIR EL ARCHIVO TEMPLATE"
            self.comm.notifications(message)
            raise OSError(message)

        headers, cartTemp, row_count = self.excel.load_excel_pd(carteraPath, 0, {"REFERENCIA": str})

        if not self.checkCartera(cartTemp):
            message = "LAS COLUMNAS DEL CARTERA SON NO ESTÁNDAR"
            self.comm.notifications(message)
            raise OSError(message)


        dataCartera  = self.exceltools.regularizeData(templates["CARTERA"][0], cartTemp)

        if len(dataCartera) == 0:
            message = "NO SE PUEDE ABRIR EL ARCHIVO CARTERA"
            self.comm.notifications(message)
            raise OSError(message)


        _, dataExtract_temp, __ = self.excel.load_excel_pd(extractoPath, 0)

        if dataExtract_temp == None or dataExtract_temp == []:
            message  = "NO SE PUEDE ABRIR EL ARCHIVO "+ os.path.basename(extractoPath)
            self.comm.notifications(message)
            raise OSError(message)

        self.comm.textUpdate("MONTANDO CONJUNTOS DE DADOS")

        dataExtract = self.__fixExtract(dataExtract_temp)

        if len(dataExtract) == 0:
            message = "NO SE PUEDE ABRIR EL ARCHIVO EXTARCTO"
            self.comm.notifications(message)
            raise OSError(message)

        self.broadcast.broadcastText("")
        rutMap = self.__mergeData(dataCartera, 0)

        if len(rutMap) == 0:
            message = "COLUNAS COM DADOS VAZIOS NA CARTEIRA | VERIFIQUE O INPUT"
            self.comm.notifications(message)
            raise OSError(message)

        rutSplited = self.split_dict(rutMap, self.maxTH)

        self.comm.thdatactrl([0, len(rutMap)])

        self.comm.textUpdate("MESCLANDO DADOS")
        rutMap = self.__mergeData_rut3(rutMap, dataCartera, dataExtract, self.maxRef, 0)

        if len(rutMap) == 0:
            message = "NÃO FOI POSSÍVEL MESCLAR A CARTEIRA E EXTRACTO. VERIFIQUE AS COLUNAS CHAVE"
            self.comm.notifications(message)
            raise OSError(message)

        #self.teste(rutMap)

        self.broadcast.payload(rutMap)

        self.comm.textUpdate("INICIALIZANDO THREADS")

        procs = []
        paths = []
        progressos = []
        lock = multiprocessing.Value('i', 0)
        isRunning = []

        for index in range(0, len(rutSplited)):

            progresso = multiprocessing.Value('i', 0)
            progressos.append(progresso)

            isRunning.append(multiprocessing.Value('i', 1))

            paths.append(self.outputFile.replace(".xlsx", '_' + str(index) + ".xlsx"))
            self.tools.deleteFile(paths[index])

            self.broadcast.dataTh(index, {"rut": None, "extract": dataExtract, "carteira": dataCartera })
            procs.append(multiprocessing.Process(target=vsr, args=(args, paths[index],  index, lock, progresso, isRunning[-1], )))

            self.logTools.addLog("REGISTER", "THREAD " + str(index) + " STARTED")

        monitor_proc = multiprocessing.Process(target=monitor_progresso, args=(progressos, len(rutMap), isRunning, ))
        monitor_proc.start()

        index = 0
        for proc in procs:
            proc.start()
            set_cpu_affinity(proc, index)
            index +=1
            time.sleep(1)

        timeout = int(args["MAX_TIME"])*60
        for proc in procs:

            proc.join(timeout)
            timeout = 0

            if proc.is_alive():
                proc.kill()
                proc.join()
                self.logTools.addLog("REGISTRO", "Tempo limite atingido. Processo " + str(procs.index(proc)) + " finalizado")

            time.sleep(1)
            self.broadcast.payload({})
        try:
            monitor_proc.kill()
        except:
            pass

        progressos[-1].value = len(rutMap)

        self.broadcast.broadcastTextCtrl_clear()
        time.sleep(1)
        self.comm.textUpdate("MESCLANDO PROPOSTAS")
        self.mergeFiles(paths, "CHILE")
        self.broadcast.payload({})


    def teste(self, rutMap):

        for key in rutMap:
            X = [row[25] for row in rutMap[key]["CARTERA"]]
            Y = [row[2] for row in rutMap[key]["EXTRACTO"]]

            resultado = self.encontrar_combinacoes(X, Y)
            #print(resultado)

    def encontrar_combinacoes(self, X, Y):
        from functools import lru_cache

        # Criar um conjunto de Y para busca rápida
        Y_set = set(Y)
        resultados = set()

        # Memoization para evitar recomputação
        memo = set()

        def backtrack(index, soma_atual):
            if soma_atual in Y_set:
                resultados.add(soma_atual)
            if index >= len(X) or soma_atual in memo:
                return
            memo.add(soma_atual)

            # Tentar incluir ou não incluir X[index]
            backtrack(index + 1, soma_atual)  # Sem incluir X[index]
            backtrack(index + 1, soma_atual + X[index])  # Incluindo X[index]

        backtrack(0, 0)
        return resultados



    def __mapPartidas(self, partidas):


        partidasMap = {}

        target = {
            "TEXTO": partidas[0].index('Texto'),
            "SOC": partidas[0].index('Empresa'),
            "CUR": partidas[0].index('Código da moeda do documento'),
            "DATE": partidas[0].index('Data do documento'),
            "MONTO": partidas[0].index('Valor em moeda do documento')

        }

        pkConcat = self.exceltools.loadSheet_v2(self.broadcast.template(), "CONCAT")

        columns = []
        for pk in pkConcat:

            if pk[0] in partidas[0]:
                columns.append(partidas[0].index(pk[0]))


        partidasMap["0"] = [partidas[0]]

        for index in range(1, len(partidas)):

            partidas[index] = self.exceltools.fixNaN(partidas[index])

            vSoc = str(partidas[index][target["SOC"]]).upper().strip()
            vCur = str(partidas[index][target["CUR"]]).upper().strip()

            partidas[index][target["TEXTO"]] = self.__fixText(columns, target["TEXTO"], partidas[index])

            key = vSoc + "#" + vCur

            if key in partidasMap:

                partidasMap[key].append(partidas[index])

            else:

                partidasMap[key] = []
                partidasMap[key].append(partidas[index])

        return partidasMap


    def __fixText(self, columns, textIndex, row):

        ztext = str(row[textIndex]) + " "

        for index in columns:

            ztext += str(row[index]) + " "

        return str(ztext).strip()


    def __mapClientes(self, data):

        target ={
            "RUT DRIVE": data[0].index('RUT DRIVE'),
            "BP": data[0].index('BP'),

        }

        for index in range(1, len(data)):

            row = self.exceltools.fixNaN(data[index])

            key = str(row[target["BP"]]).replace("-", "").replace(" ", "")
            rut = str(row[target["RUT DRIVE"]]).replace("-", "").replace(" ", "")

            if key != "":
                self.clientKey[key] = rut


    def __mapDetalle(self, detalle):

        target = {
            "SOC" : detalle[0].index("Empresa"),
            "RUT" : detalle[0].index("RUT"),
            "DATE": detalle[0].index("Data do documento"),
            "CUR" : detalle[0].index("Código da moeda do documento"),
            "MONTO": detalle[0].index("Valor em moeda do documento"),
            "BP": detalle[0].index("Cliente"),
        }

        if 'Data do documento.1' in detalle[0]:
            target["DATE 2"] = detalle[0].index('Data do documento.1')



        for index in range(1, len(detalle)):

            row = self.exceltools.fixNaN(detalle[index])

            bp = str(row[target["BP"]]).replace(" ", "")

            if bp in self.clientKey:


                rut = self.clientKey[bp]
                row[target["RUT"]] = rut

                soc = str(row[target["SOC"]]).replace(" ", "")
                date = str(self.tools.fixDate(row[target["DATE"]]))
                cur = str(row[target["CUR"]]).replace(" ", "")

                if date == "":
                    if "DATE 2" in target:
                        date = str(self.tools.fixDate(row[target["DATE 2"]]))



                if soc != "" and rut != "" and cur != "":

                    key = rut + "#" + soc + "#" + cur

                    dataObject = {"PARTIDAS": [], "DETALLE": [], "REF": [], "MODE": 'TRANSFERENCIA', "DATE": ""}
                    self.__mapManager(self.detalleMap, key, row, key, date, vtarget="DETALLE", defObject=dataObject)


    def mergeFiles(self, paths, op):

        data = {
            "1x1": [],
            "1xN": []
        }
        destPath = self.broadcast.homePath()["TEMP"] + "/" + self.tools.getDate() + ".xlsx"
        self.masterCount = 0
        self.tools.deleteFile(destPath)


        if not os.path.exists(destPath):

            shutil.copyfile("./images/Resultados.xlsx", destPath)

        wb = openpyxl.load_workbook(destPath)

        dataCtrl = {}
        zCounter = 1
        for path in paths:

            self.comm.textUpdate("MESCLANDO PROPOSTAS | " + str(zCounter) + " de " + str(len(paths)))

            n1 = self.exceltools.loadSheet_v2(path, "1x1")
            nn = self.exceltools.loadSheet_v2(path, "1xN")

            if len(n1) >= 2:

                for row in n1[1:]:

                    row = self.exceltools.fixNaN(row)
                    data["1x1"].append(row)
                    self.exceltools.appendInfo(destPath, "1x1", row, ctrl=1, wr=wb["1x1"])
                    dataCtrl[str(row)] = row
                    self.masterCount += 1

            if len(nn) >= 2:

                if not str(nn[-1]) in dataCtrl:

                    for row in nn[1:]:

                        row = self.exceltools.fixNaN(row)
                        data["1xN"].append(row)
                        self.exceltools.appendInfo(destPath, "1xN", row, wr=wb["1xN"])

                        if row[6] != "":

                            self.masterCount += 1
                            emptyRow = [" " for i in nn[0]]
                            emptyRow[-1] = "_"
                            data["1xN"].append(emptyRow)
                            self.exceltools.appendInfo(destPath, "1xN", emptyRow, wr=wb["1xN"])


            zCounter +=1

        wb.save(destPath)
        res = self.__saveFile(destPath, "CONSOLIDADO")

        if res == False:
            res = "NENHUMA COMBINAÇÃO ENCONTRADA"

        else:
            "SALVO EM: " + res

        self.broadcast.broadcastText("PROCESSAMENTO CHILE | " + res)

        self.comm.notifications(op + " | " + res)
        self.comm.notifications(op + " | " + str(self.masterCount) + " PROPOSTAS GERADAS")

    def rsProc(self, args, path, th, lock, progresso, isRunning):

        self.comm = communication.Commnunication()
        self.broadcast.threadEN("RUNNING")
        self.broadcast.dataFCmm(th, "RUNNING")
        thData = self.broadcast.dataTh(th)

        rutMap = thData["rut"]
        dataExtract = thData["extract"]
        dataCartera = thData["carteira"]

        self.outputFile = path
        self.masterCount = 0
        self.maxCartera = int(args["MAX_CARTERA"])
        self.maxCombinaciones = int(args["MAX_CARTERA_OP"])
        self.maxRef = int(args["MAX_REF"])
        self.checkName = args["CHECK_NAME"]
        self.preview = args["PREVIEW"]
        self.maxProp = int(args["MAX_PROP"])
        self.bancoMap = False
        self.negocioMap = False
        self.timeCtrl = datetime.datetime.now()
        self.dMap = {}

        self.tools.deleteFile(path)
        shutil.copyfile("./images/Resultados.xlsx", path)

        importeIndex = dataCartera[0].index('IMPORTE DOC#')

        try:
            self.__rutAlgorithm(rutMap, importeIndex, path, th, lock, progresso)
        except:
            self.logTools.addLog("CHILE ERRO TH:"+str(th), traceback.format_exc())

        isRunning.value = 0


    def __ajustParams(self):

        vText = "COMPROBAR QUE LOS PARÁMETROS DE ENTRADA"
        try:

            vText = 'EL PARÁMETRO MAX CARTERA DEBE SER MAS GRANDE IGUAL QUE 1'
            self.maxCartera = int(self.maxCartera)
            if self.maxCartera <= 0:
                raise OSError(vText)

            vText = 'EL PARÁMETRO MAX CARTERA DEBE SER MAS GRANDE IGUAL QUE 1'
            self.maxCombinaciones = int(self.maxCombinaciones)
            if self.maxCombinaciones <= 0:
                raise OSError(vText)

            vText = 'EL PARÁMETRO MAX REF DEBE SER MAS GRANDE IGUAL QUE 0'
            self.maxRef = int(self.maxRef)
            if self.maxRef <= 0:
                raise OSError(vText)

            vText = 'EL PARÁMETRO MAX PROPUESTAS DEBE SER MAS GRANDE IGUAL QUE 0'
            self.maxProp = int(self.maxProp)
            if self.maxProp <= 0:
                raise OSError(vText)

        except:
            raise OSError(vText)






    def split_list(self, header, input_list, n):
        # Calculate the number of items per part
        avg_len = len(input_list) / float(n)
        chunks = []
        last = 0.0

        while last < len(input_list):
            chunks.append(input_list[int(last):int(last + avg_len)])
            last += avg_len

        for index in range(0, len(chunks)):
            chunks[index].insert(0, header)

        return chunks

    def split_dict(self, input_dict, n):
        # Get list of keys and values
        items = list(input_dict.items())

        # Calculate the number of items per part
        avg_len = len(items) / n
        chunks = []
        last = 0.0

        while last < len(items):
            chunks.append(dict(items[int(last):int(last + avg_len)]))
            last += avg_len

        return chunks

    def __checkSize(self, rutMap):

        lSize = {}

        for key in rutMap:

            pSize = len(rutMap[key]["CARTERA"])

            if len(rutMap[key]["EXTRACTO"]) >= 1:
                if pSize in lSize:
                    lSize[pSize] = lSize[pSize] + len(rutMap[key]["EXTRACTO"])
                else:
                    lSize[pSize] = len(rutMap[key]["EXTRACTO"])

        v = list(lSize.keys())
        v.sort()
        zData = []

        for item in v:

            zData.append([item, lSize[item]])

        x = [item[0] for item in zData]
        y = [item[1] for item in zData]

        self.broadcast.chart({"X": x, "Y": y})
        self.broadcast.broadcastText("PROCESO TERMINADO")


    def __saveFile(self, path, th):

        fileName = os.path.basename(path)

        outputPath = "C:\\Users\\"+ os.getlogin() + "\\Downloads\\PROPUESTAS_DE_COMPENSACIÓN_"+str(th)+"_" + fileName

        self.tools.deleteFile(outputPath)

        if os.path.exists(path):

            shutil.copyfile(path, outputPath)
            out = os.path.basename(outputPath)
            return out
        else:
            return False

    def __rutAlgorithm(self, rutMap, importeIndex, path, th, lock,  progresso):


        counter = 0
        cont = True
        rutMap = {}
        self.sbMap = {}

        while cont:


            msdata = self.broadcast.payloadQueue()

            if msdata == "FIM":
                #print(th, "FIM - FILA VAZIA")
                lock.value = 0
                break
            else:
                rut = msdata[0]
                rutMap[rut] = msdata[1]
                lock.value = 0

            #print("THREAD (" + str(th) + ") está processando o RUT: " + str(rut))


            if rut != None:

                self.maxTime = datetime.datetime.now()

                progresso.value += 1
                zCounter = 1
                for row in rutMap[rut]["EXTRACTO"]:

                    target = self.tools.convert2float(row[2])

                    if isinstance(target, float):

                        cartera = rutMap[rut]["CARTERA"]

                        if self.__checkNegative(cartera, importeIndex):

                            response = self.sums_less_than(target, cartera[:self.maxCartera], importeIndex)

                            if len(response) > 0:
                                self.__filldata(row, response, rutMap[rut]["MODE"], path, target, importeIndex)
                                self.comm.incrementOperation(1)


                    zCounter +=1

                counter +=1

                #print("THREAD (" + str(th) + ") finalizou o RUT: " + str(rut))


    def __checkResponse(self, combination, target, importeIndex):

        if abs(combination[-1][importeIndex]) == abs(target):
            return False
        else:
            return True



    def __checkNegative(self, cartera, importeIndex):

        response = False

        for row in cartera:

            if row[importeIndex] > 0:
                response = True

        return response


    def __filldata(self, rowExtract, rowCartera, fPago, path, target, importeIndex, mode=False):



        if mode != False:

            writeRor = self.__buidRowUATP
            yearCol = 2

        else:
            writeRor = self.__buidRow
            yearCol = 19

        if not os.path.exists(path):

            shutil.copyfile("./images/Resultados.xlsx", path)

        for combination in rowCartera:

            sb = self.tools.fixFloat2Str(rowExtract[9])

            if sb in self.sbMap:
                continue
            else:
                self.sbMap[sb] = ""

            if mode != False:
                self.comment = "UATP"
            else:
                self.comment = "CHILE"


            control = 0

            if len(combination) == 1:
                if self.__checkNegative(combination, importeIndex):
                    self.masterCount +=1

                    row = writeRor(combination[0], rowExtract, fPago)
                    self.exceltools.appendInfo(path, "1x1", row, control)
                    control = 0

            cont = 0
            if len(combination) > 1:

                if self.__checkNegative(combination, importeIndex):

                    if self.__checkSum(combination, importeIndex, yearCol):

                        self.masterCount += 1

                        if self.__checkResponse(combination, target, importeIndex):

                            for rCart in combination[:-1]:
                                row = writeRor(rCart, rowExtract, fPago, True)
                                self.exceltools.appendInfo(path, "1xN", row, control)
                                control = 0



                            row = writeRor(combination[-1], rowExtract, fPago)
                            self.exceltools.appendInfo(path, "1xN", row)


    def __checkSum(self, combination, importeIndex, yCol):

        sum = 0
        for row in combination:

            sum +=row[importeIndex]


        yData = {}
        for row in combination:
            if row[yCol] != "":
                yData[row[yCol]] = ""

        if len(yData) > 0:
            self.comment = "Propostas com Anos diferentes"


        if sum < 0:
            return False

        else:
            return True



    def __buidRow(self, dataCartera, dataExtracto, fPago, n=False):


        data = [
            dataCartera[45],     # ANALISTA     <- RESPONSAVEL
            dataCartera[19],     # ANO FAC      <- ANO DOC
            dataCartera[5],      # RUT/DNI      <- NMRO BP
            dataCartera[3],      # DOC PAGA     <- REFERENCIA
            dataCartera[1],      # NRO DOC SAP  <- NRO DOCUMENTO
            dataCartera[25],     # MONTO FAC    <- IMPORT DOC

            self.tools.convert2float(dataExtracto[2]) if n == False else "",  # MONTO DEP
            self.tools.date2str(dataExtracto[3]) if n == False else "",                            # FECHA DE DEP      <- DATA DOC
            dataExtracto[5],                                                  # MONEDA            <- NMRO BP
            fPago if n == False else "",                                      # FORMA DE PAGO     <- REFERENCIA

            dataExtracto[6] if n == False else "",                          # CONTA DE BANCO    <- CTA MAYOR
            self.__checkBancName(dataExtracto[6]) if n == False else "",    # NOMBRE BANCO      <- MAP SUPORTE

            dataExtracto[8] if n == False else "",                                                      # ATRIBUIÇÃO        <- ATRIBUIÇÃO
            dataExtracto[9] if n == False else "",                                                      # DOC SBP           <- Nº DOC
            self.__checkNegocionName(dataCartera[8]),                                                                     # NEGOCIO  <- NEGOCIO
            dataCartera[0] if dataCartera[0] == dataExtracto[11] else "" if n == False else "",   # SOCIEDAD    <- SOCIENDAD
            "",
            self.comment,
            dataCartera[-1]
        ]

        return data


    def __buidRowUATP(self, dataCartera, dataExtracto, fPago, n=False):


        data = [
            dataCartera[28],     # ANALISTA     <- RESPONSAVEL
            dataCartera[2],     # ANO FAC      <- ANO DOC
            dataCartera[3],      # RUT/DNI      <- NMRO BP
            dataCartera[10],      # DOC PAGA     <- REFERENCIA
            dataCartera[9],      # NRO DOC SAP  <- NRO DOCUMENTO
            dataCartera[24],     # MONTO FAC    <- IMPORT DOC

            self.tools.convert2float(dataExtracto[9]) if n == False else "",  # MONTO DEP
            self.tools.date2str(dataExtracto[5]) if n == False else "",       # FECHA DE DEP      <- DATA DOC
            dataExtracto[10],                                                  # MONEDA            <- NMRO BP
            fPago if n == False else "",                                      # FORMA DE PAGO     <- REFERENCIA

            dataExtracto[1] if n == False else "",                          # CONTA DE BANCO    <- CTA MAYOR
            self.__checkBancName(dataExtracto[1]) if n == False else "",    # NOMBRE BANCO      <- MAP SUPORTE

            dataExtracto[4] if n == False else "",          # ATRIBUIÇÃO        <- ATRIBUIÇÃO
            dataExtracto[2] if n == False else "",          # DOC SBP           <- Nº DOC
            self.negocioMapv2[self.tools.fixFloat2Str(str(dataCartera[6]).strip())] if self.tools.fixFloat2Str(str(dataCartera[6]).strip()) in self.negocioMapv2 else "",       # NEGOCIO  <- NEGOCIO
            dataCartera[0] if dataCartera[0] == dataExtracto[0] else "" if n == False else "",   # SOCIEDAD    <- SOCIENDAD
            "",
            self.comment
        ]

        return data



    def __checkBancName(self, refConta):

        if self.bancoMap == False:

            vData = self.exceltools.loadSheet_v2(self.broadcast.template(), "SUPORTE")

            self.bancoMap = {}
            for index in range(1, len(vData)):

                conta = self.tools.fixFloat2Str(vData[index][0])
                bname = str(vData[index][1]).strip()

                if conta != "" and bname != "":
                    self.bancoMap[conta] = bname

        refConta = self.tools.fixFloat2Str(refConta)

        if refConta in self.bancoMap:
            return self.bancoMap[refConta]
        else:
            return ""

    def __checkNegocionName(self, negocio):

        if self.negocioMap == False:

            vData = self.exceltools.loadSheet_v2(self.broadcast.template(), "SUPORTE")

            self.negocioMap = {}
            self.negocioMapv2 = {}

            for index in range(1, len(vData)):

                vData[index] = self.exceltools.fixNaN(vData[index])

                rNegococio =str(vData[index][3]).strip()
                rNegocioMod = str(vData[index][4]).strip()

                cta = self.tools.fixFloat2Str(str(vData[index][0]).strip())


                if rNegococio != "" and rNegocioMod != "":
                    self.negocioMap[rNegococio] = rNegocioMod

                if rNegocioMod != "" and cta != "":

                    self.negocioMapv2[cta] = rNegocioMod

        if negocio in self.negocioMap:
            return self.negocioMap[negocio]
        else:
            return negocio


    def find_combinations(self, values, target, current_sum=0, start_index=0, path=[]):

        result = []

        if (datetime.datetime.now() - self.maxTime).total_seconds() > 300:
            return result

        if self.controler == self.maxProp:
            return result

        if (current_sum == target or abs(current_sum) == target) and len(path) <= self.maxCombinaciones:
            result.append(path)
            self.controler +=1
            return result

        if (current_sum > target) or len(path) > self.maxCombinaciones:
            return result

        for i in range(start_index, len(values)):
            new_sum = current_sum + values[i][self.importeIndex]
            new_path = path + [values[i]]
            result += self.find_combinations(values, target, new_sum, i + 1, new_path)

        return result


    def sums_less_than(self, target, cartera, importeIndex):

        rSun = {}
        self.importeIndex = importeIndex
        self.controler = 0

        return self.find_combinations(cartera, target)


    def checkCartera(self, dataCartera):

        try:
            rutIndex = dataCartera[0].index('RUT')
            refIndex = dataCartera[0].index('REFERENCIA')
            importeIndex = dataCartera[0].index('IMPORTE DOC#')
            dateIndex = dataCartera[0].index('FECHA DOCUMENTO')
            nameIndex = dataCartera[0].index('RAZON SOCIAL')

            socIndex = dataCartera[0].index('SOCIEDAD')
            curIndex = dataCartera[0].index('MONEDA DOC#')

            return True
        except:

            return False


    def __mergeData(self, dataCartera, th):

        rutMap = {}

        rutIndex = dataCartera[0].index('RUT')
        refIndex = dataCartera[0].index('REFERENCIA')
        importeIndex = dataCartera[0].index('IMPORTE DOC#')
        dateIndex = dataCartera[0].index('FECHA DOCUMENTO')
        nameIndex = dataCartera[0].index('RAZON SOCIAL')

        socIndex = dataCartera[0].index('SOCIEDAD')
        curIndex = dataCartera[0].index('MONEDA DOC#')

        for index in range(1,len(dataCartera)):

            row = self.exceltools.fixNaN(dataCartera[index])

            rut = str(self.tools.fixFloat2Str(row[rutIndex])).replace("-", "").replace(" ", "")

            ref = str(self.tools.fixFloat2Str(row[refIndex])).replace("-", "").replace(" ", "")

            vDoc = str(row[importeIndex]).replace(" ", "")

            vSoc = str(row[socIndex]).replace(" ", "")

            vCur = str(row[curIndex]).replace(" ", "")

            vDate = self.tools.fixDate(row[dateIndex])

            vName = str(row[nameIndex]).strip().upper()

            self.broadcast.broadcastText("TH: " + str(th) + " | MAPEANDO CARTERA | " + str(index) + " de " + str(len(dataCartera)), index=0)

            if rut != "" and vDoc != "" and vSoc != "" and vCur != "":

                row[importeIndex] = float(vDoc)

                if self.checkName == "SI":

                    if str(vName).replace(" ", "") != "":

                        rutMap = self.__mapManager(rutMap, vName, row, ref, vDate)

                else:

                    key = rut + "#" + vSoc + "#" + vCur

                    rutMap = self.__mapManager(rutMap, key, row, ref, vDate)

        return rutMap


    def __mergeData_rut2(self, rutMap, dataCartera, dataExtract, maxRef, th):

        textIndex = dataExtract[0].index("Texto")
        rutIndex = dataCartera[0].index('RUT')
        cSocIndex = dataExtract[0].index('Empresa')
        cCurIndex = dataExtract[0].index('Moed')
        cDateIndex = dataExtract[0].index('Data lçto.')
        ext_ctrl = 0

        counter = 0

        extMap = {}

        for index in range(1, len(dataExtract)):

            self.comm.textUpdate("BÚSQUEDA DE DATOS | MAPPING EXTRACTO | " + str(index) + " de " + str(len(dataExtract)))

            cDate = self.tools.fixDate(dataExtract[index][cDateIndex])
            cSoc = str(dataExtract[index][cSocIndex]).strip()
            cCur = str(dataExtract[index][cCurIndex]).strip()


            if cCur != "" and cCur != "" and isinstance(cDate, datetime.datetime):

                dKey = cSoc + "#" + cCur

                if not dKey in extMap:
                    extMap[dKey] = {}

                cDate = cDate.strftime("%d%m%Y")
                d2Key = cDate + "#" + cSoc + "#" + cCur

                if not dKey in extMap[dKey]:
                    extMap[dKey][d2Key] = []

                extMap[dKey][d2Key].append(dataExtract[index])


        for key in rutMap:

            self.comm.textUpdate("BÚSQUEDA DE DATOS | " + str(key.split("#")) + " | " + str(counter) + " de " + str(len(rutMap)))
            #print("TH: "+str(th)+" | BÚSQUEDA DE DATOS | " + str(key.split("#")) + " | " + str(counter) + " de " + str(len(rutMap)))
            #print("TH: "+str(th)+" | BÚSQUEDA DE DATOS | " + str(index) + " | " + str(index) + " de " + str(len(dataExtract)))

            [rut, soc, cur] = key.split("#")

            dKey = soc + "#" + cur
            rDate = rutMap[key]["DATE"].strftime("%d%m%Y")

            if dKey in extMap:

                dataExtract = []
                for vms in extMap[dKey]:

                    [vmsDate, vmsSoc,vmsCur] = str(vms).split("#")

                    if  vmsDate >= rDate:
                        dataExtract += extMap[dKey][vms]


                for index in range(0, len(dataExtract)):

                    cRut = cRef = cName = False

                    cRut = rut in str(dataExtract[index][textIndex])
                    cRef = self.__checkRef(dataExtract[index][textIndex], rutMap[key]["REF"], maxRef)

                    if self.checkName == "SI":
                        cName = key in str(dataExtract[index][textIndex]).strip().upper()
                        rut = str(self.tools.fixFloat2Str(rutMap[key]["CARTERA"][0][rutIndex])).replace("-",  "").replace(' ',  "")

                    if cRut or cRef or cName:

                        if cRut:
                            rutMap[key]["MODE"] = "TRANSFERENCIA"

                    rutMap[key]["EXTRACTO"].append(dataExtract[index])
                    ext_ctrl += 1



            counter += 1

        return rutMap


    def __mergeData_rut(self, rutMap, dataCartera, dataExtract, maxRef, th):

        textIndex = dataExtract[0].index("Texto")
        rutIndex = dataCartera[0].index('RUT')
        cSocIndex = dataExtract[0].index('Empresa')
        cCurIndex = dataExtract[0].index('Moed')
        cDateIndex = dataExtract[0].index('Data lçto.')
        ext_ctrl = 0

        counter = 0
        for key in rutMap:

            self.comm.textUpdate("BÚSQUEDA DE DATOS | " + str(key.split("#")) + " | " + str(counter) + " de " + str(len(rutMap)))
            #print("TH: "+str(th)+" | BÚSQUEDA DE DATOS | " + str(key.split("#")) + " | " + str(counter) + " de " + str(len(rutMap)))
            #print("TH: "+str(th)+" | BÚSQUEDA DE DATOS | " + str(index) + " | " + str(index) + " de " + str(len(dataExtract)))


            for index in range(1, len(dataExtract)):

                rut = soc = cur = None
                cRut = cRef = cName = False

                if str(key).count("#") >= 2:
                    [rut, soc, cur ]  = key.split("#")

                    cRut = rut in str(dataExtract[index][textIndex])
                    cRef = self.__checkRef(dataExtract[index][textIndex], rutMap[key]["REF"], maxRef)

                cDate = self.tools.fixDate(dataExtract[index][cDateIndex])
                cSoc = dataExtract[index][cSocIndex]
                cCur = dataExtract[index][cCurIndex]


                if self.checkName == "SI":

                    cName = key in str(dataExtract[index][textIndex]).strip().upper()

                    rut = str(self.tools.fixFloat2Str(rutMap[key]["CARTERA"][0][rutIndex])).replace("-", "").replace(' ', "")
                    cRut = rut in str(dataExtract[index][textIndex])


                if cRut or cRef or cName:

                    if cDate >= rutMap[key]["DATE"] and cCur == cur and soc == cSoc:

                        if cRut:
                            rutMap[key]["MODE"] = "TRANSFERENCIA"

                        rutMap[key]["EXTRACTO"].append(dataExtract[index])
                        ext_ctrl += 1

            counter +=1

        if ext_ctrl == 0:
            return {}

        return rutMap

    def __mergeData_rut3(self, rutMap, dataCartera, dataExtract, maxRef, th):

        textIndex = dataExtract[0].index("Texto")
        rutIndex = dataCartera[0].index('RUT')
        cSocIndex = dataExtract[0].index('Empresa')
        cCurIndex = dataExtract[0].index('Moed')
        cDateIndex = dataExtract[0].index('Data lçto.')
        ext_ctrl = 0

        counter = 0
        dataframe = pd.DataFrame(dataExtract[1:], columns=dataExtract[0])

        dataframe['Data lçto.'] = dataframe['Data lçto.'].apply(lambda x: self.__checkDate(self.tools.fixDate(x)))
        toRemove = []

        for key in rutMap:
            self.comm.textUpdate(
                "BÚSQUEDA DE DATOS | " + str(key.split("#")) + " | " + str(counter) + " de " + str(len(rutMap)))

            tempDate = self.__checkDate(self.tools.fixDate(rutMap[key]["DATE"]))

            rut, soc, cur = key.split("#")

            filtro = (
                    (dataframe['Moed'] == cur) &
                    (dataframe['Empresa'] == soc) &
                    (dataframe['Texto'].str.contains(rut, na=False)) &
                    (dataframe['Data lçto.'] >= tempDate)
            )

            df_filtrado = dataframe[filtro]

            if len(df_filtrado.values.tolist()) > 0:
                df_filtrado.loc['Data lçto.'] = df_filtrado['Data lçto.'].apply(lambda x: self.__fixDate2(x))
                rutMap[key]["EXTRACTO"] += df_filtrado.values.tolist()

            counter += 1
            if len(rutMap[key]["EXTRACTO"]) == 0:
                toRemove.append(key)

        for skey in toRemove:
            if skey in rutMap:
                del rutMap[skey]

        return rutMap


    def __checkDate(self, date):

        try:
            return date.strftime("%Y%m%d")
        except:
            return ""

    def __fixDate2(self, date):

        try:
            return datetime.datetime.strptime(date, "%Y%m%d")
        except:
            return ""



    def __mapManager(self, itemMap,  key, row, ref, vDate, vtarget="CARTERA", defObject = False):


        if defObject ==  False:
            defObject = {"CARTERA": [], "EXTRACTO": [], "REF": [], "MODE": 'DEPOSITO', "DATE": ""}



        if key in itemMap:

            itemMap[key][vtarget].append(row)

            if len(str(ref)) >= self.maxRef:
                itemMap[key]["REF"].append(ref)

            if vDate < itemMap[key]["DATE"]:
                itemMap[key]["DATE"] = vDate

        else:
            itemMap[key] = copy.copy(defObject)
            itemMap[key][vtarget].append(row)

            if len(str(ref)) >= self.maxRef:
                itemMap[key]["REF"].append(ref)

            itemMap[key]["DATE"] = vDate


        return itemMap

    def __checkRef(self, texto, refList, maxRef):

        for ref in refList:

            pRef = str(ref).replace(" ", "")

            if len(pRef) == maxRef:

                if pRef in str(texto):
                    return True


        return False


    def __fixExtract(self, dataExtract):

        vrData = self.exceltools.loadSheet_v2(self.broadcast.template(), "EXTRACTO")

        pkConcat = self.exceltools.loadSheet_v2(self.broadcast.template(), "CONCAT")
        columns = []
        for pk in pkConcat:

            if pk[0] in dataExtract[0]:

                columns.append(dataExtract[0].index(pk[0]))



        textIndex = dataExtract[0].index("Texto")

        for index in range(1, len(dataExtract)):

            dataExtract[index] = self.exceltools.fixNaN(dataExtract[index])
            dataExtract[index][textIndex] = str(dataExtract[index][textIndex])

            ztext = " "
            for col in columns:
                ztext += str(dataExtract[index][col]) + " "

            dataExtract[index][textIndex] += " " + ztext.strip()



        de_para = {}
        for index in range(0, len(vrData[1])):

            de_para[vrData[1][index]] = vrData[0][index]


        for index in range(0, len(dataExtract[0])):

            if str(dataExtract[0][index]) in de_para:

                dataExtract[0][index] = de_para[dataExtract[0][index]]


        try:

            textindex = dataExtract[0].index("Texto")
            monto = dataExtract[0].index("monto")
            cSocIndex = dataExtract[0].index('Empresa')
            cCurIndex = dataExtract[0].index('Moed')
            cDateIndex = dataExtract[0].index('Data lçto.')

        except:
            raise OSError("LAS COLUMNAS DEL EXTRACTO SON NO ESTÁNDAR")

        dataExtract = self.exceltools.regularizeData(vrData[0], dataExtract)

        return dataExtract


