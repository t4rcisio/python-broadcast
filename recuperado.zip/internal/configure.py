# -*- coding: utf-8 -*-

import contextlib
import datetime
import os
import pickle
import random
import shutil
import subprocess
import sys
import traceback
import webbrowser
from threading import Thread

import pandas as pd
import pygame

import psutil
import win32com.client
from PyQt6 import QtWidgets, QtCore, QtGui
from PyQt6.QtCore import Qt, QFileSystemWatcher, QSize, QObject, QLocale, QPropertyAnimation, QRect
from PyQt6.QtGui import QIcon, QPixmap, QMovie, QTextCursor, QPainter, QPalette, QColor
from PIL import Image, ImageDraw, ImageQt
from PyQt6.QtWidgets import QDialog, QLabel, QScrollArea, QWidget, QCalendarWidget, QFrame, QVBoxLayout, QPushButton
import pyqtgraph as pg
from matplotlib import pyplot as plt
from bs4 import BeautifulSoup

from internal.services import echo, qrGenerator, thread_control, excelTools
from internal.internal_pages import inicio, infoWidget, textWindow, userWidget, logWidget, sumary
from internal.com import logControl, communication
from internal.internal_pages import home_client

GUEST_PHOTO = "./images/user.png"


class Functions:

    def __init__(self, mPage, Form, app):

        locale = QLocale("pt_BR")
        QLocale.setDefault(locale)

        self.mPage = mPage
        self.Form = Form
        self._translate = QtCore.QCoreApplication.translate
        self.app = app

        self.textCache = {"DATA": 'ACCENTURE AUTOMATION FACTORY', "OP": 1}
        self.PROFILE_PHOTO = ""

        self.local_i = ".\\images\\com.pickle"
        self.elementsVBox = False
        self.colorChange = {}

    def info(self, PROCESS_ID, PROCESS_VERSION, TOKEN, APP_NAME, ICON_LIGHT, ICON_DARK, APP_TITLE, DEV, PASSWORD,
             URL_DIR, URL_MANUAL, URL_SDD, CLIENT_LOGO, CLIENT_NAME, CLIENT_COLOR, CLIENT_TEXT_COLOR):

        self.appInfo = {

            "PROCESS_ID": PROCESS_ID,
            "PROCESS_VERSION": PROCESS_VERSION,
            "TOKEN": TOKEN,
            "APP_NAME": APP_NAME,
            "ICON_PATH": ICON_LIGHT,
            "ICON_LIGHT": ICON_LIGHT,
            "ICON_DARK": ICON_DARK,
            "APP_TITLE": APP_TITLE,
            "DEV": DEV,
            "PASSWORD": PASSWORD,
            "URL_DIR": URL_DIR,
            "URL_MANUAL": URL_MANUAL,
            "URL_SDD": URL_SDD,
            "CLIENT_LOGO": CLIENT_LOGO,
            "CLIENT_NAME": CLIENT_NAME,
            "CLIENT_COLOR": CLIENT_COLOR,
            "CLIENT_TEXT_COLOR": CLIENT_TEXT_COLOR
        }

        # Cria um arquivo local com as configurações iniciais da automação
        with open(self.local_i, "wb") as file:
            pickle.dump(self.appInfo, file)
        file.close()

        self.comm = communication.Commnunication()
        self.logTools = logControl.LogControl()

        self.comm.config(self.appInfo)
        self.appInfo = self.comm.config()

    def config(self):

        self.bgCollor = "#ffffff"
        self.is_dark_mode = False

        # Inicializa a interface com os parâmetros passados nas configuração da automação
        self.__startParams()

        # Inicializa os eventos de clique e animações
        self.__connections()

        # Configura as funções de zoom no logo do cliente
        self.mPage.zoom_in = self.zoom_in
        self.mPage.zoom_out = self.zoom_out
        self.comm.isRunnig("")

        mcolor = self.comm.theme()

        if mcolor == "light" or mcolor == False:
            self.bgCollor = "#ffffff"
            self.is_dark_mode = True
        else:
            self.bgCollor = "#1e1e1e"
            self.is_dark_mode = False

    def translateWindow(self, pageList):

        self.__loadTranslations()

        if self.translateTable == False:
            return

        lang = self.comm.language()
        try:
            langIndex = self.translateTable["HEADER"].index(lang)
        except:
            langIndex = 0

        for item in pageList:

            for widget in item.findChildren(QWidget):
                try:
                    ctrl = False
                    data = self.__extractHTML(widget.text())
                    if data != "":

                        if str(data).strip() != "":
                            for word in self.translateTable["DATA"]:
                                if data in word.split("#$")[:-1]:
                                    t_text = word.split("#$")[langIndex]
                                    widget.setText(widget.text().replace(data, t_text))
                                    ctrl = True
                                    break

                        if not ctrl:
                            for group in self.translateTable["DATA"]:
                                for word in group.split("#$")[:-1]:
                                    if word in data:
                                        t_text = group.split("#$")[langIndex]
                                        widget.setText(widget.text().replace(word, t_text))
                                        ctrl = True
                                        break

                        if not ctrl:
                            sdata = data.split(" ")
                            for mData in sdata:
                                if str(mData).strip() != "":
                                    for word in self.translateTable["DATA"]:
                                        if mData in word.split("#$")[:-1]:
                                            t_text = word.split("#$")[langIndex]
                                            widget.setText(widget.text().replace(mData, t_text))
                                            ctrl = True
                                            break

                except:
                    pass

    def run(self, payload, begin=False, end=False, update=False):

        self.payloadEx = payload
        self.tmCtrl = datetime.datetime.now()

        if self.comm.isRunnig() == "RUNNING":
            self.msgBox(QObject().tr("THERE IS ALREADY A PROCESS IN PROCESS"))
            return

        # CRIA UMA INSTANCIA DA CLASSE THREAD
        self.process = thread_control.ThreadService()

        begin = begin if begin != False else self.begin  # FUNÇÃO QUE SERA´EXECUTADA ANTES DE INICIAR A THREAD
        end = end if end != False else self.end  # FUNÇÃO QUE SERA´EXECUTADA APÓS O FIM DA THREAD
        update = update if update != False else self.update  # FUNÇÃO QUE SERA´EXECUTADA DURANTE A EXECUÇÃO DA THREAD

        self.process.startThread(self.payloadEx, begin, end, update)  # INICIALIZA

    def __startParams(self):

        self.ringControl = datetime.datetime.now()
        self.nState = False
        self.sideCRTL = False
        self.previusqItem = False
        self.mPage.automationName.setText(
            '<html><head/><body><p><span style=" font-size:12pt; font-weight:600; color:#ffffff;">' + str(
                self.appInfo['APP_TITLE'].upper()) + '</span></p></body></html>')

        # Cria e configura a página inicial
        self.iniWidget = QtWidgets.QWidget()
        self.iniPage = inicio.Ui_Form()
        self.iniPage.setupUi(self.iniWidget)

        # Configura a Home
        self.homeWidget = QtWidgets.QWidget()
        self.homePage = home_client.Ui_Form()
        self.homePage.setupUi(self.homeWidget)

        self.mPage.languageCombo.setCurrentText(self.comm.language())

        self.homePage.label_tech.setStyleSheet('background-color:rgb(255, 255, 255);border-radius: 10px;')
        self.Form.th_background_label = self.homePage.label_tech
        self.Form.th_pixmap = QPixmap('./images/techMasters.png')

        self.homePage.client_text.setText(
            '<html><head/><body><p align="center"><span style=" font-size:24pt; font-weight:600; color:' + self.appInfo[
                'CLIENT_TEXT_COLOR'] + ';">' + self.appInfo['CLIENT_NAME'].upper() + '</span></p></body></html>')
        self.homePage.widget.setStyleSheet("border-radius: 10px;background-color:" + str(self.appInfo["CLIENT_COLOR"]))

        icon23 = QtGui.QIcon()
        icon23.addPixmap(QtGui.QPixmap(self.appInfo["CLIENT_LOGO"]), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.homePage.client_btn.setIcon(icon23)
        self.homePage.client_btn.setIconSize(QtCore.QSize(300, 300))
        self.homePage.client_btn.setStyleSheet("border: none")

        # Configura os graficos que monitoram o uso de CPU, RAM e Disco
        self.__monitorChart()

        # Configura o gráfico de hora de execução
        self.__usageChart()

        # Configura o gráfico de media de execução
        self.__meanExecution()

        # Configura o logo do cliente na tela inicial
        self.__clientLogo()

        # Inicializa a barra superior
        self.__configTopBar()

        self.__toggleBtn()

        # Inicializa a barra inferior
        self.__configBottonBar()

        # Configura o widget da accenture na janela de gráficos
        self.iniPage.textEdit.setVisible(False)

        self.sumaryWidget = QtWidgets.QWidget()
        self.sumaryPage = sumary.Ui_Form()
        self.sumaryPage.setupUi(self.sumaryWidget)

        self.iniPage.verticalLayout_3.addWidget(self.sumaryWidget)
        self.__loadAccWidget()

    def __loadAccWidget(self):

        data = self.comm.execution_report()

        ops_counter = 0
        ex_counter = 0
        tm = 0
        automation_ex = 0
        delta = 0
        cafe = 0
        caminhada = 0
        paginas = 0

        subName = {}

        if isinstance(data, list):

            ex_counter = len(data)
            ops_counter = 0

            self.comm.execution_report(data)

            for row in data:
                try:

                    if row["OPS"] > 0:

                        if "OPS" in row:
                            ops_counter += row["OPS"]

                        if "TM" in row:
                            tm += row["OPS"] * (int(row["TM"]) * 60)

                        if "DELTA" in row:

                            automation_ex += row['DELTA']

                            if "SUBPROCESS_NAME" in row:

                                if not row["SUBPROCESS_NAME"] in subName:
                                    subName[row["SUBPROCESS_NAME"]] = []

                                subName[row["SUBPROCESS_NAME"]].append(row['DELTA'])
                except:
                    pass

            delta = tm - automation_ex

            cafe = int(round((delta / 60) / 5, 0))
            paginas = int(round((delta / 60), 0))
            caminhada = int(round((delta / 60) / 15, 0))

        cafe = cafe if cafe > 0 else 0
        paginas = paginas if paginas > 0 else 0
        caminhada = caminhada if caminhada > 0 else 0

        self.sumaryPage.operacoes.setText(
            '<html><head/><body><p align="center"><span style=" font-size:11pt; font-weight:600; color:#969696;">Operações</span></p><p align="center"><span style=" font-size:28pt; font-weight:600; color:#f2a900;">' + str(
                ops_counter) + '</span></p></body></html>')
        self.sumaryPage.execucoes.setText(
            '<html><head/><body><p align="center"><span style=" font-size:11pt; font-weight:600; color:#969696;">Execuções</span></p><p align="center"><span style=" font-size:28pt; font-weight:600; color:#f2a900;">' + str(
                ex_counter) + '</span></p></body></html>')
        self.sumaryPage.infos.setText(
            '<html><head/><body><p><span style=" font-size:12pt; font-weight:600; color:#969696;">Tempo de Execução Manual: </span><span style=" font-size:12pt; font-weight:600; color:#a100fe;">' + str(
                self.tempoExec(
                    tm)) + '</span></p><p><span style=" font-size:12pt; font-weight:600; color:#969696;">Tempo de Automação: </span><span style=" font-size:12pt; font-weight:600; color:#a100fe;">' + str(
                self.tempoExec(
                    automation_ex)) + '</span></p><p><span style=" font-size:12pt; font-weight:600; color:#969696;">Tempo Economizado: </span><span style=" font-size:12pt; font-weight:600; color:#a100fe;">' + str(
                self.tempoExec(delta)) + '</span></p></body></html>')

        self.sumaryPage.cafes.setText(
            '<html><head/><body><p align="center"><span style=" font-size:8pt; font-weight:600; color:#ffffff;">' + str(
                cafe) + ' CAFEZINHOS TOMADOS</span></p></body></html>')
        self.sumaryPage.livros.setText(
            '<html><head/><body><p align="center"><span style=" font-size:8pt; font-weight:600; color:#ffffff;">' + str(
                paginas) + ' PÁGINAS DE LIVRO LIDAS</span></p></body></html>')
        self.sumaryPage.caminhada.setText(
            '<html><head/><body><p align="center"><span style=" font-size:8pt; font-weight:600; color:#ffffff;">' + str(
                caminhada) + ' KM DE CAMINHADA</span></p></body></html>')

        if len(subName) > 0:
            self.plot_data(subName)

    def __connections(self):

        self.mPage.sideButton.clicked.connect(lambda state: self.__sideBarControl())
        self.mPage.userButton.clicked.connect(lambda state: self.__userButton())
        self.mPage.infoButton.clicked.connect(lambda state: self.__infoButton())
        self.mPage.termsLabel.mousePressEvent = lambda state: self.showMessage(title="TERMS OF USE",
                                                                               path="./images/legal.html")
        self.mPage.privacyLabel.mousePressEvent = lambda state: self.showMessage(title="TERMS OF USE",
                                                                                 path="./images/privacy.html")

        self.mPage.contactLabel.mousePressEvent = lambda state: self.__malito()

        self.mPage.bugButton.clicked.connect(lambda state: self.__openLog())
        self.mPage.languageCombo.currentIndexChanged.connect(lambda index: self.__changeLanguage(index))

        self.mPage.ringButton.clicked.connect(self.show_notifications)

        self.watcher = QFileSystemWatcher()
        self.watcher.addPath(self.comm.notificationsPath)
        self.watcher.fileChanged.connect(self.__notificationsEvent)
        self.__notificationsEvent()

        self.pmax = None

    def __notificationsEvent(self):

        res = self.comm.notifications()

        if res == None:
            res = []

        if len(res) == 0:

            icon2 = QtGui.QIcon()
            icon2.addPixmap(QtGui.QPixmap("./ui\\../images/bell.png"), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
            self.mPage.ringButton.setIcon(icon2)
            self.mPage.ringButton.setIconSize(QtCore.QSize(35, 35))
            self.nState = True
        else:

            icon2 = QtGui.QIcon()
            icon2.addPixmap(QtGui.QPixmap("./ui\\../images/bell_2.png"), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
            self.mPage.ringButton.setIcon(icon2)
            self.mPage.ringButton.setIconSize(QtCore.QSize(35, 35))

            if self.nState == True:
                app = Thread(target=self.__ringNotification)
                app.start()

            self.nState = True

    def __ringNotification(self):

        if (datetime.datetime.now() - self.ringControl).total_seconds() > 5:

            with contextlib.redirect_stdout(None):
                pygame.mixer.init()

                # Carrega e toca o áudio
                pygame.mixer.music.load("./images/notification.mp3")
                pygame.mixer.music.play()

                # Manter o programa rodando até o áudio terminar
                while pygame.mixer.music.get_busy():
                    pass

    def __malito(self):

        to = str(self.appInfo["DEV"]).lower() + "@accenture.com"
        subject = "HELP ABOUT " + str(self.appInfo["APP_TITLE"]).upper()
        body = f"""
Hello,<br><br>
I hope you are doing well.<br><br>

I am experiencing some difficulties with automation <b>{self.appInfo["APP_TITLE"]}</b>, version <b>{self.appInfo['PROCESS_VERSION']}</b>, and I would appreciate your help in resolving this issue. Could you assist me with this?<br><br>

Thank you in advance for your time and support.<br>
Looking forward to your response.<br><br>

Best regards,<br>
{os.getlogin()}
"""

        attachment_path = self.comm.logPath + "\\LOG.log"

        # Inicia o Outlook
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)
        mail.To = to
        mail.Subject = subject
        mail.HTMLBody  = body

        if os.path.exists(attachment_path):
            mail.Attachments.Add(attachment_path)

        mail.Display()

    def __clientLogo(self):

        self.mPage.rotation_angle = 0

        if not os.path.exists(self.appInfo['CLIENT_LOGO']):
            self.appInfo['CLIENT_LOGO'] = './images/defaultLogo.png'

        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(self.appInfo['CLIENT_LOGO']), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.mPage.clientButton.setIcon(icon2)
        self.mPage.clientButton.setIconSize(QtCore.QSize(50, 50))
        self.mPage.clientButton.clicked.connect(lambda state: self.animate_button())
        self.mPage.clientButton.setStyleSheet("border:0px;border-radius:7px;")

        self.mPage.clientButton.installEventFilter(self.Form)

        bgg = QtWidgets.QVBoxLayout(self.homePage.widget_6)
        bgg.setContentsMargins(0, 0, 0, 0)

        tfo_bg = GIFBackgroundWidget("./images/tfo.gif", self.homeWidget)
        bgg.addWidget(tfo_bg)

        text = QtWidgets.QLabel()
        text.setStyleSheet("background-color: transparent;")
        text.setText(
            '<html><head/><body><p align="center"><span style=" font-size:24pt; font-weight:600; color:#ffffff;">Technology for Operations (TfO)</span></p></body></html>')

        tfo_layout = QtWidgets.QHBoxLayout(tfo_bg)
        tfo_layout.addWidget(text)

    def animate_button(self):
        # Criar a animação de rotação em torno do eixo Y
        animation = QtCore.QPropertyAnimation(self.mPage.clientButton, b"rotation")
        animation.setStartValue(self.mPage.rotation_angle)
        animation.setEndValue(self.mPage.rotation_angle + 360)  # Girar 360 graus
        animation.setDuration(1000)  # A duração da animação em milissegundos
        animation.setEasingCurve(QtCore.QEasingCurve.Type.Linear)  # A curva de animação
        animation.start()

        self.mPage.rotation_angle += 360

    def __sideBarControl(self):

        if self.pmax == None:
            self.pmax = 250

        if not self.sideCRTL:
            self.annnimation1 = QtCore.QPropertyAnimation(self.mPage.sideBarWidget, b'maximumWidth')
            self.annnimation1.setDuration(500)
            self.annnimation1.setStartValue(80)
            self.annnimation1.setEndValue(self.pmax)
            self.annnimation1.start()

            self.annnimation2 = QtCore.QPropertyAnimation(self.mPage.sideButton, b'maximumWidth')
            self.annnimation2.setDuration(250)
            self.annnimation2.setStartValue(45)
            self.annnimation2.setEndValue(0)
            self.annnimation2.start()
            self.annnimation2.finished.connect(lambda: self.__sideButtonFlip("2"))

        if self.sideCRTL:
            '''for item in self.qItens:

                if item.width() > self.pmax:
                    self.pmax = item.width()'''

            self.annnimation4 = QtCore.QPropertyAnimation(self.mPage.sideBarWidget, b'maximumWidth')
            self.annnimation4.setDuration(500)
            self.annnimation4.setStartValue(self.pmax)
            self.annnimation4.setEndValue(80)
            self.annnimation4.start()

            self.annnimation2 = QtCore.QPropertyAnimation(self.mPage.sideButton, b'maximumWidth')
            self.annnimation2.setDuration(250)
            self.annnimation2.setStartValue(45)
            self.annnimation2.setEndValue(0)
            self.annnimation2.start()
            self.annnimation2.finished.connect(lambda: self.__sideButtonFlip(""))

        self.sideCRTL = not self.sideCRTL

    def __sideButtonFlip(self, op):

        self.annnimation3 = QtCore.QPropertyAnimation(self.mPage.sideButton, b'maximumWidth')
        self.annnimation3.setDuration(250)
        self.annnimation3.setStartValue(0)
        self.annnimation3.setEndValue(45)
        self.annnimation3.start()
        icon = QtGui.QIcon()

        icon.addPixmap(QtGui.QPixmap(".\\ui\\../images/acc_emb" + op + ".png"), QtGui.QIcon.Mode.Normal,
                       QtGui.QIcon.State.Off)
        self.mPage.sideButton.setIcon(icon)
        self.mPage.sideButton.setIconSize(QtCore.QSize(45, 45))

        if op != "":
            self.__showIconsLabel()
        else:
            self.__hideIconsLabel()

    def __showIconsLabel(self):

        self.mPage.clientName.setVisible(True)
        self.mPage.clientName.setText(
            '<html><head/><body><p><span style=" font-size:12pt; font-weight:600; color:#a100fe;">' + self.appInfo[
                'CLIENT_NAME'] + '</span></p></body></html>')

        for item in self.janelas:
            self.janelas[item]["LABEL"].setVisible(True)

    def __hideIconsLabel(self):

        self.mPage.clientName.setVisible(False)

        for item in self.janelas:
            self.janelas[item]["LABEL"].setVisible(False)

    def clear_layout(self, layout):
        while layout.count() > 0:
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            else:
                if item.layout() is not None:
                    self.clear_layout(item.layout())

    def buildJanelas(self, janelas):

        if not self.elementsVBox:
            qWindow = QtWidgets.QWidget()
            self.elementsVBox = QtWidgets.QVBoxLayout(qWindow)
            self.elementsVBox.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)
            self.elementsVBox.setSpacing(12)
            self.mPage.scrollArea.setWidget(qWindow)
            self.mPage.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        self.janelas = janelas
        self.qItens = []

        index = 0
        for item in self.janelas:
            self.qItens.append(QtWidgets.QWidget())
            qLayout = QtWidgets.QHBoxLayout(self.qItens[-1])
            qLayout.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
            qLayout.setContentsMargins(3, 3, 3, 3)

            qButton = QtWidgets.QPushButton()
            qButton.setStyleSheet(''' 
            QPushButton {
                border:0px;
            }''')

            qButton.clicked.connect(lambda state, i=index, q=self.qItens[-1]: self.__switchPage(i, q))

            icon = QtGui.QIcon()
            icon.addPixmap(QtGui.QPixmap(self.janelas[item]["TAB_ICON"]), QtGui.QIcon.Mode.Normal,
                           QtGui.QIcon.State.Off)
            qButton.setIcon(icon)
            qButton.setIconSize(QtCore.QSize(50, 50))

            self.janelas[item]["LABEL"] = QtWidgets.QLabel()
            self.janelas[item]["LABEL"].setText(
                '<html><head/><body><p><span style=" font-size:12pt; font-weight:600; color:#7500b9;">' +
                self.janelas[item]["TAB_NAME"] + '</span></p></body></html>')
            self.janelas[item]["LABEL"].setVisible(False)

            qLayout.addWidget(qButton)
            qLayout.addWidget(self.janelas[item]["LABEL"])

            self.mPage.stackedWidget.insertWidget(index, self.janelas[item]["WINDOW"])
            self.qItens[-1].mousePressEvent = lambda state, i=index, q=self.qItens[-1]: self.__switchPage(i, q)

            index += 1
            self.elementsVBox.addWidget(self.qItens[-1])

        self.mPage.stackedWidget.setCurrentIndex(0)

        self.translateWindow([self.janelas[item]["WINDOW"] for item in self.janelas])

    def __changeLanguage(self, index):

        lang = self.mPage.languageCombo.currentText()
        self.comm.language(lang)

        if self.translateTable == False:
            return

        self.restart()

    def restart(self):
        self.msgBox("A APLICAÇÃO SERÁ FECHADA! ")
        self.Form.close()  # Fecha a janela atual
        QtWidgets.QApplication.quit()  # Encerra o loop atual do aplicativo

        subprocess.Popen([sys.executable] + sys.argv)
        sys.exit(0)

    def __extractHTML(self, html_string):

        try:
            soup = BeautifulSoup(html_string, 'html.parser')
            text_parts = soup.stripped_strings
            extracted_text = "\n".join(text_parts)
            extracted_text = extracted_text.replace("\n", " ")

            if extracted_text:
                return extracted_text
            else:
                return html_string

        except:

            return html_string

    def __loadTranslations(self):

        self.translateTable = False

        try:

            path = "./images/translate.xlsx"
            df = pd.read_excel(path)

            rows = df.values.tolist()
            header = df.columns.tolist()

            tTable = []
            for row in rows:
                text = ""
                for item in row:
                    if item != "":
                        text += item + "#$"

                tTable.append(text)

            self.translateTable = {"HEADER": header, "DATA": tTable}
        except:
            self.translateTable = False

    def __switchPage(self, index, qItem):

        if self.previusqItem != False:
            self.previusqItem.setStyleSheet("")

        qItem.setStyleSheet("border:0px;background-color: rgb(88, 0, 145);border-radius:10px;")
        self.previusqItem = qItem

        self.mPage.stackedWidget.setCurrentIndex(index)

    def __meanExecution(self):

        self.meanlayout = QtWidgets.QVBoxLayout(self.iniPage.widget_3)

        # Widget do gráfico
        self.plot_widgetMean = pg.PlotWidget(title="Runtime")
        self.plot_widgetMean.setBackground(self.bgCollor)
        self.plot_widgetMean.setLabel("left", "Runtime (s)")
        self.plot_widgetMean.setLabel("bottom", "Executions")
        self.plot_widgetMean.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widgetMean.getAxis('left').setPen(pg.mkPen(color="white"))
        self.plot_widgetMean.getAxis('bottom').setPen(pg.mkPen(color="white"))
        self.meanlayout.addWidget(self.plot_widgetMean)
        self.plot_widgetMean.setMinimumHeight(300)

        self.__loadMeanExecution()

    def __loadMeanExecution(self):

        self.plot_widgetMean.clear()

        # Dados do gráfico
        self.xMean = list(range(100))
        self.yMean = []
        data = self.comm.execution_report()

        soma = 0
        if data != None:

            for row in data:
                self.yMean.append(row["DELTA"])

            self.xMean = list(range(len(self.yMean)))
        else:
            self.yMean = [random.randint(50, 100) for _ in self.xMean]  # Valores iniciais de tempo de execução (em ms)

        # Linha dos tempos de execução
        self.execution_line = self.plot_widgetMean.plot(self.xMean, self.yMean,
                                                        pen=pg.mkPen(color=(161, 0, 254, 200), width=2))

        # Linha média
        self.mean_line = pg.InfiniteLine(angle=0, pen=pg.mkPen(style=pg.QtCore.Qt.PenStyle.DashLine, color="#a100fe"))
        self.plot_widgetMean.addItem(self.mean_line)

        # Texto para o valor médio
        self.mean_text = pg.TextItem("", color="black", anchor=(0, 1), fill=(255, 255, 255, 220))
        self.plot_widgetMean.addItem(self.mean_text)

        mean_value = round(sum(self.yMean) / len(self.yMean), 2)

        # Atualiza a posição da linha média
        self.mean_line.setPos(mean_value)

        # Atualiza o texto com o valor da média
        self.mean_text.setText(QObject().tr(f"Average: {mean_value:.2f} s"))
        self.mean_text.setPos(self.xMean[-1] - 20, mean_value)

    def __usageChart(self):

        self.usageLayout = QtWidgets.QVBoxLayout(self.iniPage.widget_5)

        # Widget do gráfico
        self.plot_widget = pg.PlotWidget(title=QObject().tr("Hourly Execution Recurrence"))
        self.plot_widget.setBackground(self.bgCollor)
        self.plot_widget.setLabel("left", QObject().tr("Occurrences"))
        self.plot_widget.setLabel("bottom", QObject().tr("Time"))
        self.plot_widget.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widget.getAxis('left').setPen(pg.mkPen(color="white"))
        self.plot_widget.getAxis('bottom').setPen(pg.mkPen(color="white"))
        self.usageLayout.addWidget(self.plot_widget)
        self.plot_widget.setMinimumHeight(300)

        self.__loadUserChart()

    def __loadUserChart(self):

        self.plot_widget.clear()

        data = self.comm.execution_report()

        if data != None:

            hourMap = {}

            for row in data:
                hour = row["START"].hour

                if not hour in hourMap:
                    hourMap[hour] = 1
                else:
                    hourMap[hour] = hourMap[hour] + 1

            self.xUsage = list(range(24))
            self.yUsage = []

            for i in self.xUsage:
                if i in hourMap:
                    self.yUsage.append(hourMap[i])
                else:
                    self.yUsage.append(0)
        else:
            self.xUsage = list(range(24))
            self.yUsage = [random.randint(0, 10) for _ in self.xUsage]  # Quantidade de ocorrências para cada hora

        # Desenha o gráfico inicial
        self.bar_graph = pg.BarGraphItem(x=self.xUsage, height=self.yUsage, width=0.8, brush="#a100fe")
        self.plot_widget.addItem(self.bar_graph)

    def __monitorChart(self):

        self.monitorLayout = QtWidgets.QVBoxLayout(self.iniPage.widget_6)

        # Widget do gráfico
        self.plot_widgetSubProc = pg.PlotWidget(title="Runtime")
        self.plot_widgetSubProc.setBackground(self.bgCollor)
        self.plot_widgetSubProc.setLabel("left", "Runtime (s)")
        self.plot_widgetSubProc.setLabel("bottom", "Executions")
        self.plot_widgetSubProc.showGrid(x=True, y=True, alpha=0.3)
        self.plot_widgetSubProc.getAxis('left').setPen(pg.mkPen(color="white"))
        self.plot_widgetSubProc.getAxis('bottom').setPen(pg.mkPen(color="white"))
        self.monitorLayout.addWidget(self.plot_widgetSubProc)
        self.plot_widgetSubProc.setMinimumHeight(300)

    def plot_data(self, subName):

        self.plot_widgetSubProc.clear()

        yData = []
        xRange = []

        for key in subName:
            yData.append(subName[key])
            xRange.append(range(0, len(subName[key])))

        yLabels = list(subName.keys())
        self.plot_widgetSubProc.addLegend()

        n_curves = len(subName)
        colors = [plt.cm.hsv(i / max(1, n_curves)) for i in range(n_curves)]

        for idx, (x, yMean, label) in enumerate(zip(xRange, yData, yLabels)):
            r, g, b, _ = [int(c * 255) for c in colors[idx]]
            pen = pg.mkPen(color=(r, g, b), width=2)
            if len(yMean) == 1:
                self.plot_widgetSubProc.plot(
                    x, yMean, pen=None, symbol='o', symbolSize=10, symbolBrush=(r, g, b),
                    name=label
                )
            else:
                self.plot_widgetSubProc.plot(x, yMean, pen=pen, name=label)

    def update_data(self):
        # Obtém dados do sistema
        cpu_percent = psutil.cpu_percent()
        ram_percent = psutil.virtual_memory().percent
        disk_percent = psutil.disk_usage('/').percent

        # Atualiza os dados
        self.cpu_data = self.cpu_data[1:] + [cpu_percent]
        self.ram_data = self.ram_data[1:] + [ram_percent]
        self.disk_data = self.disk_data[1:] + [disk_percent]

        # Atualiza os gráficos
        self.cpu_plot.plot(self.xMonitor, self.cpu_data, pen=pg.mkPen(color="orange", width=2), clear=True)
        self.ram_plot.plot(self.xMonitor, self.ram_data, pen=pg.mkPen(color="purple", width=2), clear=True)
        self.disk_plot.plot(self.xMonitor, self.disk_data, pen=pg.mkPen(color="cyan", width=2), clear=True)

        # Atualiza os textos com os valores mais recentes
        self.cpu_text.setText(QObject().tr(f"CPU: {cpu_percent:.1f}%"))
        self.cpu_text.setPos(len(self.xMonitor) - 1, cpu_percent)

        self.ram_text.setText(QObject().tr(f"RAM: {ram_percent:.1f}%"))
        self.ram_text.setPos(len(self.xMonitor) - 1, ram_percent)

        self.disk_text.setText(QObject().tr(f"DISK: {disk_percent:.1f}%"))
        self.disk_text.setPos(len(self.xMonitor) - 1, disk_percent)

        # self.y = [random.randint(0, 10) for _ in self.x]  # Atualiza os dados aleatoriamente
        self.bar_graph.setOpts(height=self.yUsage)  # Atualiza as alturas das barras

        # media
        self.execution_line.setData(self.xMean, self.yMean)

        """Atualiza a linha média e o texto associado."""
        # Calcula a média
        mean_value = sum(self.yMean) / len(self.yMean)

        # Atualiza a posição da linha média
        self.mean_line.setPos(mean_value)

        # Atualiza o texto com o valor da média
        self.mean_text.setText(QObject().tr(f"Average: {mean_value:.2f} s"))
        self.mean_text.setPos(self.xMean[-1] - 20, mean_value)

    def __configTopBar(self):

        mainPath = "C:\\Users\\" + os.getlogin() + "\\AppData\\Local\\Microsoft\\Edge\\User Data\\Snapshots"
        ctrl = False

        if os.path.exists(mainPath):
            snapshots = os.listdir(mainPath)

            if len(snapshots) > 0:

                for folder in snapshots:

                    vPath = mainPath + "\\" + folder + "\\Default\\Edge Profile Picture.png"

                    if os.path.exists(vPath):

                        try:
                            self.PROFILE_PHOTO = self.comm.tempPath + "\\" + "user.png"

                            shutil.copy(vPath, self.PROFILE_PHOTO)
                            if os.path.exists(self.PROFILE_PHOTO):
                                ctrl = True
                                break
                        except:
                            print(traceback.format_exc())

            if ctrl:

                rounded_pixmap = self.get_rounded_pixmap(self.PROFILE_PHOTO, 80)
                icon = QtGui.QIcon(rounded_pixmap)
                self.mPage.userButton.setIcon(icon)
                self.mPage.userButton.setIconSize(QtCore.QSize(42, 42))
            else:
                icon = QtGui.QIcon()
                icon.addPixmap(QtGui.QPixmap(GUEST_PHOTO), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
                self.mPage.userButton.setIcon(icon)
                self.mPage.userButton.setStyleSheet("border-radius: 8px;")
                self.mPage.userButton.setIconSize(QtCore.QSize(50, 50))

    def begin(self):

        self.textCache = "ACCENTURE AUTOMATION FACTORY"
        self.comm.operationsCounter({"ECHO": 0, "TOTAL": 0})
        self.comm.automationError({"STATUS": False, "MESSAGE": ""})

        if self.payloadEx["ECHO"]["SPID"] != False:
            self.echo.start(self.payloadEx["ECHO"]["SPID"], self.payloadEx["ECHO"]["NOME"],
                            self.payloadEx["ECHO"]["TM"])

        self.comm.textUpdate("ACCENTURE AUTOMATION FACTORY")
        self.comm.isRunnig("RUNNING")

        self.loadingLabel.setVisible(True)
        self.labelThread.setVisible(True)

    def end(self):

        message = self.comm.textUpdate()
        ops = self.comm.operationsCounter()
        if isinstance(message, dict):
            self.textCache = message

        errAuto = self.comm.automationError()
        try:
            if not isinstance(errAuto, dict):
                errAuto = {"STATUS": False, "MESSAGE": ""}
        except:
            errAuto = {"STATUS": False, "MESSAGE": ""}

        if self.payloadEx["ECHO"]["SPID"] != False:

            if errAuto["STATUS"] == True:
                self.echo.error(self.payloadEx["ECHO"]["SPID"], errAuto['MESSAGE'], ops["TOTAL"])
            else:
                self.echo.end(self.payloadEx["ECHO"]["SPID"], ops["TOTAL"])

        self.comm.isRunnig("")

        self.loadingLabel.setVisible(False)
        self.labelThread.setVisible(False)

        self.comm.textUpdate("ACCENTURE AUTOMATION FACTORY")

        self.__loadUserChart()
        self.__loadMeanExecution()
        self.__loadAccWidget()

        self.textCache = {"DATA":"ACCENTURE AUTOMATION FACTORY"}

        text = '<html><head/><body><p align="left"><span style=" font-size:12pt; font-weight:600; color:#a100fe;">' + QObject().tr(
            str(self.textCache)) + '</span></p></body></html>'
        self.labelThread.setText(text)
        self.labelThread.setWordWrap(True)
        self.comm.operationsCounter({"ECHO": 0, "TOTAL": 0})

    def update(self):

        now = datetime.datetime.now()
        message = self.comm.textUpdate()

        if message == "" or message == None:
            message = self.textCache

        # FAZ A ATUALIZAÇÃO NO ECHO PARA QUE ELE NÃO SEJA DESCONECTADO
        if (now - self.tmCtrl).total_seconds() >= 480:
            ops = self.comm.operationsCounter()
            self.echo.update(self.payloadEx["ECHO"]["SPID"], ops["ECHO"])
            self.tmCtrl = datetime.datetime.now()
            ops["ECHO"] = 0
            self.comm.operationsCounter(ops)

        self.textCache = message

        text = '<html><head/><body><p align="left"><span style=" font-size:12pt; font-weight:600; color:#a100fe;">' + str(self.textCache['DATA']) + '</span></p></body></html>'
        self.labelThread.setText(text)
        self.labelThread.setWordWrap(True)

    def echoCheck(self):

        self.echo = echo.Echo()
        self.echo.initialize()

        echo_version = self.echo.check_version()
        if echo_version != None:
            if echo_version != self.appInfo['PROCESS_VERSION']:
                msg = "You are using an outdated version of automation!\n\nYour Version: " + str(
                    self.appInfo['PROCESS_VERSION']) + "\nNew version: " + str(
                    echo_version) + "\n\nPlease contact your administrator to receive the new version!"
                self.msgBox(msg)
                return False

        return True


    def selectFolder(self, event, element):

        filenme = QtWidgets.QFileDialog.getExistingDirectory(self.mPage.widget, "SELECT FOLSER")

        if filenme == "" or not os.path.exists(filenme):
            return

        element.setText(filenme)

    def selectFile(self, event, element, boxElement=False, filter="All Files (*)"):

        filenme = QtWidgets.QFileDialog.getOpenFileName(self.mPage.widget, QObject().tr("SELECT FILE"), filter=filter)

        if filenme[0] == "" or not os.path.exists(filenme[0]):
            return

        if boxElement != False:

            try:
                self.excelTools = excelTools.ExcelTools()
                tables = self.excelTools.getTableNames(filenme[0])

                boxElement.clear()
                boxElement.addItems(tables)

            except:
                pass

        element.setText(filenme[0])

    def __selectFolder(self):

        pass

    def tempoExec(self, tempo_execucao_segundos):

        if tempo_execucao_segundos == 0:
            return " 0 HORAS & 0 MINUTOS"

        ctrl = ""

        if tempo_execucao_segundos < 0:
            ctrl = "- "
            tempo_execucao_segundos = tempo_execucao_segundos * -1

        if tempo_execucao_segundos < 60:
            txtTime = f"{tempo_execucao_segundos:.2f} SEGUNDOS"
        elif tempo_execucao_segundos < 3600:

            minutos = int(tempo_execucao_segundos // 60)
            segundos = int(tempo_execucao_segundos % 60)
            txtTime = f"{minutos} MINUTOS & {segundos} SEGUNDOS"
        else:
            horas = int(tempo_execucao_segundos // 3600)
            minutos = int((tempo_execucao_segundos % 3600) // 60)

            txtTime = f"{horas} HORAS & {minutos} MINUTOS"

        return ctrl + txtTime

    def openCalendar(self, element, format="dd/MM/yyyy"):

        dialog = QDialog()
        dialog.setWindowTitle("SELECT DATE")
        icon = QIcon(self.appInfo['ICON_PATH'])
        dialog.setWindowIcon(icon)

        calendar = QCalendarWidget(dialog)
        calendar.setStyleSheet('''
                   QCalendarWidget {
                       background: #F0F0F0;  /* Fundo cinza claro */
                       border: 1px solid #D3D3D3;
                       border-radius: 6px;
                       font-size: 14px;
                   }

                   /* Barra superior (botões de navegação e mês/ano) */
                   QCalendarWidget QWidget {
                       background: #D3D3D3;
                       color: #ffffff;
                       font-weight: bold;
                   }

                   /* Botões de navegação */
                   QCalendarWidget QToolButton {
                       background: #D3D3D3;
                       color: black;
                       border-radius: 4px;
                       padding: 5px;
                   }

                   /* Estilizando dropdown de mês/ano */
                   QCalendarWidget QToolButton::menu-indicator {
                       image: none;  /* Remove a seta padrão */
                   }

                   QCalendarWidget QMenu {
                       background: white;  /* Fundo do menu dropdown */
                       color: black;        /* Texto preto visível */
                       border: 1px solid #D3D3D3;
                   }

                   /* Barra dos dias da semana */
                   QCalendarWidget QHeaderView {
                       background: #E1E1E1;
                       color: #ffffff;
                       font-weight: bold;
                   }

                   /* Números dos dias */
                   QCalendarWidget QAbstractItemView {
                       color: black;
                   }

                   /* Dia selecionado */
                   QCalendarWidget QAbstractItemView::item:selected {
                       background: #0078D7;  /* Azul Windows */
                       color: white;
                       border-radius: 3px;
                   }

                   /* Removendo setas do QSpinBox do ano */
                   QCalendarWidget QSpinBox {
                       qproperty-buttonSymbols: NoButtons;  /* Oculta as setas ↑ ↓ */
                       color: black; /* Texto preto para melhor visibilidade */
                   }
               ''')

        calendar.setVerticalHeaderFormat(calendar.verticalHeaderFormat().NoVerticalHeader)
        calendar.clicked.connect(lambda: self.__showDate(calendar.selectedDate(), dialog, element, format))
        calendar.setDateEditEnabled(False)

        layout = QVBoxLayout(dialog)
        layout.addWidget(calendar)
        dialog.setLayout(layout)

        dialog.exec()

    def __showDate(self, date, dialog, element, dateFormat):
        selected_date = date.toString(dateFormat)
        element.setText(str(selected_date))
        dialog.accept()

    def __configBottonBar(self):

        bLayout = QtWidgets.QHBoxLayout(self.mPage.widget_18)
        bLayout.setContentsMargins(0, 0, 0, 0)
        bLayout.setSpacing(20)
        self.mPage.widget_18.setStyleSheet("background-color: rgb(214, 214, 214)")

        self.loadingGif = QMovie("./images/loading.gif")
        self.loadingGif.setScaledSize(QSize(60, 60))
        self.loadingLabel = QtWidgets.QLabel()
        self.loadingLabel.setMovie(self.loadingGif)
        self.loadingLabel.setMaximumWidth(60)
        self.loadingGif.start()

        self.labelThread = QtWidgets.QLabel()
        text = '<html><head/><body><p align="left"><span style=" font-size:12pt; font-weight:600; color:#a100fe;">ACCENTURE AUTOMATION FACTORY</span></p></body></html>'
        self.labelThread.setText(text)
        self.labelThread.setWordWrap(True)

        bLayout.addWidget(self.loadingLabel)
        bLayout.addWidget(self.labelThread)

        self.loadingLabel.setVisible(False)
        self.labelThread.setVisible(False)

    def __userButton(self):

        self.page = QtWidgets.QWidget()
        self.userPage = userWidget.Ui_Form()
        self.userPage.setupUi(self.page)
        self.page.setWindowModality(Qt.WindowModality.ApplicationModal)

        url = GUEST_PHOTO

        if os.path.exists(self.PROFILE_PHOTO):
            url = self.PROFILE_PHOTO

        rounded_pixmap = self.get_rounded_pixmap(url, 80)
        icon = QtGui.QIcon(rounded_pixmap)
        self.userPage.userButton.setIcon(icon)
        self.userPage.userButton.setIconSize(QtCore.QSize(90, 90))

        self.userPage.portalBtn.clicked.connect(lambda state: self.__openLink(self.appInfo['URL_SDD']))
        self.userPage.manualBtn.clicked.connect(lambda state: self.__openLink(self.appInfo['URL_MANUAL']))

        self.userPage.userLabel.setText(
            '<html><head/><body><p align="center"><span style=" font-size:12pt; font-weight:600; color:#ffffff;">' + os.getlogin() + '</span></p></body></html>')

        icon = QIcon(self.appInfo['ICON_PATH'])
        self.page.setWindowTitle("Perfil")
        self.page.setWindowIcon(icon)

        self.userPage.resetBtn.clicked.connect(lambda state: self.__clearRegData())

        self.translateWindow([self.page])

        self.page.show()

    def __clearRegData(self):

        reply = self.__msgQuestion("ATENÇÃO",
                                   "Isso irá apagar os seguintes dados:\n\n❎LOGIN E SENHAS SALVAS\n❎CONFIGURAÇÕES\n❎ESTATÍSTICAS DE USO\n❎LOGS\n\nDeseja continuar?")

        if reply:
            try:
                shutil.rmtree(self.comm.appFolder)
                self.restart()
            except:
                self.msgBox("OCORREU UM ERRO")

        else:
            self.msgBox("OPERAÇÃO CANCELADA")

    def __msgQuestion(self, title, text):
        msg_box = QtWidgets.QMessageBox()
        msg_box.setWindowTitle(title)
        msg_box.setText(text)
        icon = QIcon(self.appInfo["ICON_PATH"])
        msg_box.setWindowIcon(icon)
        msg_box.setStandardButtons(
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No)
        msg_box.setStyleSheet(
            "color: white; background-color: rgb(237, 86, 88); font-size: 16px; font-weight: bold;")

        reply = msg_box.exec()

        return True if reply == QtWidgets.QMessageBox.StandardButton.Yes else False

    def __infoButton(self):

        self.pageI = QtWidgets.QWidget()
        self.infoPage = infoWidget.Ui_Form()
        self.infoPage.setupUi(self.pageI)
        self.pageI.setWindowModality(Qt.WindowModality.ApplicationModal)

        self.infoPage.sourceURL.clicked.connect(lambda state: self.__openLink(self.appInfo['URL_DIR']))

        self.infoPage.devLabel.setText(
            '<html><head/><body><p>''<span style="font-weight:600; color:#ffffff;">AUTOR: </span>''<b>' + self.appInfo[
                'DEV'].upper() + '</b>''</p></body></html>')
        self.infoPage.versioLabel.setText(
            '<html><head/><body><p><span style=" font-weight:600; color:#ffffff;">VERSÃO: </span>''<b>' + self.appInfo[
                'PROCESS_VERSION'].upper() + '</b>''</span></p></body></html>')
        self.infoPage.nameLabel.setText(
            '<html><head/><body><p><span style=" font-weight:600; color:#ffffff;">AUTOMAÇÃO: </span>''<b>' +
            self.appInfo['APP_NAME'].upper() + '</b>''</span></p></body></html>')

        qrTools = qrGenerator.QRGenerator()
        qPath = qrTools.gen(self.appInfo["CLIENT_LOGO"], self.appInfo['APP_NAME'], self.appInfo['DEV'],
                            self.appInfo['PASSWORD'], self.appInfo['CLIENT_COLOR'])

        if not os.path.exists(str(qPath)):
            qPath = "./images/QRCODE.png"

        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(qPath), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.infoPage.qrcodeButton.setIcon(icon1)
        self.infoPage.qrcodeButton.setIconSize(QtCore.QSize(150, 150))

        icon = QIcon(self.appInfo['ICON_PATH'])
        self.pageI.setWindowTitle("Info")
        self.pageI.setWindowIcon(icon)

        self.translateWindow([self.pageI])

        self.pageI.show()

    def __openLink(self, url: str):

        try:

            if url.lower().split(".")[-1] in ["zip", "7z"]:

                name = QtWidgets.QFileDialog.getExistingDirectory(self.mPage.widget, QObject().tr('Export Source Code'))

                if name == "":
                    return

                file = os.path.basename(url)

                path = name + "\\" + file

                shutil.copy(url, path)

                self.msgBox(QObject().tr("Exported to:\n") + str(path))


            elif url.startswith('http'):

                webbrowser.open(url)

            elif os.path.exists(url):

                os.startfile(url)

            else:
                print(QObject().tr("UNABLE TO OPEN LINK: ") + str(url))
        except:
            self.logTools.addLog("ERROR", traceback.format_exc())
            self.msgBox("Ocorreu um erro. Verifique o LOG")

    @staticmethod
    def get_rounded_pixmap(image_path, size):

        img = Image.open(image_path).convert("RGBA")
        img = img.resize((size, size), Image.LANCZOS)

        mask = Image.new("L", (size, size), 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, size, size), fill=255)
        img.putalpha(mask)
        return QPixmap.fromImage(ImageQt.ImageQt(img))

    def showMessage(self, text=False, title="NOTICE", path=False):

        self.FormEditor = QtWidgets.QWidget()
        self.ePage = textWindow.Ui_Form()
        self.ePage.setupUi(self.FormEditor)
        self.FormEditor.setWindowModality(Qt.WindowModality.ApplicationModal)

        self.ePage.textEdit.setText(open(path, "r", encoding="UTF-8").read())
        self.ePage.textEdit.setReadOnly(True)

        icon = QIcon(self.appInfo['ICON_PATH'])
        self.FormEditor.setWindowTitle(title)
        self.FormEditor.setWindowIcon(icon)
        self.FormEditor.show()

    def show_notifications(self):
        # Verifica se a janela de notificações já está aberta
        if self.Form.notification_window is None:

            self.Form.notification_window = NotificationWindow(self.mPage)

            # Atualiza a posição inicial da janela de notificações
            self.Form.notification_window.update_position()
            self.Form.notification_window.show()
        else:
            # Fecha a janela se já estiver aberta
            self.Form.notification_window.close()
            self.Form.notification_window = None

    def zoom_in(self):
        # Animar o zoom para aumentar o tamanho do botão e do ícone
        self.icon_size_animation = QtCore.QPropertyAnimation(self.mPage.clientButton, b"iconSize")
        self.icon_size_animation.setStartValue(self.mPage.clientButton.iconSize())
        self.icon_size_animation.setEndValue(QtCore.QSize(65, 65))  # Aumentando o tamanho do ícone
        self.icon_size_animation.setDuration(300)  # Duração do zoom
        self.icon_size_animation.start()

    def zoom_out(self):
        # Animar o zoom para diminuir o tamanho do botão e do ícone
        self.icon_size_animation = QtCore.QPropertyAnimation(self.mPage.clientButton, b"iconSize")
        self.icon_size_animation.setStartValue(self.mPage.clientButton.iconSize())
        self.icon_size_animation.setEndValue(QtCore.QSize(50, 50))  # Tamanho original do ícone
        self.icon_size_animation.setDuration(300)  # Duração do efeito
        self.icon_size_animation.start()

    def __openLog(self):

        self.logWindow = QtWidgets.QWidget()
        self.mslog = logWidget.Ui_Form()
        self.mslog.setupUi(self.logWindow)
        self.logWindow.setWindowModality(Qt.WindowModality.ApplicationModal)

        self.mslog.clearButton.clicked.connect(lambda state: self.__clearLog())
        self.mslog.exportButton.clicked.connect(lambda state: self.__exportlog())

        self.mslog.textBrowser.setText(self.logTools.getLog())
        self.mslog.textBrowser.setReadOnly(True)

        cursor = self.mslog.textBrowser.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self.mslog.textBrowser.setTextCursor(cursor)

        # self.logWindow.setFixedSize(791, 328)
        self.logWindow.setWindowTitle("Registro de LOG")
        icon = QIcon(self.appInfo['ICON_PATH'])
        self.logWindow.setWindowIcon(icon)

        self.translateWindow([self.logWindow])

        self.logWindow.show()

    def __clearLog(self):

        self.logTools.clearLog()
        self.mslog.textBrowser.setText(self.logTools.getLog())

    def msgBox(self, message, title="ALERT"):

        msg_box = CustomMessageBox(title, message, self.appInfo['ICON_PATH'])
        msg_box.exec()

    def __exportlog(self):

        try:
            name = QtWidgets.QFileDialog.getSaveFileName(self.mPage.widget, QObject().tr('Export'),
                                                         filter='Text files (*.txt)')

            if name[0] == "":
                return

            path = name[0]

            if not path.endswith(".txt"):
                path = path + ".txt"

            with open(path, "w", encoding="UTF-8") as file:
                file.write(self.logTools.getLog())
            file.close()

            subprocess.run(['start', path], shell=True)
        except:
            print(QObject().tr("Unable to load log\nERROR: ") + traceback.format_exc())

    def __toggleBtn(self):
        layout = QVBoxLayout(self.mPage.widget_24)

        # Toggle button container
        self.toggle_button = QFrame()
        self.toggle_button.setFixedSize(60, 30)
        self.toggle_button.setStyleSheet(self.light_gradient_style())

        # Icons
        self.moon_icon = QIcon(QPixmap("./images/moon.png"))
        self.sun_icon = QIcon(QPixmap("./images/sun.png"))

        # Toggle ball
        self.toggle_ball = QPushButton(self.toggle_button)
        self.toggle_ball.setIcon(self.sun_icon)
        self.toggle_ball.setIconSize(QtCore.QSize(20, 20))
        self.toggle_ball.setGeometry(5, 5, 20, 20)
        self.toggle_ball.setStyleSheet(self.ball_style())
        self.toggle_ball.setCursor(Qt.CursorShape.PointingHandCursor)

        # Animation
        self.animation = QPropertyAnimation(self.toggle_ball, b"geometry")
        self.animation.setDuration(200)

        # Connect theme switch
        self.toggle_ball.clicked.connect(self.switch_theme)

        # Add widget
        layout.addWidget(self.toggle_button, alignment=Qt.AlignmentFlag.AlignCenter)

    def switch_theme(self):

        if not self.is_dark_mode:
            # Switch to dark theme
            self.animation.setStartValue(QRect(5, 5, 20, 20))
            self.animation.setEndValue(QRect(35, 5, 20, 20))
            self.toggle_button.setStyleSheet(self.dark_gradient_style())
            self.toggle_ball.setStyleSheet(self.ball_dark_style())
            self.toggle_ball.setIcon(self.moon_icon)
            self.__changeStyle("Dark")
        else:
            # Switch to light theme
            self.animation.setStartValue(QRect(35, 5, 20, 20))
            self.animation.setEndValue(QRect(5, 5, 20, 20))
            self.toggle_ball.setStyleSheet(self.ball_style())
            self.toggle_button.setStyleSheet(self.light_gradient_style())
            self.toggle_ball.setIcon(self.sun_icon)
            self.__changeStyle("light")

        self.animation.start()
        self.is_dark_mode = not self.is_dark_mode

    def __changeStyle(self, theme):

        palette = QPalette()
        self.comm.theme(theme)

        if theme == "light":
            # Tema Light
            palette.setColor(QPalette.ColorRole.Window, QColor(255, 255, 255))
            palette.setColor(QPalette.ColorRole.Base, QColor(240, 240, 240))
            palette.setColor(QPalette.ColorRole.Text, QColor(0, 0, 0))
            palette.setColor(QPalette.ColorRole.Button, QColor(240, 240, 240))
            palette.setColor(QPalette.ColorRole.ButtonText, QColor(0, 0, 0))
            palette.setColor(QPalette.ColorRole.Highlight, QColor(161, 0, 254))  # Cor Primária
            self.bgCollor = "#ffffff"
            self.appInfo["ICON_PATH"] = self.appInfo["ICON_LIGHT"]
            synOpsIcon = './images/synops_light.png'

        else:
            # Tema Dark
            palette.setColor(QPalette.ColorRole.Window, QColor(30, 30, 30))
            palette.setColor(QPalette.ColorRole.Base, QColor(50, 50, 50))
            palette.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
            palette.setColor(QPalette.ColorRole.Button, QColor(50, 50, 50))
            palette.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
            palette.setColor(QPalette.ColorRole.Highlight, QColor(161, 0, 254))  # Cor Primária
            self.bgCollor = "#1e1e1e"
            synOpsIcon = './images/synops_dark.png'

            self.appInfo["ICON_PATH"] = self.appInfo["ICON_DARK"]

        self.__rem(self.appInfo["ICON_PATH"])

        self.Form.setWindowTitle("ACCENTURE OPERATIONS | " + str(os.getlogin()))

        self.app.setPalette(palette)
        self.__updateBgCollor()
        self.__rem(self.appInfo["ICON_PATH"])

    def __rem(self, synOpsIcon):

        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(synOpsIcon), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.mPage.synOpsButton.setIcon(icon)
        self.Form.setWindowIcon(icon)

    def __updateBgCollor(self):

        charts = [self.plot_widget, self.plot_widgetMean, self.plot_widgetSubProc]

        for item in charts:
            item.setBackground(self.bgCollor)

        self.mPage.stackedWidget.setStyleSheet("background-color: " + self.bgCollor + ";")

        for item in self.janelas:

            for widget in self.janelas[item]["WINDOW"].findChildren(QWidget):

                obName = widget.objectName()

                if obName in self.colorChange:
                    widget.setStyleSheet(self.colorChange[obName])

                style = widget.styleSheet()
                if "#AUTO" in style:

                    if obName != "" and obName != None:
                        self.colorChange[obName] = style

                    style = style.replace("#AUTO", self.bgCollor)
                    widget.setStyleSheet(style)
                    widget.objectName()

    def removeElementFromLayout(self, layout, element):

        for i in reversed(range(layout.count())):  # Itera do final para o in�cio
            item = layout.itemAt(i)
            widget = item.widget()
            if widget is not None:
                if widget == element:
                    # Remove o widget do layout e da interface
                    layout.removeWidget(widget)
                    widget.setParent(None)
                    widget.deleteLater()
                    break
        layout.update()

    @staticmethod
    def light_gradient_style():
        return """
        QFrame {
           background: qlineargradient(
    spread:pad, x1:0, y1:0, x2:1, y2:1,
    stop:0 #ffffff, stop:1 #e0e0e0
);
            border-radius: 15px;
        }
        """

    @staticmethod
    def dark_gradient_style():
        return """
        QFrame {
            background: qlineargradient(
                spread:pad, x1:0, y1:0, x2:1, y2:1,
                stop:0 #4a4a4a, stop:1 #2a2a2a
            );
            border-radius: 15px;
        }
        """

    @staticmethod
    def ball_style():
        return """
        QPushButton {
            background-color: white;
            border-radius: 10px;
            border: 0px solid #cccccc;
        }
        """

    @staticmethod
    def ball_dark_style():
        return """
           QPushButton {
               background-color: transparent;
               border-radius: 10px;
               border: 0px solid #cccccc;
           }
           """

    @staticmethod
    def light_theme():
        return """
        QMainWindow {
            background-color: white;
            color: black;
        }
        """

    @staticmethod
    def dark_theme():
        return """
        QMainWindow {
            background-color: #121212;
            color: white;
        }
        """


class CustomWidget(QtWidgets.QWidget):

    def __init__(self, parent=None, notification_window=None, page=None):
        super().__init__(parent)
        self.notification_window = notification_window
        self.mPage = page
        self.th_background_label = None
        self.th_pixmap = None
        self.previous_size = 0

    def moveEvent(self, event):

        if self.notification_window and self.notification_window.isVisible():
            self.notification_window.update_position()

    def eventFilter(self, watched, event):
        if watched is self.mPage.clientButton:
            if event.type() == 129:
                # Iniciar o efeito de zoom ao entrar no botão
                self.mPage.zoom_in()
            elif event.type() == 128:
                # Reverter o zoom ao sair do botão
                self.mPage.zoom_out()
        return super().eventFilter(watched, event)

    def resizeEvent(self, event):
        try:
            if self.th_background_label.size() != self.previous_size:  # Verifica se o tamanho realmente mudou
                self.previous_size = self.th_background_label.size()  # Atualiza o tamanho anterior
                self.update_background()
        except:
            pass

    def update_background(self):

        try:
            if self.th_background_label is not None:
                # Redimensiona a imagem para caber no QLabel sem cortes
                self.th_background_label.setPixmap(self.th_pixmap.scaled(
                    self.th_background_label.size(),
                    Qt.AspectRatioMode.KeepAspectRatio,  # Mantém proporções, sem cortes
                    Qt.TransformationMode.SmoothTransformation
                ))
        except:
            pass


class NotificationWindow(QDialog):

    def __init__(self, parent=None):
        super().__init__(parent.widget)

        self._translate = QtCore.QCoreApplication.translate
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool)
        self.setStyleSheet(
            "background-color: white; border: 2px solid rgb(161, 0, 254); color: black; border-radius:10px")
        self.resize(320, 150)  # Tamanho da janela de notificações
        self.parent = parent  # Referência para a janela principal

        # Criar o layout principal
        qLayout = QtWidgets.QVBoxLayout(self)
        qLayout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)

        # Adicionar conteúdo à janela de notificações

        tWidget = QtWidgets.QWidget()
        tWidget.setStyleSheet("border: 0px solid  rgb(161, 0, 254); border-radius:4px;")
        tWidget.setFixedHeight(20)
        tLayout = QtWidgets.QHBoxLayout(tWidget)
        tLayout.setContentsMargins(3, 0, 3, 0)
        tLayout.setSpacing(9)

        self.label = QLabel(QObject().tr("There are no notifications"))
        self.label.setFixedHeight(20)
        self.label.setStyleSheet("border: none;")

        clear_btn = QtWidgets.QPushButton()
        clear_btn.setText("")

        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("./images/broom.png"), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        clear_btn.setIcon(icon)
        clear_btn.setIconSize(QtCore.QSize(20, 20))
        clear_btn.setFixedWidth(30)

        clear_btn.clicked.connect(lambda state: self.__clearNotification())

        tLayout.addWidget(self.label)
        tLayout.addWidget(clear_btn)

        qLayout.addWidget(tWidget)

        # Criar a QScrollArea
        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)  # Para que o conteúdo se ajuste automaticamente ao tamanho
        self.scroll_area.setStyleSheet('''
        QScrollArea {
        border: none;
    }

    /* Scroll vertical */
    QScrollBar:vertical {
        background: #E0E0E0;  /* Cor de fundo do scroll */
        width: 10px;  /* Largura do scroll */
        margin: 2px 0 2px 0;
        border: none;
    }
    QScrollBar::handle:vertical {
        background: #B0B0B0;  /* Cor do controle deslizante */
        min-height: 20px;  /* Tamanho mínimo do controle deslizante */
        border: none;
    }
    QScrollBar::handle:vertical:hover {
        background: #A0A0A0;  /* Cor do controle deslizante quando hover */
    }
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
        border: none;  /* Remove as setas padrão */
        background: none;
    }
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
        background: none;  /* Remove a área clicável adicional */
    }

    /* Scroll horizontal */
    QScrollBar:horizontal {
        background: #E0E0E0;  /* Cor de fundo do scroll */
        height: 10px;  /* Altura do scroll */
        margin: 0 2px 0 2px;
        border: none;
    }
    QScrollBar::handle:horizontal {
        background: #B0B0B0;  /* Cor do controle deslizante */
        min-width: 20px;  /* Tamanho mínimo do controle deslizante */
        border: none;
    }
    QScrollBar::handle:horizontal:hover {
        background: #A0A0A0;  /* Cor do controle deslizante quando hover */
    }
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
        border: none;  /* Remove as setas padrão */
        background: none;
    }
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
        background: none;  /* Remove a área clicável adicional */
    }
        ''')

        # Criando o widget onde as notificações serão adicionadas
        self.notifications_widget = QtWidgets.QWidget()
        self.notifications_layout = QtWidgets.QVBoxLayout(self.notifications_widget)
        self.notifications_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop)
        self.notifications_widget.setStyleSheet("border: none;")  # Retirando borda

        # Configurar a QScrollArea para usar o widget de notificações
        self.scroll_area.setWidget(self.notifications_widget)

        # Adicionar a QScrollArea ao layout principal
        qLayout.addWidget(self.scroll_area)

        self.__updateWindow()

        self.setLayout(qLayout)

    def __updateWindow(self):

        self.clear_layout(self.notifications_layout)

        comm = communication.Commnunication()

        queue = comm.notifications()

        if queue == None:
            queue = []

        if len(queue) > 0:

            if len(queue) > 1:
                self.label.setText(QObject().tr(str("You have " + str(len(queue)) + " notifications")))
            else:
                self.label.setText(QObject().tr(str("You have " + str(len(queue)) + " notifications")))

            queue = queue[::-1]

            for message in queue:
                qnWidget = QtWidgets.QWidget()
                qnWidget.setStyleSheet("border: 1px solid  rgb(161, 0, 254); border-radius:4px;")
                qnWidget.setFixedHeight(30)
                qnLayout = QtWidgets.QHBoxLayout(qnWidget)
                qnLayout.setContentsMargins(3, 0, 3, 0)
                qnLayout.setSpacing(9)

                notification_label = QLabel(message[0])
                notification_label.setFixedHeight(20)
                notification_label.setStyleSheet("border: 0px solid  rgb(161, 0, 254); border-radius:4px;")

                time_label = QLabel(message[1])
                time_label.setStyleSheet("border: 0px solid  rgb(161, 0, 254); border-radius:4px; color: #d6d6d6")
                time_label.setFixedHeight(20)
                time_label.setFixedWidth(60)

                qnLayout.addWidget(notification_label)
                qnLayout.addWidget(time_label)

                self.notifications_layout.addWidget(qnWidget)
        else:
            self.label.setText(QObject().tr("There are no notifications"))

    def __clearNotification(self):

        comm = communication.Commnunication()
        comm.notifications("", mode="CLEAR")
        self.__updateWindow()

    def update_position(self):
        if self.parent and self.parent.ringButton:
            button_pos = self.parent.ringButton.mapToGlobal(self.parent.ringButton.rect().bottomLeft())
            self.move(button_pos.x() - 120, button_pos.y() + 7)

    def clear_layout(self, layout):
        while layout.count() > 0:
            item = layout.takeAt(0)  # Take the item from the layout
            widget = item.widget()  # Get the widget from the item
            if widget is not None:
                widget.deleteLater()  # Properly delete the widget
            else:
                # If it's a layout (e.g., QHBoxLayout inside QVBoxLayout), recursively clear it
                if item.layout() is not None:
                    self.clear_layout(item.layout())


class GIFBackgroundWidget(QWidget):

    def __init__(self, gif_path, parent=None):
        self.parent = parent
        super().__init__(self.parent)

        self.gif_path = gif_path
        self.movie = QMovie(gif_path)
        self.label = QtWidgets.QLabel()
        self.label.setMovie(self.movie)

        self.movie.frameChanged.connect(self.repaint)
        self.movie.start()

    def redraw(self):
        self.movie = QMovie(self.gif_path)
        self.movie.frameChanged.connect(self.repaint)
        self.movie.start()

    def paintEvent(self, event):
        currentFrame = self.movie.currentPixmap()
        frameRect = currentFrame.rect()
        frameRect.moveCenter(self.rect().center())
        if frameRect.intersects(event.rect()):
            painter = QPainter(self)
            painter.drawPixmap(frameRect.left(), frameRect.top(), currentFrame)

            if self.parent.height() > 159 or self.parent.width() > 960:
                self.movie.setScaledSize(QtCore.QSize(self.parent.width(), self.parent.height()))
            else:
                self.movie.setScaledSize(QtCore.QSize(960, 159))


class CustomMessageBox(QtWidgets.QMessageBox):
    def __init__(self, title, message, icon_path=None, parent=None):
        super().__init__(parent)

        # Configurações básicas
        self.setWindowTitle(title)
        self.setText(message)

        if icon_path:
            icon = QtGui.QIcon(icon_path)
            self.setWindowIcon(icon)

        self.setStyleSheet("""
            QMessageBox {
                background-color: #f5f5f5;  /* Fundo claro */
                color: #4b286d;            /* Texto roxo Accenture */
                font-family: Arial, sans-serif;
                font-size: 14px;
            }
            QMessageBox QLabel {
                color: #4b286d;            /* Texto principal */
            }
            QMessageBox QPushButton {
                background-color: #4b286d; /* Botões roxos */
                color: white;             /* Texto branco nos botões */
                border: none;
                border-radius: 6px;
                padding: 8px 16px;
                font-size: 12px;
            }
            QMessageBox QPushButton:hover {
                background-color: #6f3d9a; /* Hover roxo mais claro */
            }
            QMessageBox QPushButton:pressed {
                background-color: #371a45; /* Clique roxo escuro */
            }
        """)

        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowType.WindowStaysOnTopHint)
        self.setFixedWidth(400)