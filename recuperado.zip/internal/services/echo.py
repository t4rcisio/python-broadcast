import datetime
import os
import pickle
import subprocess
import traceback

ECHO_PATH = "C:\Program Files (x86)\Echo API\echo-api.exe"
from internal.com import communication
class Echo:

    def __init__(self):

        self.comm = communication.Commnunication()
        self.local_i = ".\\images\\com.pickle"
        self.id = None
        self.delta = None

        with open(".\images\\com.pickle", "rb") as file:
            self.appInfo = pickle.load(file)
        file.close()


    def initialize(self):

        return self.__call(ECHO_PATH + " TOKEN " + str(self.appInfo["TOKEN"]))

    def check_version(self):

        response = self.__call(ECHO_PATH + " VERSION " + str(self.appInfo["PROCESS_ID"]) + " " + str(self.appInfo["PROCESS_VERSION"]))

        if response == None:
            response = ""

        echo_version = None
        rData = response.split("\n")
        for item in rData:
            if "payload recebido" in item:
                item = item.replace("payload recebido", "").strip()
                try:
                    info = eval(item)
                    echo_version = info['version']['atual']
                except:
                    echo_version = None

        return echo_version


    def start(self, subproccess_id, subproccess_name, tm):

        self.time_start = datetime.datetime.now()
        self.id = subproccess_id
        self.tempo_manual = tm
        self.subproccess_name = subproccess_name

        return self.__call(ECHO_PATH + " START " + str(subproccess_id) + " " + str(self.appInfo["PROCESS_VERSION"]) + " " + os.getlogin())

    def end(self, subproccess_id, operations):

        self.__report(operations)
        self.id = subproccess_id
        return self.__call(ECHO_PATH + " END " + str(subproccess_id) + " " + str(operations))

    def update(self, subproccess_id, operations):

        return self.__call(ECHO_PATH + " UPDATE " + str(subproccess_id) + " " + str(operations))

    def error(self, subproccess_id, message, operations):

        self.__report(operations)
        self.id = subproccess_id
        return self.__call(ECHO_PATH + " ERRO " + str(subproccess_id) + " " + str(message).replace("\n", ""))

    def __call(self, command):

        try:
            resultado = subprocess.check_output(
                command,
                shell=False,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            print(resultado)
            return self.__decodeResponse(resultado)
        except:
            print(traceback.format_exc())


    def __decodeResponse(self, res):

        try:
           return res.decode('utf-8')
        except:
            return res


    def __report(self, operations):

        try:

            self.time_end = datetime.datetime.now()
            self.delta = self.time_end - self.time_start
            total_seconds = self.delta.total_seconds()

            payload = {"SUBPROCESS": self.id, "SUBPROCESS_NAME": self.subproccess_name, "START": self.time_start, "END": self.time_end, "DELTA": total_seconds, "OPS": operations, "TM": self.tempo_manual}
            his = self.comm.execution_report()

            if his == None:
                his = []

            his.append(payload)
            self.comm.execution_report(his)

        except:

            print(traceback.format_exc())
