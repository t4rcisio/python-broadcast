import traceback

import qrcode
from PIL import Image
ASCII_CHARS = "@%#*+=-:. "


class QRGenerator:


    def gen(self, source, appName="", devName="", password="", bgColor="white"):

        try:
            texto = "ACCENTURE AUTOMATION FACTORY\n\n"+str(appName).upper()+"\nDEV: "+str(devName).upper()+"\nSENHA: " + str(password)

            # Criação do QR Code
            qr = qrcode.QRCode(
                version=5,  # Aumente o tamanho para comportar logotipos maiores
                error_correction=qrcode.constants.ERROR_CORRECT_H,  # Alta correção de erros para suportar sobreposições
                box_size=10,
                border=4,
            )
            qr.add_data(texto)
            qr.make()

            img_qr = qr.make_image(fill_color="#a100fe", back_color="white").convert("RGB")

            try:
                logotipo = Image.open(source)

                fundo_branco = Image.new("RGB", logotipo.size, bgColor)
                fundo_branco.paste(logotipo, mask=logotipo.split()[-1])

                fundo_branco.save("./images/logotiop_emb.jpg", "JPEG")
                logotipo = Image.open("./images/logotiop_emb.jpg")


                largura_base = 100
                proporcao = largura_base / logotipo.width
                nova_altura = int(logotipo.height * proporcao)
                logotipo = logotipo.resize((largura_base, nova_altura), Image.Resampling.LANCZOS)

                posicao = (
                    (img_qr.width - logotipo.width) // 2,
                    (img_qr.height - logotipo.height) // 2,
                )
                img_qr.paste(logotipo, posicao)
            except:
                print(traceback.format_exc())

            img_qr.save("./images/QRCODE_EMB.png")

            return "./images/QRCODE_EMB.png"
        except:
            print(traceback.format_exc())


    def __resize_image(self, image, new_width=100):
        """
        Redimensiona a imagem mantendo a proporção.
        """
        width, height = image.size
        ratio = height / width / 3  # Ajuste para a proporção altura-largura
        new_height = int(new_width * ratio)
        resized_image = image.resize((new_width, new_height))
        return resized_image

    def __grayify(self, image):

        return image.convert("L")

    def __pixels_to_ascii(self, image):

        pixels = image.getdata()
        ascii_str = ""
        for pixel in pixels:
            # Garante que o índice fique dentro do intervalo [0, len(ASCII_CHARS)-1]
            ascii_str += ASCII_CHARS[min(pixel // 25, len(ASCII_CHARS) - 1)]
        return ascii_str

    def image_to_ascii(self, image_path, new_width=100):

        try:
            # Carrega e processa a imagem
            image = Image.open(image_path)
            image = self.__resize_image(image, new_width)
            image = self.__grayify(image)

            ascii_str = self.__pixels_to_ascii(image)
            img_width = image.width
            ascii_str_len = len(ascii_str)

            # Divide a string ASCII em linhas para formar a imagem
            ascii_img = ""
            for i in range(0, ascii_str_len, img_width):
                ascii_img += ascii_str[i:i + img_width] + "\n"

            return ascii_img

        except:
            return  ""


