import datetime
import re
import time
import traceback

import pandas as pd

from utils import webEngine, excelTools, tools
from internal.com import logControl, communication
from selenium.webdriver.common.by import By
from functions import sapCheckUatp
import os
class Restituicao_UATP:



    def __init__(self):

        self.drive = webEngine.Webdriver_X()
        self.excel = excelTools.ExcelTools()
        self.comm = communication.Commnunication()
        self.logTools = logControl.LogControl()
        self.tools = tools.Utils()
        self.sapUATP = sapCheckUatp.SapCheckUATP()

        self.urlLogin = 'https://datasuite.uatp.com/Authentication/Login'
        self.urlHome = ''
        self.browser = None
        self.queue = None
        self.maxCounter = 0

    def export(self):

        try:
            self.__save()
        except:
            self.logTools.addLog("ERRO", traceback.format_exc())

    def run(self, args):

        try:
            self.__run(args)
            msg = "REST UATP | PROCESSO FINALIZADO"
        except:
            msg = "OCORREU UM ERRO NO PROCESSAMENTO"
            self.logTools.addLog("ERRO", msg+"\n"+traceback.format_exc(), True)


        finally:

            try:
                self.drive.driver.quit()
            except:
                pass


            if self.queue != None:

                payload = {"TABLE": args["TABLE"], "COL_MAP": self.colMap, "QUEUE": self.queue}
                self.comm.saveTempProccess("UATP", payload)

                self.__save(args["TABLE"])

            self.comm.notifications("REST UATP | "+str(self.maxCounter) + " RESTITUIÇÕES PROCESSADAS")
            self.comm.textUpdate(msg, 0)
            self.comm.notifications(msg)

    def __run(self, args):

        self.comm.textUpdate("CARREGANDO DADOS DO ARQUIVO DE INPUT")

        _, sheet, __ = self.excel.load_excel_pd(args["FILE"], args["TABLE"])
        self.__buildQueue(sheet)

        self.accountMap = {}
        self.accountMapTable = {}
        self.uatpMap = {}

        tables = self.excel.getTableNames(args["ACC_FILE"])

        self.comm.textUpdate("CARREGANDO DADOS DO ARQUIVO DE CONTAS")


        for table in tables:
            try:
                _, accountsTable, __ = self.excel.load_excel_pd(args["ACC_FILE"], table)
                self.__buildAccountMap(accountsTable, table)
            except:
                self.logTools.addLog("ERROR", traceback.format_exc())

        self.comm.textUpdate("CARREGANDO RELATÓRIO UATP")

        uatp_cols, uatpReport, __ = self.excel.load_excel_pd(args["REST_FILE"], args["REST_TABLE"])
        self.build_uatpReport(uatp_cols, uatpReport)

        if len(self.queue) == 0 or len(self.accountMap) == 0:
            self.logTools.addLog("ERRO", "NÃO FOI POSSIVEL ENCONTRAR DADOS VÁLIDOS NO INPUT")
            self.comm.notifications("NÃO FOI POSSIVEL ENCONTRAR DADOS VÁLIDOS NO INPUT")

        self.comm.textUpdate(str(len(self.queue)) + " RESTITUIÇÕES UATP ENCONTRADAS")

        self.buildOutput()


    def buildOutput(self):

        err = False
        i = 1
        mCounter = {"False": 0, "True": 0}
        try:
            for key in self.queue:

                if str(self.comm.stop()) == "TRUE":
                    self.logTools.addLog("LOG", "O USUÁRIO PAROU O PROCESSO")
                    self.comm.stop("")
                    break

                self.comm.textUpdate("RESTITUIÇÃO | EXECUTANDO " + str(i) + " de " + str(len(self.queue)))
                self.comm.incrementOperation(1)

                '''if self.queue[key][-1][3] in self.accountMapTable:
                    self.queue[key][-1][self.colMap["TIPO"]] = self.accountMapTable[self.queue[key][-1][3]]
                else:
                    self.queue[key][-1][self.colMap["ANALISIS ACCENTURE"]] = "NÃO ENCONTRADO NO ARQUIVO DE CONTAS"'''

                if self.queue[key][-1][3] in self.accountMap:
                    self.queue[key][-1][self.colMap["CONTA"]] = self.accountMap[self.queue[key][-1][3]]
                    self.checkUATP(key, self.accountMap[self.queue[key][-1][3]])
                else:
                    self.queue[key][-1][self.colMap["ANALISIS ACCENTURE"]] = "NÃO ENCONTRADO NO ARQUIVO DE CONTAS"




                i += 1
        except:
            self.logTools.addLog("ERRO", traceback.format_exc())

        self.comm.textUpdate(
            "FINALIZANDO | " + str(mCounter["True"]) + " COM SUCESSO E " + str(mCounter["False"]) + " COM FALHA")


    def checkUATP(self, key, conta):

        for index in range(0, len(self.queue[key])):

            conta = self.tools.fixFloat2Str(conta)
            ref = str(self.queue[key][index][self.colMap['Documento Que Paga (Factura / Nota De Crédito / Liquidación)']])
            numeros = re.findall(r'\d+', ref)
            referencia = ''.join(numeros)
            pkey = conta + "#" + referencia

            if pkey in self.uatpMap:
                for i in range(0, len(self.uatpMap[pkey])):
                    value = self.uatpMap[pkey][i]
                    if value == self.queue[key][index][self.colMap["Monto De La Factura"]]:
                        self.queue[key][index][self.colMap["REST UATP"]] = "RESTITUÍDO ANTERIORMENTE"
            else:
                self.queue[key][index][self.colMap["REST UATP"]] = ""


    def build_uatpReport(self, uatp_cols, uatpReport):

        for index in range(1, len(uatpReport)):

            conta = self.tools.fixFloat2Str(uatpReport[index][uatp_cols.index('Account Number')])
            ref = str(uatpReport[index][uatp_cols.index('Reference Number')])
            numeros = re.findall(r'\d+', ref)
            referencia = ''.join(numeros)

            key = conta+"#"+referencia

            if not key in self.uatpMap:
                self.uatpMap[key] = []

            self.uatpMap[key].append(self.tools.convert2float(uatpReport[index][uatp_cols.index('Amount')]))




    def __run_old(self, args):

        checkpoint = self.__startSession(args["USER"], args["PASSWORD"])



        if not checkpoint:
            self.logTools.addLog("ERRO", "NÃO FOI POSSIVEL ACESSAR A TELA DE LOGIN")
            self.comm.notifications("NÃO FOI POSSIVEL ACESSAR A TELA DE LOGIN")
            return

        self.pagoHis = self.comm.pagoHis()
        if not isinstance(self.pagoHis, dict):
            self.pagoHis = {}

        err = False
        i = 1
        mCounter = {"False": 0, "True": 0}
        try:
            for key in self.queue:

                if str(self.comm.stop()) == "TRUE":
                    self.logTools.addLog("LOG", "O USUÁRIO PAROU O PROCESSO")
                    self.comm.stop("")
                    break

                self.comm.textUpdate("RESTITUIÇÃO | EXECUTANDO " + str(i) + " de " + str(len(self.queue)))
                self.comm.incrementOperation(1)

                pg = str(self.queue[key][-1][self.colMap['Documento Que Paga (Factura / Nota De Crédito / Liquidación)']]).strip()
                if not pg.startswith("0"):
                    pg = "0" + pg

                pago = "PAGO " + pg


                if pago in self.pagoHis:

                    msg = "ESTE DOCUMENTO FOI PROCESSADO FOI ANTERIORMENTE [" + str(self.pagoHis[pago]) + "]"

                else:
                    try:
                        checkpoint, msg = self.__checkCartaCredito(key, args)

                        if checkpoint:
                            checkpoint, msg = self.__payment(self.queue[key], pago)
                            mCounter[str(checkpoint)] += 1
                    except:
                        msg = "OCORREU UM ERRO AO PROCESSAR"

                if self.queue[key][-1][3] in self.accountMapTable:
                    self.queue[key][-1][self.colMap["CONTA UATP"]] = self.accountMapTable[self.queue[key][-1][3]]
                else:
                    self.queue[key][-1][self.colMap["CONTA UATP"]] = "NÃO ENCONTRADO NO ARQUIVO DE CONTAS"

                self.queue[key][-1][self.colMap["RESTITUICAO UATP"]] = msg
                self.comm.pagoHis(self.pagoHis)

                i +=1
        except:
            self.logTools.addLog("ERRO", traceback.format_exc())

        self.comm.textUpdate("FINALIZANDO | "+ str(mCounter["True"]) + " COM SUCESSO E " + str(mCounter["False"]) + " COM FALHA" )

    def __checkCartaCredito(self, key, args):

        status = True
        msg = ""

        for item in self.queue[key]:

            value = item[self.colMap["Monto De La Factura"]]

            if self.tools.convert2float(value) < 0:

                status, msg = self.sapUATP.search(item, self.colMap, args)

                if not status:
                    return status, msg

        return status, msg



    def __save(self, worksheet=False):

        if worksheet == False:

            self.comm.textUpdate("CARREGANDO DADOS PARA EXPORTAÇÃO")

            res = self.comm.saveTempProccess("UATP")
            if not isinstance(res, dict):
                self.logTools.addLog("ERRO", "NÃO HÁ DADOS PARA EXPORTAÇÃO")
                self.comm.notifications("NÃO HÁ DADOS PARA EXPORTAÇÃO")
                return

            worksheet = res["TABLE"]
            self.colMap = res["COL_MAP"]
            self.queue = res["QUEUE"]


        self.comm.textUpdate("SALVANDO RESULTADO EM RESTITUIÇÃO UATP.xlsx")
        dest = "C:\\Users\\" + str(os.getlogin()) + "\\Downloads\\RESTITUIÇÃO UATP_"+str(datetime.datetime.now().strftime("%d.%m.%Y_%H.%M"))+".xlsx"


        data = []
        data.append(list(self.colMap.keys()))

        for key in self.queue:
            for row in self.queue[key]:
                data.append(row)

            data.append(["" for i in self.colMap])

        temp = self.comm.tempPath + "/temp.txt"
        self.excel.saveData(dest, worksheet, temp, data)

        self.comm.textUpdate("SALVANDO RESULTADO EM RESTITUIÇÃO UATP_FIORI.xlsx")
        self.__saveFiori()

        self.comm.notifications("COMPLETO! SALVO EM: \Downloads\RESTITUIÇÃO UATP.xlsx")

    def __saveFiori(self):

        cols = ["Número de cuenta",	"Monto", "Fecha",	"Tipo de cuenta", "identificador de pago"]
        data = []
        data.append(cols)
        for key in self.queue:
            for row in self.queue[key]:

                if str(row[self.colMap["CONTA"]]).strip() != "":
                    data.append([row[self.colMap["CONTA"]],row[self.colMap['Monto De La Factura']], row[self.colMap['Fecha De Depósito.Pago']],	"1045", "Pago"])

        dest = "C:\\Users\\" + str(os.getlogin()) + "\\Downloads\\RESTITUIÇÃO UATP_FIORI_" + str(datetime.datetime.now().strftime("%d.%m.%Y_%H.%M")) + ".xlsx"
        self.tools.deleteFile(dest)

        worksheet = pd.DataFrame(data, columns=cols, index=None)

        worksheet.to_excel(dest)

        self.comm.notifications("COMPLETO! SALVO EM: \Downloads\RESTITUIÇÃO UATP_FIORI.xlsx")

    def __payment(self, paymentdata, pago):

        self.drive.driver.get('https://datasuite.uatp.com/Payments/PaymentEntry')

        checkpoint = self.drive.getText(By.XPATH, '//*[@id="div-payment-entry-inner-form"]/div[1]/div[1]/label', timeAfter=1, max=10)
        if str(checkpoint) != 'Add a new Batch Number':
            return False, "OCORREU UM ERRO A PROCESSAR O PAGAMENTO"


        self.drive.click(By.XPATH, '//*[@id="div-payment-entry-inner-form"]/div[1]/div[1]/a', timeAfter=2, max=2)
        self.drive.click(By.XPATH, '//*[@id="gridPaymentEntry"]/div[1]/span/a', timeAfter=2, max=3)
        time.sleep(3)

        if not paymentdata[-1][3] in self.accountMap:
            return False, "CONTA NÃO ENCONTRADA NO ARQUIVO DE CONTAS"

        acc = self.accountMap[paymentdata[-1][self.colMap['Documento Que Paga (Factura / Nota De Crédito / Liquidación)']]]

        self.drive.click(By.XPATH, '//*[@id="gridPaymentEntry"]/div[2]/table/tbody/tr/td[1]/span[1]/span/span[2]',timeAfter=3, max=2)
        self.drive.sendKeys(By.XPATH, '//*[@id="AccountId-list"]/span/input', str(acc), timeAfter=1, max=5)
        self.drive.click(By.XPATH, '//*[@id="AccountId_listbox"]/li', timeAfter=1, max=2)


        checkpoint = self.drive.getText(By.XPATH, '//*[@id="gridPaymentEntry"]/div[2]/table/tbody/tr/td[1]/span[1]/span/span[1]', timeAfter=1, max=2)

        if not str(acc) in str(checkpoint):
            return False, "NÃO FOI POSSÍVEL SELECIONAR [ACCOUNT]"

        value = self.tools.fixFloat2Str(paymentdata[-1][self.colMap['Monto De La Factura']])

        if value == "":
            return False, "VALOR INVÁLIDO"

        if value == "0":
            return False, "MONTO IGUAL A 0"

        if "-" in str(paymentdata[-1][self.colMap['Monto Depositado']]):
            return False, "NOTA DE CRÉDITO"

        checkpoint = self.drive.sendKeys(By.XPATH, '//*[@id="Amount"]', value, timeAfter=1, max=5)

        if not checkpoint:
            return False, "ERRO DE PREENCHIMENTO [AMOUNT]"

        self.drive.click(By.XPATH, '//*[@id="gridPaymentEntry"]/div[2]/table/tbody/tr/td[10]/span[1]/span',  timeAfter=1, max=2)

        for i in range(1, 10):
            text = self.drive.getText(By.XPATH, '//*[@id="Type_listbox"]/li['+str(i)+']', timeAfter=1, max=2)

            if 'Bank' in str(text):
                self.drive.click(By.XPATH, '//*[@id="Type_listbox"]/li[' + str(i) + ']', timeAfter=1, max=2)
                break

        checkpoint = self.drive.getText(By.XPATH, '//*[@id="gridPaymentEntry"]/div[2]/table/tbody/tr/td[10]/span[1]/span',  timeAfter=1, max=2)
        if not "Bank" in checkpoint:
            return False, "ERRO DE PREENCHIMENTO [PAYMENT TYPE]"

        checkpoint = self.drive.sendKeys(By.XPATH, '//*[@id="ReferenceNumber"]', pago, timeAfter=1, max=2)

        if not checkpoint:
            return False, "ERRO DE PREENCHIMENTO [REFERENCIA]"


        date = paymentdata[-1][self.colMap['Fecha De Depósito.Pago']].replace(".", "/")

        if date == "":
            return False, "ERRO CAMPO DE DATA VAZIO"

        checkpoint = self.drive.sendKeys(By.XPATH, '//*[@id="PaymentDate"]', date, timeAfter=1, max=2)

        if not checkpoint:
            return False, "ERRO DE PREENCHIMENTO [DATE]"

        checkpoint = self.drive.click(By.XPATH, '//*[@id="gridPaymentEntry"]/div[2]/table/tbody/tr/td[15]/a[1]', timeAfter=1, max=2)

        if not checkpoint:
            return False, "ERRO DE PREENCHIMENTO [CONFIRM]"

        editar = self.drive.getText(By.XPATH, '//*[@id="gridPaymentEntry"]/div[2]/table/tbody/tr/td[15]/a[1]', timeAfter=1, max=2)
        btn =  self.drive.getText(By.XPATH, '//*[@id="div-payment-entry-inner-form"]/div[2]/div[2]', timeAfter=1, max=2)

        checkpoint = self.drive.click(By.XPATH, '//*[@id="div-payment-entry-inner-form"]/div[2]/div[2]/a[2]', timeAfter=1, max=2)

        if not checkpoint:
            return False, "ERRO AO ENVIAR BATCH [SALVAR]"

        self.maxCounter += 1
        return self.__confirm(date, pago)





    def __confirm(self, date, pago):

        self.drive.driver.get('https://datasuite.uatp.com/Payments/PaymentsAdjustmentsSearch')

        self.drive.sendKeys(By.XPATH, '//*[@id="PaymentDateFrom"]', date, timeAfter=1, max=5) # de
        self.drive.sendKeys(By.XPATH, '//*[@id="PaymentDateTo"]', date, timeAfter=1, max=2) #ATE

        self.drive.sendKeys(By.XPATH, '//*[@id="ReferenceNumber"]', pago, timeAfter=1, max=2) #PAGO

        self.drive.click(By.XPATH, '//*[@id="PaymentsAdjustmentsSearchform"]/div[1]/div[2]/div/div/a[1]', timeAfter=5, max=2)

        data_formatada = datetime.datetime.today().strftime("%d.%m.%Y")

        for i in range(0, 5):
            checkpoint = self.drive.getText(By.XPATH, '//*[@id="GridPaymentAdjustment"]/div[2]/table/tbody/tr/td[11]', timeAfter=1, max=5)

            rows = self.drive.getText(By.XPATH, '//*[@id="GridPaymentAdjustment"]/div[3]/span[2]')
            mRows = -1
            if rows != False:
                try:
                    mRows = int(rows.split(" ")[-1])
                except:
                    mRows = -1

            if mRows > 1:
                self.pagoHis[pago] = str(pago) + " - " + str(data_formatada)
                return True, "DUPLICADO PROCESSO CONCLUÍDO - " + str(pago) + " - " + str(data_formatada)

            if str(checkpoint) == pago:
                self.pagoHis[pago] = str(pago) + " - " + str(data_formatada)
                return True, "PROCESSO CONCLUÍDO - " + str(pago) + " - " + str(data_formatada)

            time.sleep(2)

        count = self.drive.getText(By.XPATH, '//*[@id="GridPaymentAdjustment"]/div[3]/div/ul/li/span', timeAfter=1, max=5)

        if count != False:
            try:
                if int(count) == 0:
                    return False, "REGISTRO NÃO ENCONTRADO - " + str(pago) + " - " + str(data_formatada)
            except:
                pass

        return False, "NÃO FOI POSSIVEL CONFIRMAR EM 'Payments and Adjustments Search'"



    def __startSession(self, user, password):


        if self.browser != None:
            try:
                self.drive.driver.quit()
            except:
                pass

        self.browser = self.drive.openBrowser(self.comm.tempPath)
        self.drive.driver.get(self.urlLogin)

        self.comm.textUpdate("FAZENDO LOGIN EM UATP")

        res = self.drive.sendKeys(By.XPATH, '//*[@id="UserName"]', user, timeAfter=1, max=15)

        if not res:
            return False

        self.drive.sendKeys(By.XPATH, '//*[@id="Password"]', password, timeAfter=1, max=3)

        self.drive.click(By.XPATH, '/html/body/section/div[1]/div[1]/form/button', timeAfter=1, max=3)

        self.drive.driver.maximize_window()

        checkpoint = self.drive.getText(By.XPATH, '//*[@id="uatp"]/div[1]/div[4]/div/div/div/form/div/div[1]/h6', timeAfter=1, max=10)

        if "VERIFICATION CODE" in str(checkpoint).upper():

            for i in range(0, 60):

                self.comm.textUpdate("AGUARDANDO AUTENTICAÇÃO EM 2 FATORES. VERIFIQUE O EMAIL | " + str(i) + " DE " + str(60))

                checkpoint = self.drive.getText(By.XPATH, '//*[@id="spanUsername"]', timeAfter=1, max=1)
                if not str(user).upper().strip() in str(checkpoint).upper().strip() and not checkpoint:
                    break
                time.sleep(1)


        checkpoint = self.drive.getText(By.XPATH, '//*[@id="spanUsername"]', timeAfter=1, max=10)
        if not str(user).upper().strip() in str(checkpoint).upper().strip() and not checkpoint:
            return False


        return True



    def __buildAccountMap(self, sheet, tName):


        colMap = {}

        sheet[0] = self.excel.fixNaN(sheet[0])
        for index in range(0, len(sheet[0])):

            colName = str(sheet[0][index]).strip().upper()

            if colName != "":
                colMap[colName] = index

        for index in range(1, len(sheet)):

            sheet[index] = self.excel.fixNaN(sheet[index])

            sheet[index][colMap['FACTURA']] = self.tools.fixFloat2Str(sheet[index][colMap['FACTURA']])
            sheet[index][colMap['ACCOUNT']] = self.tools.fixFloat2Str(sheet[index][colMap['ACCOUNT']])

            key = sheet[index][colMap['FACTURA']].strip()
            data = sheet[index][colMap['ACCOUNT']].strip()

            if key != "" and data != "":
                self.accountMap[key] = data
                self.accountMapTable[key] = tName

    def __buildQueue(self, sheet):

        self.colMap = {}
        self.queue = {}

        sheet[0].append("CONTA")
        sheet[0].append("TIPO")
        sheet[0].append("REST UATP")
        sheet[0].append("ANALISIS ACCENTURE")



        for index in range(0, len(sheet[0])):
            self.colMap[sheet[0][index]] = index

        ctrl = 1
        for index in range(len(sheet) - 1, 0, -1):

            row = self.excel.fixNaN(sheet[index])
            row = self.__fixFloat(row)
            if len(row) < len(sheet[0]):

                dif = len(sheet[0]) - len(row)
                for i in range(0, dif):
                    row.append("")

            mkey = str(row[self.colMap['Rut/Dni/Bp/Iata Cliente Emisor']]).strip()
            if mkey != '':

                if not ctrl in self.queue:
                    self.queue[ctrl] = []

                self.queue[ctrl].append(row)

            else:
                ctrl +=1

        for item in self.queue:
                self.queue[item] = self.queue[item][::-1]

        self.__fixNC()

        self.__fixQueue()


    def __fixNC(self):

        for item in self.queue:

            ncRows = []
            resRows = []

            for row in self.queue[item]:

                v = str(row[self.colMap["Monto De La Factura"]])

                if "-" in v:
                    ncRows.append(row)
                else:
                    resRows.append(row)


            if len(ncRows) == 0:
                continue

            totalNC = 0
            for row in ncRows:

                tnc = row[self.colMap["Monto De La Factura"]]

                if not isinstance(tnc, int) and not isinstance(tnc, float):
                    tnc = 0 - int(self.tools.convert2float(tnc))

                if tnc > 0:
                    tnc = 0 - tnc

                totalNC += tnc


            while totalNC < 0:

                ctrl = False

                for index in range(0, len(resRows)):

                    if totalNC == 0:
                        break

                    tRes = resRows[index][self.colMap["Monto De La Factura"]]

                    if not isinstance(tRes, int) and not isinstance(tRes, float):
                        tRes = int(self.tools.convert2float(tRes))


                    if tRes >= abs(totalNC):
                        resRows[index][self.colMap["Observación"]] += " MONTO ALTERADO POR NOTA DE CREDITO ["+str(tRes)+"]"

                        resRows[index][self.colMap["Monto De La Factura"]] = tRes + totalNC
                        totalNC = 0

                for index in range(0, len(resRows)):

                    if totalNC == 0:
                        break

                    tRes = resRows[index][self.colMap["Monto De La Factura"]]

                    if not isinstance(tRes, int) and not isinstance(tRes, float):
                        tRes = int(self.tools.convert2float(tRes))

                    if tRes < abs(totalNC):
                        resRows[index][self.colMap["Observación"]] += " MONTO ALTERADO POR NOTA DE CREDITO [" + str(tRes) + "]"
                        resRows[index][self.colMap["Monto De La Factura"]] = 0
                        totalNC = totalNC + tRes
                        ctrl = True


                if not ctrl:
                    break

            self.queue[item] = resRows + ncRows










    def __fixQueue(self):

        tempQueue = {}

        for item in self.queue:

            date = ""
            for i in range(0, len(self.queue[item])):
                if str(self.queue[item][i][self.colMap["Fecha De Depósito.Pago"]]).strip() != "":
                    date = self.queue[item][i][self.colMap["Fecha De Depósito.Pago"]]
                    break

            for index in range(0, len(self.queue[item])):

                self.queue[item][index][self.colMap['Monto Depositado']] = self.queue[item][index][self.colMap['Monto De La Factura']]
                self.queue[item][index][self.colMap["Fecha De Depósito.Pago"]] = date

                self.queue[item][index][self.colMap["Cuenta De Banco Destinatario"]] = self.queue[item][-1][self.colMap["Cuenta De Banco Destinatario"]]
                self.queue[item][index][self.colMap["Forma De Pago"]] = self.queue[item][-1][self.colMap["Forma De Pago"]]
                self.queue[item][index][self.colMap["Nombre Banco Destinatario"]] = self.queue[item][-1][self.colMap["Nombre Banco Destinatario"]]
                self.queue[item][index][self.colMap["Atruibuiciõn"]] = self.queue[item][-1][self.colMap["Atruibuiciõn"]]
                self.queue[item][index][self.colMap["Numero Documento Sap (Sb)"]] = self.queue[item][-1][self.colMap["Numero Documento Sap (Sb)"]]

                key = str(item)+str(index)
                tempQueue[key] = [self.queue[item][index]]

        self.queue = tempQueue
    def __fixFloat(self, row):


        col = ['Cuenta De Banco Destinatario','Documento Que Paga (Factura / Nota De Crédito / Liquidación)','Rut/Dni/Bp/Iata Cliente Emisor', 'Número Documento Sap', 'Numero Documento Sap (Sb)']

        for i in col:

            if i in self.colMap:
                row[self.colMap[i]] = self.tools.fixFloat2Str(row[self.colMap[i]])


        return row