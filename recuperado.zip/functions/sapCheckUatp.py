import os
import subprocess
import time
import traceback

from utils import excelUtils, broadcast, sapManager, tools
from utils import excelTools

from internal.com import communication, logControl
from internal.services import echo


class SapCheckUATP:


    def __init__(self):

        self.excelTools = excelUtils.XlsxUtils()
        self.excelUtils = excelTools.ExcelTools()
        self.broadcast = broadcast.Broadcast()
        self.logTools = logControl.LogControl()
        self.sapTools = sapManager.SAPManager()
        self.tools = tools.Utils()
        self.comm = communication.Commnunication()
        self.echo = echo.Echo()
        self.ctrl = False
        self.constasMap = {}


    def start(self, payload):

        if not self.sapTools.startSAP(payload["SAP_USER"], payload["SAP_PASSWORD"], payload["SAP_CONNECTION"]):
            self.comm.notifications("OCORREU UM ERRO AO INICIALIZAR O SAP")
            return True
        return True

    def search(self, row, colMap, args):

        self.colMap = colMap

        if not self.ctrl:
            self.ctrl = self.start(args)

        self.__loadContas()

        if not self.ctrl:
            return False, "OCORREU UM ERRO AO INICIALIZAR O SAP"

        self.sapTools.openTransaction("FB03")

        self.sapTools.press("LISTAR","wnd[0]/tbar[1]/btn[20]")

        self.sapTools.setText("SOCIEDADE", "wnd[0]/usr/ctxtBR_BUKRS-LOW", row[self.colMap["Sociedad"]])

        ref = row[self.colMap['Documento Que Paga (Factura / Nota De Crédito / Liquidación)']]

        self.sapTools.setText("REFERENCIA", "wnd[0]/usr/txtBR_XBLNR-LOW", ref)

        checkpoint = self.sapTools.press("RELÓGIO", "wnd[0]/tbar[1]/btn[8]")

        if not checkpoint:
            self.__goHome()
            return False, "OCORREU UM ERRO NA VERIFICAÇÃO FB03"


        checkpoint =  str(self.sapTools.getSAPmsg())

        if 'No existe' in checkpoint:
            self.__goHome()
            return False, checkpoint.strip() + " " + str(ref)

        self.sapTools.currentCell("USER", "wnd[0]/usr/cntlGRID1/shellcont/shell", "USNAM", select=True, timeAfter=1)
        self.sapTools.currentCell("USER", "wnd[0]/usr/cntlGRID1/shellcont/shell",  dbClick=True, timeAfter=1)


        error = False

        index = 0
        while not error:

            try:
                self.sapTools.session.findById("wnd[0]/usr/cntlCTRL_CONTAINERBSEG/shellcont/shell").setCurrentCell(index, "HKONT")
                self.sapTools.currentCell("CONTA", "wnd[0]/usr/cntlCTRL_CONTAINERBSEG/shellcont/shell", dbClick=True, timeAfter=1)
                conta = self.sapTools.getText("CONTA","wnd[0]/usr/ctxtBSEG-HKONT", timeAfter=1)

                if str(conta) in self.constasMap:
                    self.constasMap[str(conta)] = True

                self.sapTools.press("VOLTAR","wnd[0]/tbar[0]/btn[3]", timeAfter=2)

            except:
                error = True

            index +=1

        self.__goHome()

        for pConta in self.constasMap:
            if self.constasMap[pConta] == False:
                return False, "CONTA INVÁLIDA"

        return True, ""



    def __goHome(self):

        self.sapTools.press("VOLTAR","wnd[0]/tbar[0]/btn[3]", timeAfter=2)
        self.sapTools.press("VOLTAR","wnd[0]/tbar[0]/btn[3]",timeAfter=2)
        self.sapTools.press("VOLTAR","wnd[0]/tbar[0]/btn[3]",timeAfter=2)
        self.sapTools.press("VOLTAR","wnd[0]/tbar[0]/btn[3]",timeAfter=2)

    def __loadContas(self):

        headers, data, row_count = self.excelUtils.loadTable_v2(self.broadcast.template(), "CONTAS UATP")


        for row in data[1:]:

            row = self.excelUtils.fixNaN(row)

            key = self.tools.fixFloat2Str(row[0])

            if key != "":

                self.constasMap[key] = False