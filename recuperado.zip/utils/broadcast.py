import os
import pickle
from queue import Queue

from contextlib import contextmanager
from filelock import FileLock
@contextmanager
def dummy_lock():
    yield  # Não faz nada, mas permite o uso de 'with'

class Broadcast:

    def __init__(self):

        self.appName = "Carteiras e compensação"
        self.parentFolder = "C:/Automation"
        self.appFolder = "C:/Automation/" + self.appName

        self.confFolder = self.appFolder + "/registers"
        self.downloadsFolder = self.appFolder + "/downloads"
        self.tempFolder = self.appFolder + "/temp"
        self.dataBase = self.appFolder + "/database"
        self.log = self.appFolder + "/log"

        self.createFolder(self.parentFolder)
        self.createFolder(self.appFolder)
        self.createFolder(self.confFolder)
        self.createFolder(self.downloadsFolder)
        self.createFolder(self.tempFolder)
        self.createFolder(self.dataBase)
        self.createFolder(self.log)
        self.cache = ""
        self.lock = False

        payload = {"Home": self.appFolder, "CONF": self.confFolder, "DOWNLOADS": self.downloadsFolder,
                    "TEMP": self.tempFolder, "DATABASE": self.dataBase, "LOG": self.log}
        self.homePath(payload)

        self.folder = self.confFolder

    def homePath(self, data=False):

        temp = self.__dataControl("HOME.reg", data, self.confFolder)
        if temp == "":
            return False
        return temp

    def template(self, data=False):

        return self.__dataControl("template.pickle", data)


    def stopProc(self, data=False):

        return self.__dataControl("stopProc.pickle", data)

    def tempData(self, data=False):

        return self.__dataControl("tempData.pickle", data)



    def payload(self, data=False):

        return self.__dataControl("payload.pickle", data)

    def payloadQueue(self):

        lock = FileLock("queue" + ".lock")

        try:
            with lock:

                data = self.__dataControl("payload.pickle", False, locker=True)
                if data != None:
                    if len(data) == 0:
                        return "FIM"

                    first = list(data.keys())[0]
                    cache = data[first]
                    del data[first]
                    self.__dataControl("payload.pickle", data)
                    return [first, cache]
                else:
                    return [None, None]
        except:
            return [None, None]

    def appInfo(self, data=False):

        return self.__dataControl("appInfo.pickle", data)

    def dataTh(self, id, data=False):

        return self.__dataControl("dataTh_" + str(id) + ".pickle", data)

    def dataFCmm(self, index, data=False):

        return self.__dataControl("dataFCmm" + str(index) + ".pickle", data)

    def broadcastText(self, data=False, index=None, getData=False):

        if index == None and not getData:
            return self.__dataControl("broadcastText.pickle", data)
        elif index != None and not getData:
            path = "broadcastText_"+str(index)+".pickle"
            self.__broadcastTextCtrl(path)
            return self.__dataControl(path, data)
        elif getData:
            return self.broadcastTextCtrl_getData()

    def __broadcastTextCtrl(self, path):

        data = self.__dataControl("mxBr.pickle" , False)

        if data == None:
            data = {}

        data[path] = path
        self.__dataControl("mxBr.pickle", data)

    def broadcastTextCtrl_clear(self):

        data = self.__dataControl("mxBr.pickle", False)

        if data == None:
            data = {}

        for i in data:
            try:
                os.remove(self.homePath()['CONF'] + "/" + i)
            except:
                pass


    def broadcastTextCtrl_getData(self):

        data = self.__dataControl("mxBr.pickle", False)

        if data == None:
            data = {}

        text = ""
        for i in data:
            res = self.__dataControl(i, False)
            if res != None:
                text += "<p>" + str(res) + "</p>"

        return text

    def masterCRTL(self, data=False):

        return self.__dataControl("masterCRTL.pickle", data)

    def userExportData(self, data=False):

        return self.__dataControl("userExportData.pickle", data)

    def fopData(self, data=False):

        return self.__dataControl("fopData.pickle", folder=self.homePath()['DATABASE'], data=data)

    def historicSearch(self, data=False):

        return self.__dataControl("historicSearch.pickle", folder=self.homePath()['DATABASE'], data=data)

    def cartolaStorage(self, data=False):

        return self.__dataControl("cartolaStorage.pickle", folder=self.homePath()['DATABASE'], data=data)

    def baseHistoric(self, data=False):

        return self.__dataControlTrust("baseHistoric.pickle", folder=self.homePath()['DATABASE'], data=data)

    def chart(self, data=False):

        return self.__dataControlTrust("chart.pickle", folder=self.homePath()['DATABASE'], data=data)

    def register(self, data=False):

        return self.__dataControl("register.pickle", folder=self.homePath()['LOG'], data=data)


    def smartCache(self, data=False):

        vData =  self.__dataControl("smartCache.pickle", data)
        if vData == "" or vData == None:
            return {}
        return vData

    def threadEN(self, data=False):

        return self.__dataControl("threadEN.pickle", folder=self.folder, data=data)


    def createFolder(self, path):

        try:
            if not os.path.exists(path):
                os.mkdir(path)
        except:
            None

    def __dataControlTrust(self, path, data=False, folder=False):

        if folder == False:
            folder = self.homePath()['CONF']


        if data != False:

            with open(folder + "/" + path, "wb") as file:
                pickle.dump(data, file)
            file.close()
            return str(data)

        else:

            if not os.path.exists(folder + "/" + path):
                return ""

            with open(folder + "/" + path, "rb") as file:
                content = pickle.load(file)
            file.close()
            return content



    def __dataControl(self, path, data=False, folder=False, locker=False):

        lockFile = path + ".lock"

        if locker:
            lock = FileLock(lockFile)
        else:
            lock = dummy_lock()

        res = None

        if folder == False:
            folder = self.folder

        try:

            with lock:

                if data != False:

                    with open(folder + "/" + path, "wb") as file:
                        pickle.dump(data, file)
                    file.close()
                    return str(data)

                else:
                    try:
                        with open(folder + "/" + path, "rb") as file:
                            content = pickle.load(file)
                        file.close()
                        return content
                    except:
                        return None
        except:
            return None