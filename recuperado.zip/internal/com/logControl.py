import os.path
import traceback

from internal.com import communication
import datetime

class LogControl:

    logPath = None

    def __init__(self):

        self.com = communication.Commnunication()
        self.logFolder = self.com.logPath


    def addLog(self, title, message, echoErro=False):


        if echoErro:
            self.com.automationError({"STATUS": True, "MESSAGE": message})

        if not os.path.exists(str(self.logPath)):

            self.com = communication.Commnunication()
            self.logFolder = self.com.logPath

        try:

            date = str(datetime.datetime.now()).split(".")[0]

            payload = "DATE: " + date + "\nTITLE: " + str(title) + '\nMESSAGE: ' + str(message)
            payload = "\n-----------------------------------\n" + payload

            with open(self.logFolder + "/LOG.log", "a", encoding='UTF-8') as file:
                file.write(payload)
            file.close()

        except:
            print(traceback.format_exc())


    def getLog(self):


        try:
            with open(self.logFolder + "/LOG.log", "r", encoding='UTF-8') as file:
                data = file.read()
                return data
        except:
            return "No data"


    def clearLog(self):


        try:
            with open(self.logFolder + "/LOG.log", "w", encoding='UTF-8') as file:
                file.write("")
            file.close()
            return "No data"
        except:
            return "No data"
