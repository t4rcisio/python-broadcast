
import traceback
import psutil
import win32com.client
import subprocess
import time
from internal.com import logControl

class SAPManager:


    def __init__(self):

        self.SAPath = r'C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe'
        self.session = None
        self.logTools = logControl.LogControl()



    def startSAP(self, user, password, connection):
        self.killSAP()

        if not self.__start(1):
            self.killSAP()
            if not self.__start(3):
                self.__genError(message="Falha na conexão com o SAP. Tente novamente!")
                return False
        try:
            self.connection_parent = self.application.OpenConnection(connection, True)
            self.session = self.connection_parent.Children(0)

            return self.__getLogin(user, password)

        except:
            self.__genError("Falha ao abrir a conexão: " + str(connection) + ". Tente novamente!")
            return False


    def __getLogin(self,user, password):

        try:
            self.press("Message1", "wnd[1]/tbar[0]/btn[0]")
            self.press("Message1", "wnd[1]/tbar[0]/btn[12]")
        except:
            None

        try:
            self.session.findById("wnd[0]").maximize
            self.setText("User login", "wnd[0]/usr/txtRSYST-BNAME", user)
            self.setText("Password","wnd[0]/usr/pwdRSYST-BCODE", password)
            self.setText("Language","wnd[0]/usr/txtRSYST-LANGU", "es")
            self.session.findById("wnd[0]").sendVKey(0)
            time.sleep(3)
        except:
            error = "Ocorreu um erro durante o login. Verifique suas credenciais.\n" + str(traceback.format_exc())
            self.__genError(message=error)


        try:
            self.press("Message1","wnd[1]/tbar[0]/btn[0]")
            self.press("Message1","wnd[1]/tbar[0]/btn[12]")
        except:
            None

        try:
            self.session.findById("wnd[1]/usr/radMULTI_LOGON_OPT1").select()
            self.sendKey("Confirm stay logged", "wnd[1]", 0)
        except:
            None

        try:
            self.session.findById("wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell").selectedNode = "Favo"
            return True
        except:

            self.__genError("Erro ao fazer login, verifique seu login e senha.")
            return False

    def __start(self, timer=1):

        try:
            subprocess.Popen(self.SAPath)
            time.sleep(5 * timer)
            self.gui = win32com.client.GetObject('SAPGUI')

            time.sleep(3 * timer)
            self.application = self.gui.GetScriptingEngine
            time.sleep(5)
            return True
        except:
            error = "Ocorreu um erro ao inicializar o SAP. Tente novamente.\n" + str(traceback.format_exc())
            self.__genError(error)

    def openTransaction(self, transaction):

        self.press("Search button", "wnd[0]/tbar[0]/btn[71]", timeAfter=1)
        self.setText("Miro text", "wnd[1]/usr/txt130_FIND", transaction)
        self.caretPosition("Position", "wnd[1]/usr/txt130_FIND", 4, timeAfter=2)
        self.sendKey("Confirm search", "wnd[1]", 0, timeAfter=1)
        self.sendKey("Confirm search", "wnd[0]", 0)

        if 'SAP.TableTreeControl.1' == str(self.getText('o', "wnd[0]/usr/cntlIMAGE_CONTAINER/shellcont/shell/shellcont[0]/shell")):

            self.setText("text", "wnd[0]/tbar[0]/okcd", transaction)
            self.sendKey("confirm", "wnd[0]", 0)


    def caretPosition(self, itemName, id, position, timeAfter=0):
        try:
            self.session.findById(id).caretPosition = position
            time.sleep(timeAfter)
            return True
        except:
            msg = "Ocorreu um erro ao tentar inserir o valor "+str(position)+" do campo " + str(itemName)
            self.__genError(msg)
            time.sleep(timeAfter)
            return False

    def select(self, itemName, id, timeAfter=0):
        try:
            self.session.findById(id).select()
            time.sleep(timeAfter)
            return True
        except:
            msg = "Ocorreu um erro ao tentar selecionar o campo " + str(itemName)
            self.__genError(msg)
            time.sleep(timeAfter)
            return False

    def getText(self, itemName, id, timeAfter=0):

        try:
            testData = self.session.findById(id).text
            time.sleep(timeAfter)
            return testData
        except:

            msg = "Ocorreu um erro ao tentar ler o valor do campo " + str(itemName)
            self.__genError(msg)
            time.sleep(timeAfter)
            return False

    def setText(self, itemName, id, data, timeAfter=0):

        try:

            self.session.findById(id).text = data
            time.sleep(timeAfter)
            return True
        except:
            msg = "Ocorreu um erro ao tentar gravar o valor " + str(data) + " no campo " + str(itemName)
            self.__genError(msg)
            time.sleep(timeAfter)
            return False

    def press(self, itemName, id, keyname=None, op=0, timeAfter=0, skipLog=False):
        try:
            if keyname != None:

                if op == 1:
                    self.session.findById(id).pressButton(keyname)
                    time.sleep(timeAfter)
                    return True
                else:
                    self.session.findById(id).pressKey(keyname)
                    time.sleep(timeAfter)
                    return True
            else:
                self.session.findById(id).press()
                time.sleep(timeAfter)
                return True

        except:
            if not skipLog:
                error = 'Durante o preenchimenbto dos dados, o SAP gerou um erro. Campo: ' + str(itemName)
                self.__genError(error)
            time.sleep(timeAfter)
            return False

    def sendKey(self, itemName, id, key, mKey=False, timeAfter=0):
        try:
            if mKey:
                self.session.findById(id).key = key
            else:
                self.session.findById(id).sendVKey(key)

            time.sleep(timeAfter)
            return True
        except:

            msg = "Ocorreu um erro ao tentar gravar o valor " + str(key) + " no campo " + str(itemName)
            self.__genError(msg)
            time.sleep(timeAfter)
            return False



    def currentCell(self, itemName, id, key="", select=False, dbClick=False, timeAfter=0):
        try:
            if select:
                self.session.findById(id).currentCellColumn = key
            if dbClick:
                self.session.findById(id).doubleClickCurrentCell()
            time.sleep(timeAfter)
            return True
        except:

            msg = "Ocorreu um erro ao tentar gravar o valor " + str(key) + " no campo " + str(itemName)
            self.__genError(msg)
            time.sleep(timeAfter)
            return False



    def killSAP(self):

        try:

            for proc in psutil.process_iter():
                if "saplogon.exe" in proc.name():
                    print("KILLED")
                    proc.kill()
        except:
            print(traceback.format_exc())
    def getSAPmsg(self):
        try:

            content = ""

            try:
                str(self.session)
            except:
                content = traceback.format_exc()

            if "The object invoked has disconnected" in content:
                self.session = False
                return " - O SAP foi encerrado"

            data = self.session.findById("wnd[0]/sbar").text

            if str(data) != "":
                return " - " + str(data)
            else:
                return str(data)
        except:
            return ""


    def __genError(self, message=""):

        sapDialog = self.getSAPmsg()
        errMsg = "SAP MESSAGE: " + str(sapDialog) + "\n" + message
        err = traceback.format_exc()

        response = "SAP MESSAGE: " + str(sapDialog) + "\nDESCRIPTION: " + str(errMsg) + "\nSYS LOG: " + str(err)

        self.logTools.addLog("LOG", response)
