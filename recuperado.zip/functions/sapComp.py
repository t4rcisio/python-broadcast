import copy
import datetime
import os
import subprocess
import time
import traceback

from utils import excelUtils, broadcast, sapManager, tools
from utils import excelTools

from internal.com import communication, logControl
from internal.services import echo


class SAP_COMP:

    def __init__(self):

        self.excelTools = excelUtils.XlsxUtils()
        self.excelUtils = excelTools.ExcelTools()
        self.broadcast = broadcast.Broadcast()
        self.logTools = logControl.LogControl()
        self.sapTools = sapManager.SAPManager()
        self.tools = tools.Utils()
        self.comm = communication.Commnunication()
        self.echo = echo.Echo()


    def export(self):

        try:

            self.__saveResults()
        except:
            self.logTools.addLog("ERRO", traceback.format_exc())



    def run(self, payload):

        self.masterCount = 0

        try:

            self.comm.textUpdate("CARREGANDO ARQUIVO")
            sheet = self.excelTools.loadSheet_v2(payload["FILE"], payload["TABLE"])
            self.__buildQueue(sheet)

            self.comm.textUpdate("INICIALIZANDO SAP")
            if not self.sapTools.startSAP(payload["USER"], payload["PASSWORD"], payload["CONNECTION"]):
                self.comm.notifications("OCORREU UM ERRO AO INICIALIZAR O SAP")
                return

            self.dataComp = payload["DATA COMP."]

            self.sapTools.openTransaction("F-51")
            self.erros = []
            self.__sendData()

            if len(self.erros) > 0:
                self.__sendData(copy.copy(self.erros))

            self.tableName = payload["TABLE"]
            payload = {"TABLE": payload["TABLE"], "QUEUE": self.queue, "COLMAP": self.colMap}
            self.comm.saveTempProccess("F51", payload)

            self.__saveResults(payload["TABLE"])
            self.comm.textUpdate("PROCESSO FINALIZADO | " + str(self.masterCount) + " COMPESAÇÕES FINALIZADAS")

            self.echo.end("1347", str(self.masterCount))
            self.sapTools.killSAP()
        except:

            payload = {"TABLE": payload["TABLE"], "QUEUE": self.queue, "COLMAP": self.colMap}
            self.comm.saveTempProccess("F51", payload)

            self.__saveResults(payload["TABLE"])
            self.sapTools.killSAP()
            self.logTools.addLog("ERRO", traceback.format_exc(), True)
            self.broadcast.broadcastText("PROCESSO FINALIZADO | OCORREU UM ERRO | " + str(self.masterCount) + " COMPESAÇÕES FINALIZADAS")

    def __sendData(self, queue=False):

        counter = 1

        if not queue:
            queue = list(self.queue.keys())

        for item in queue:

            if str(self.comm.stop()) == "TRUE" or self.sapTools.session == False:
                self.logTools.addLog("LOG", "O USUÁRIO PAROU O PROCESSO")
                self.comm.stop("")
                break

            self.comm.textUpdate("PROCESSANDO F-51 | " + str(counter) + " de " + str(len(queue)))

            moeda = self.queue[item][0][self.colMap["Moneda"]].strip()
            sociedade = self.queue[item][0][self.colMap["Sociedad"]].strip()
            data = self.queue[item][-1][self.colMap["Fecha De Depósito.Pago"]].strip()

            bp = self.tools.fixFloat2Str(str(self.queue[item][-1][self.colMap["Rut/Dni/Bp/Iata Cliente Emisor"]]).strip())


            if moeda != "" and sociedade != "" and data != "":
                self.sapTools.setText("DATA", "wnd[0]/usr/ctxtBKPF-BLDAT", str(data))

                if self.dataComp != "":
                    self.sapTools.setText("DATA CONTAB.", "wnd[0]/usr/ctxtBKPF-BUDAT", str(self.dataComp))

                self.sapTools.setText("MOEDA", "wnd[0]/usr/ctxtBKPF-WAERS", str(moeda))
                self.sapTools.setText("SOCIUEDADE", "wnd[0]/usr/ctxtBKPF-BUKRS", str(sociedade))
                self.sapTools.setText("CLASSE", "wnd[0]/usr/ctxtBKPF-BLART", "DO")
                self.sapTools.setText("REF", "wnd[0]/usr/txtBKPF-XBLNR", "COMP UATP - AUT")
                self.sapTools.setText("TEXT", "wnd[0]/usr/txtBKPF-BKTXT", "COMP UATP - AUT")

                self.sapTools.press("TRATAR PAS", "wnd[0]/tbar[1]/btn[6]", timeAfter=2)

                stepCheck = self.sapTools.getText("1", 'wnd[0]/usr/ctxtRF05A-AGBUK')

                if stepCheck == sociedade:

                    self.sapTools.setText("BP", "wnd[0]/usr/ctxtRF05A-AGKON", bp)
                    self.sapTools.setText("TEXT", "wnd[0]/usr/ctxtRF05A-AGKOA", "D")
                    #self.sapTools.caretPosition("SELEC", "wnd[0]/usr/ctxtRF05A-AGBUK", 6)
                    self.sapTools.select("OP","wnd[0]/usr/sub:SAPMF05A:0710/radRF05A-XPOS1[4,0]")

                    self.sapTools.sendKey("ENTER", "wnd[0]", 16)
                    #self.sapTools.press("TRATAR PAS", "wnd[0]/tbar[1]/btn[16]", timeAfter=2)

                    stepCheck = self.sapTools.getText("1", "wnd[0]/usr/txtRF05A-AGKON")

                    if stepCheck == bp:

                        for index in range(0,len(self.queue[item])):

                            value = self.tools.fixFloat2Str(str(self.queue[item][index][self.colMap["Número Documento Sap"]]).strip())
                            if len(value) < 8:
                                value = "0" + value

                            self.sapTools.setText("INSERT DOC","wnd[0]/usr/sub:SAPMF05A:0731/txtRF05A-SEL01["+str(index)+",0]",value)


                        self.sapTools.sendKey("ENTER", "wnd[0]", 0,  timeAfter=1)

                        stepCheck = self.sapTools.getText("ELEMENT", "wnd[0]/usr/sub:SAPMF05A:0731/txtRF05A-SEL01["+str(0)+",0]", timeAfter=1)

                        if stepCheck == "" and stepCheck != False:

                            conta = str(self.tools.fixFloat2Str(self.queue[item][-1][self.colMap["Cuenta De Banco Destinatario"]])).strip()

                            self.sapTools.press("OUTRA CONTA", "wnd[0]/tbar[1]/btn[7]", timeAfter=1)
                            self.sapTools.select("OP", "wnd[0]/usr/sub:SAPMF05A:0710/radRF05A-XPOS1[4,0]", timeAfter=1)
                            self.sapTools.setText("CLASSE", "wnd[0]/usr/ctxtRF05A-AGKOA", "S", timeAfter=1)
                            self.sapTools.setText("CONTA", "wnd[0]/usr/ctxtRF05A-AGKON", conta , timeAfter=1)
                            self.sapTools.sendKey("ENTER", "wnd[0]", 0, timeAfter=1)

                            stepCheck = self.sapTools.getText("ELEMENT","wnd[0]/usr/sub:SAPMF05A:0731/txtRF05A-SEL01[" + str(0) + ",0]", timeAfter=1)

                            if stepCheck == "" and stepCheck != False:

                                value = str(self.tools.fixFloat2Str(self.queue[item][-1][self.colMap["Numero Documento Sap (Sb)"]])).strip()
                                self.sapTools.setText("INSERT DOC","wnd[0]/usr/sub:SAPMF05A:0731/txtRF05A-SEL01[" + str(0) + ",0]", value)
                                self.sapTools.sendKey("ENTER", "wnd[0]", 0, timeAfter=1)

                                self.sapTools.press("TRATAR PAs", "wnd[0]/tbar[1]/btn[16]", timeAfter=1)

                                if self.chechValue(item):

                                    optn, response = self.__checkSave()

                                    if not optn:

                                        self.erros.append(item)
                                        self.queue[item][-1][self.colMap["F-51"]] = "ERRO AO PROCESSAR " + response

                                    else:
                                        self.queue[item][-1][self.colMap["F-51"]] = "PROCESSADO " + response
                                        self.comm.incrementOperation(1)

                                    self.__backToHome()
                                else:

                                    time.sleep(2)
                                    self.queue[item][-1][self.colMap["F-51"]] = self.__checkCompensado("NEM TODOS OS VALORES FORAM FORAM IDENTIFICADOS" + self.sapTools.getSAPmsg(), item)
                                    self.__backToHome()

                            else:

                                time.sleep(2)
                                self.queue[item][-1][self.colMap["F-51"]] = self.__checkCompensado("ERRO AO PROCESSAR"  + self.sapTools.getSAPmsg(), item)
                                self.__backToHome()
                        else:

                            time.sleep(2)
                            self.queue[item][-1][self.colMap["F-51"]] = self.__checkCompensado("ERRO AO PROCESSAR" + self.sapTools.getSAPmsg(), item)
                            self.__backToHome()
                    else:
                        self.erros.append(item)
                        time.sleep(2)
                        self.queue[item][-1][self.colMap["F-51"]] = "ERRO AO PROCESSAR" + self.sapTools.getSAPmsg()
                        self.__backToHome()
                else:
                    self.erros.append(item)
                    time.sleep(2)
                    self.queue[item][-1][self.colMap["F-51"]] = "ERRO AO PROCESSAR" + self.sapTools.getSAPmsg()
                    self.__backToHome()
            else:
                self.erros.append(item)
                time.sleep(2)
                self.queue[item][-1][self.colMap["F-51"]] = "ERRO AO PROCESSAR" + self.sapTools.getSAPmsg()
                self.__backToHome()

            counter +=1
            self.masterCount +=1

    def __checkCompensado(self, message, item):

        self.__backToHome("FB03")

        if not 'No se encontró' in message:
            return message

        ndoc = self.tools.fixFloat2Str(str(self.queue[item][-1][self.colMap['Numero Documento Sap (Sb)']]).strip())
        sociedade = str(self.queue[item][-1][self.colMap['Sociedad']]).strip()
        ano = str(datetime.datetime.now().year)

        self.sapTools.setText("NDOC","wnd[0]/usr/txtRF05L-BELNR", ndoc)
        self.sapTools.setText("SOC","wnd[0]/usr/ctxtRF05L-BUKRS", sociedade)
        self.sapTools.setText("ANO","wnd[0]/usr/txtRF05L-GJAHR", ano)

        self.sapTools.sendKey("ENTER", "wnd[0]", 0, timeAfter=1)

        smax = int(self.comm.userConf()['max_comb'])
        smax = smax + int(smax/2)

        for index in range(0, smax):
            try:
                res = self.sapTools.session.findById("wnd[0]/usr/cntlCTRL_CONTAINERBSEG/shellcont/shell").GetCellValue(index, "AUGBL")

                if res != "" and isinstance(self.tools.convert2float(res), float):
                    return "DOCUMENTO COMPENSADO ANTERIORMENTE - Doc." + str(res)
            except:
                pass

        self.erros.append(item)
        return str(message) + " | NÃO COMPENSADO NA FB03"



    def __saveResults(self, worksheet=False):


        self.comm.textUpdate("SALVANDO ARQUIVO COM O RESULTADO")

        try:

            if worksheet == False:
                dta = self.comm.saveTempProccess("F51")

                if not isinstance(dta, dict):
                    self.logTools.addLog("ERRO", "NÃO HÁ DADOS PARA EXPORTAÇÃO")
                    self.comm.notifications("NÃO HÁ DADOS PARA EXPORTAÇÃO")
                    return

                self.queue = dta["QUEUE"]
                self.colMap = dta["COLMAP"]
                worksheet = dta["TABLE"]



            mdata = []
            header = list(self.colMap.keys())
            mdata.append(header)

            for item in self.queue:
                for index in range(0, len(self.queue[item])):
                    mdata.append(self.queue[item][index])
                mdata.append([" " for i in range(0, len(header))])

            dest = "C:\\Users\\" + str(os.getlogin()) + "\\Downloads\\F-51_"+str(datetime.datetime.now().strftime("%d.%m.%Y_%H.%M"))+".xlsx"
            temp = self.broadcast.tempFolder + "/temp.txt"
            self.excelUtils.saveData(dest, worksheet, temp, mdata)

            self.comm.textUpdate("COMPLETO! SALVO EM: "+ str(os.path.basename(dest)))
            self.comm.notifications("COMPLETO! SALVO EM: "+ str(os.path.basename(dest)))
        except:
            self.logTools.addLog("ERRO", traceback.format_exc())

    i = 0
    def chechValue(self, item, tentative=2):

        valueList = [self.tools.convert2float(self.queue[item][index][self.colMap['Monto De La Factura']]) for index in range(0, len(self.queue[item]))]
        counter = 0

        for i in range(0, 50):
            value = self.sapTools.getText("VALUE","wnd[0]/usr/tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/tblSAPDF05XTC_6102/txtDF05B-PSBET[9,"+str(i)+"]")

            value = self.tools.convert2float(value)

            if value in valueList:
                counter +=1
            if str(value) == "False":
                break


        res = counter >= len(valueList)

        if not res and tentative > 0:
            return self.chechValue(item, tentative-1)
        else:
            return res


    def __checkSave(self):

        s1 = self.sapTools.getText('SALDO', "wnd[0]/usr/tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/txtRF05A-DIFFB")
        s2 = self.sapTools.getText('SALDO', "wnd[0]/usr/tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/txtRF05A-NETTO")
        s3 = self.sapTools.getText('SALDO', "wnd[0]/usr/tabsTS/tabpMAIN/ssubPAGE:SAPDF05X:6102/txtRF05A-BETRG", timeAfter=1)

        if s1 == False or s2 == False or s3 == False:
            return False, "NÃO FOI POSSÍVEL VERIFICAR O SALDO" + " \ " + self.sapTools.getSAPmsg()

        values = [self.tools.convert2float(s1), self.tools.convert2float(s2), self.tools.convert2float(s3)]

        for item in values:

            if isinstance(item, float):

                if item > 0:
                    return False, "SALDO DIFERENTE DE 0 \ " + self.sapTools.getSAPmsg()

            else:
                return False, "NÃO FOI POSSÍVEL VERIFICAR O SALDO" + " \ " + self.sapTools.getSAPmsg()

        self.sapTools.press("SIMULAR", "wnd[0]/mbar/menu[0]/menu[1]")
        self.sapTools.press("SALVAR", "wnd[0]/tbar[0]/btn[11]")
        self.sapTools.press("SALVAR 2", "wnd[1]/tbar[0]/btn[0]")

        time.sleep(3)
        response = self.sapTools.getSAPmsg()
        return True, response



    def __newCol(self, cName):

        vMax = 0
        for key in self.colMap:
            if self.colMap[key] > vMax:
                vMax = self.colMap[key]

        vMax = vMax + 1



    def __backToHome(self, transacao="F-51"):


        self.sapTools.press("CONFIRMA","wnd[0]/tbar[0]/btn[15]", timeAfter=0.5, skipLog=True)
        self.sapTools.press("CONFIRMA","wnd[1]/usr/btnSPOP-OPTION1", timeAfter=0.5, skipLog=True)

        self.sapTools.openTransaction(transacao)

    def __buildQueue(self, sheet):

        self.colMap = {}
        self.queue = {}

        if not "F-51" in sheet[0]:
            sheet[0].append("F-51")

        for index in range(0, len(sheet[0])):
            self.colMap[sheet[0][index]] = index

        ctrl = 1
        for index in range(1, len(sheet)):

            row = self.excelTools.fixNaN(sheet[index])
            row = self.__fixFloat(row)
            if len(row) < len(sheet[0]):

                dif = len(sheet[0]) - len(row)
                for i in range(0, dif):
                    row.append("")

            cod = str(row[self.colMap['Rut/Dni/Bp/Iata Cliente Emisor']]).strip()

            if cod != '':

                if not ctrl in self.queue:
                    self.queue[ctrl] = []

                self.queue[ctrl].append(row)

            else:
                ctrl +=1



    def __fixFloat(self, row):


        col = ['Cuenta De Banco Destinatario','Documento Que Paga (Factura / Nota De Crédito / Liquidación)','Rut/Dni/Bp/Iata Cliente Emisor', 'Número Documento Sap', 'Numero Documento Sap (Sb)']

        for i in col:

            if i in self.colMap:
                row[self.colMap[i]] = self.tools.fixFloat2Str(row[self.colMap[i]])


        return row